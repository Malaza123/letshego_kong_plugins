apk add expat expat-dev
luarocks install --only-deps kong-plugin-soap-request-transformer-0.1.0-0.rockspec
