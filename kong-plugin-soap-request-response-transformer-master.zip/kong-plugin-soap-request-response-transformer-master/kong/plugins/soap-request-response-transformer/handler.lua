-- local access = require("kong.plugins.soap-request-transformer.access") --------
local access = require("kong.plugins.soap-request-response-transformer.access")
local kong = kong
local get_raw_body = kong.request.get_raw_body
local set_raw_body = kong.service.request.set_raw_body
local get_header = kong.request.get_header
local set_header = kong.service.request.set_header
local handler = require("xmlhandler.tree")
local xml2lua = require("xml2lua")
local concat = table.concat
local cjson = require("cjson")

local CONTENT_TYPE = "content-type"
local CONTENT_LENGTH = "content-length"

----------------------------------------------------------------------
--------------------response transformation---------------------------
----------------------------------------------------------------------

local find = string.find
local sub = string.sub
local gsub = string.gsub
local match = string.match
local lower = string.lower
local next = next
local pl = require ("pl.pretty")
local ngx_re = require("ngx.re")
--local lunajson = require("lunajson")

-- decode to convert json string to lua table
local function read_json_body(body)
    if body then
      return cjson.decode(body)
    end
end

local function toboolean(value)
    if value == "true" then
      return true
    else
      return false
    end
end


local function cast_value(value, value_type)
    if value_type == "number" then
      return tonumber(value)
    elseif value_type == "boolean" then
      return toboolean(value)
    else
      return value
    end
end

local function iter(config_array)

    if type(config_array) ~= "table" then
      return noop
    end
  
    return function(config_array, i)
      i = i + 1
  
      local current_pair = config_array[i]
      if current_pair == nil then -- n + 1
        return nil
      end
  
      local current_name, current_value = match(current_pair, "^([^:]+):*(.-)$")
      if current_value == "" then
        current_value = nil
      end
  
      return i, current_name, current_value
    end, config_array, 0
end

  
-- Navigate json to the value(s) pointed to by path and apply function f to it.
local function navigate_and_apply(json, path, f)
    local head, index, tail
  
    -- Split into a table with three values, e.g. Results[*].info.name becomes {"Results", "[*]", "info.name"}
    local res = ngx_re.split(path, "(\\[[\\d|\\*]*\\])?\\.", nil, nil, 2)

    if res then
    head = res[1]
    if res[2] and res[3] then
        -- Extract index, e.g. "2" from "[2]"
        index = string.sub(res[2], 2, -2)
        tail = res[3]
    else
        tail = res[2]
    end
    end
  
    if type(json) == "table" then
      if index == '*' then
        -- Loop through array
        local array = json
        if head ~= '' then
          array = json[head]
        end
  
        for k, v in ipairs(array) do
          if type(v) == "table" then
            navigate_and_apply(v, tail, f)
          end
        end
  
      elseif index and index ~= '' then
        -- Access specific array element by index
        index = tonumber(index)
        local element = json[index]
        if head ~= '' and json[head] and type(json[head]) == "table" then
          element = json[head][index]
        end
  
        navigate_and_apply(element, tail, f)
  
      elseif tail and tail ~= '' then
        -- Navigate into nested JSON
        navigate_and_apply(json[head], tail, f)
  
      elseif head and head ~= '' then
        -- Apply passed-in function
        f(json, head)
  
      end
    end
end


----------------------------------------------------------------------
----------------------------------------------------------------------
------------ CAN'T MAKE THE BELOW FUNCTIONS GENERIC ------------------
-------- HAD TO BE PER SERVICE even though there is repeating code ---
-------- because conf. value  can't be stored in a variable ----------
------------- It also can't be passed as a function parameter --------
----------------------------------------------------------------------
----------------------------------------------------------------------


-- remove key:value to body
local function remove_enquireAccountDetails(conf, decodedbody)

  for _, name in iter(conf.remove.enquireAccountDetails) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_nPBTransferToDepositAccount(conf, decodedbody)

  for _, name in iter(conf.remove.nPBTransferToDepositAccount) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end



-- remove key:value to body
local function remove_nPBTransferToDepositAccountCorrection(conf, decodedbody)

  for _, name in iter(conf.remove.nPBTransferToDepositAccountCorrection) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_pOSPurchase(conf, decodedbody)

  for _, name in iter(conf.remove.pOSPurchase) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_pOSPurchaseCorrection(conf, decodedbody)

  for _, name in iter(conf.remove.pOSPurchaseCorrection) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_pOSRefund(conf, decodedbody)

  for _, name in iter(conf.remove.pOSRefund) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_atmCashWithdrawal(conf, decodedbody)

  for _, name in iter(conf.remove.atmCashWithdrawal) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_aTMCashWithdrawalCorrection(conf, decodedbody)

  for _, name in iter(conf.remove.aTMCashWithdrawalCorrection) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_inwardNRTCredit(conf, decodedbody)

  for _, name in iter(conf.remove.inwardNRTCredit) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_inwardNRTCreditCorrection(conf, decodedbody)

  for _, name in iter(conf.remove.inwardNRTCreditCorrection) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_inwardEnDebit(conf, decodedbody)

  for _, name in iter(conf.remove.inwardEnDebit) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_inwardEnDebitCorrection(conf, decodedbody)

  for _, name in iter(conf.remove.inwardEnDebitCorrection) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end


-- remove key:value to body
local function remove_inwardNRTCreditClearing(conf, decodedbody)

  for _, name in iter(conf.remove.inwardNRTCreditClearing) do
    navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)
  end

    return decodedbody
end

-- remove single key:value to body
local function remove_single_json(decodedbody, name)
  navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)

  return decodedbody
end

----------------------------------------------------------------------
----------------------------------------------------------------------
------------ CAN'T MAKE THE ABOVE FUNCTIONS GENERIC ------------------
-------- HAD TO BE PER SERVICE even though there is repeating code ---
-------- because conf. value  can't be stored in a variable ----------
------------- It also can't be passed as a function parameter --------
----------------------------------------------------------------------
----------------------------------------------------------------------

-- remove nested key:value in a nested json array
-- used only for /account
local function remove_nested_enquireAccountDetails(conf , decodedbody, count)

  local res_subcoll = "enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[index]"
  local subcoll = "enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[index]"

  -- flag to change after executing
  local singleaccountflag = true

  for _, name in iter(conf.remove.nested_enquireAccountDetails) do

    -- change the max index to the number of accounts returned in response
    -- by replacing filler "index" in the plugin config with count
    name = gsub(name, "index", count)
    -- kong.log.debug("inside remove_nested_jsons FOR for: ............. "..name)

    -- *******TO DO**********
    -- Optimize the FOR loops code, getting executed multiple times unnecessarily after removing an array already

    -- remove the keys in each array one by one
    for i=count,1,-1 do

      -- remove the whole account sub array if below conditions are met
      -- enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[index]
          -- .Stat ~= "OPEN"          (should return only OPEN not CLOS or DRMT)
          -- .RelnshpWtAcct ~= "OWN"  (should return only OWN not JOINT)
          -- .AcctTyp == ""           (should be some value not empty)
          -- .AcctSubTyp == ""        (should be some value not empty)

      -- If response has only one account, then coll[] is no longer an array
      -- So, this is to convert it into one and then do the manipulation
      if count == 1 and singleaccountflag then

        -- change to false if already modified
        singleaccountflag = false
        
        -- encode to get a string for string manipulation
        local changetoarray = cjson.encode(decodedbody)

        -- sub {} to [] by
        -- "Coll":{ to "Coll":[{
        -- ending }}}}} to }]}}}}
        changetoarray = gsub(changetoarray, '"Coll":{', '"Coll":[{')
        -- get length
        local n = string.len(changetoarray)
        -- remove ending 5 brackets }}}}}
        local lastbracketsremoved = sub(changetoarray, 1, n-5)

        -- replace with array ] bracket inserted
        changetoarray = lastbracketsremoved.."}]}}}}"

        -- decode again
        decodedbody = read_json_body(changetoarray)

      end

      local res_stat_value = decodedbody.enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[i].Stat
      local res_RelnshpWtAcct_value = decodedbody.enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[i].RelnshpWtAcct
      local res_AcctTyp_value = decodedbody.enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[i].AcctTyp
      local res_AcctSubTyp_value = decodedbody.enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[i].AcctSubTyp

      -- kong.log.debug("inside 2nd FOR loop for removing the key inside all arrays with i: ...... "..i.." and name: "..name)

      if res_stat_value == "CLOS" or res_stat_value == "DRMT" or res_RelnshpWtAcct_value == "JOIN" or res_AcctTyp_value == "" or res_AcctSubTyp_value == "" then
        --kong.log.debug("removing accnum: "..decodedbody.enquireAccountDetailsResponse.AcctDetailsInqRs.AcctDetailsInqData.Coll[i].AcctNum)

        -- get the coll[index] to remove
        res_subcoll = gsub(subcoll, "index", i)
        -- kong.log.debug("coll to remove: "..res_subcoll)

        -- keys to remove
        local remove_stat = res_subcoll..".Stat"
        local remove_CurCode2 = res_subcoll..".CurCode2"
        local remove_Bal = res_subcoll..".Bal"
        local remove_AcctNum = res_subcoll..".AcctNum"
        local remove_ShrtName = res_subcoll..".ShrtName"
        local remove_AcctTyp = res_subcoll..".AcctTyp"

        -- remove the remaining too if conditions are met
        decodedbody = remove_single_json(decodedbody, remove_stat)
        decodedbody = remove_single_json(decodedbody, remove_CurCode2)
        decodedbody = remove_single_json(decodedbody, remove_Bal)
        decodedbody = remove_single_json(decodedbody, remove_AcctNum)
        decodedbody = remove_single_json(decodedbody, remove_ShrtName)
        decodedbody = remove_single_json(decodedbody, remove_AcctTyp)

      end
      
      navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)    
      -- coll[0] doesn't exist as indexes in LUA start from 1 rather than 0
      name = gsub(name, i, i - 1)
    end
  end

    return decodedbody
end


-- find repeating strings
local function countSubstring(s1, s2)
  local count = 0
  for eachMatch in s1:gmatch(s2) do 
      count = count + 1 
  end
  return count
end

----------------------------------------------------------------------
--------------------response transformation END-----------------------
----------------------------------------------------------------------

local SoapTransformerHandler = {
    VERSION = "0.0.2",
    PRIORITY = 799,
}

local function remove_attr_tags(e)
    if type(e) == "table" then
        for k, v in pairs(e) do
            if k == '_attr' then
                e[k] = nil
            end
            remove_attr_tags(v)
        end
    end
end

function SoapTransformerHandler.convertXMLtoJSON(xml, conf)
    local xmlHandler = handler:new()
    local parser = xml2lua.parser( xmlHandler )
    parser:parse(xml)
    local SOAPPrefix = "soapenv"

    if     string.match(xml,"soapenv:Envelope") then SOAPPrefix = "soapenv"
    elseif string.match(xml,"soap:Envelope"   ) then SOAPPrefix = "soap" 
    elseif string.match(xml,"soap12:Envelope" ) then SOAPPrefix = "soap12" end

    local t = xmlHandler.root[SOAPPrefix .. ":Envelope"][SOAPPrefix .. ":Body"]
    
    remove_attr_tags(t)

    return cjson.encode(t)
end

function SoapTransformerHandler:access(conf)
    local body = get_raw_body()
    --kong.log.debug("get_raw_body: "..body)
    local is_body_transformed, body = access.transform_body(conf, body,get_header(CONTENT_TYPE))

    if is_body_transformed then
        set_raw_body(body)
        set_header(CONTENT_LENGTH, #body)
        set_header(CONTENT_TYPE, "text/xml;charset=UTF-8")
    end

end

function SoapTransformerHandler:header_filter(conf)
    kong.response.clear_header("Content-Length")
    kong.response.set_header("Content-Type", "application/json")
end

function SoapTransformerHandler:body_filter(conf)
    local ctx = ngx.ctx
    local chunk, eof = ngx.arg[1], ngx.arg[2]

    ctx.rt_body_chunks = ctx.rt_body_chunks or {}
    ctx.rt_body_chunk_number = ctx.rt_body_chunk_number or 1

    -- if eof wasn't received keep buffering
    if not eof then
        ctx.rt_body_chunks[ctx.rt_body_chunk_number] = chunk
        ctx.rt_body_chunk_number = ctx.rt_body_chunk_number + 1
        ngx.arg[1] = nil
        return
    end

    -- if bad gateway status recieved return
    if kong.response.get_status() == 502 then
        return nil
    end

    -- last piece of body is ready
    local resp_body = concat(ctx.rt_body_chunks)

    if not resp_body or resp_body == '' then
        return nil
    end

    kong.log.debug("Response body XML: "..resp_body)
    -- ngx.arg[1] = self.convertXMLtoJSON(resp_body, conf)

    ----------------------------------------------------------------------
    --------------------response transformation---------------------------
    ----------------------------------------------------------------------

    -- storing the encoded json, converted from table to string
    local responsejson = self.convertXMLtoJSON(resp_body, conf)

    -- remove ns2:, dlwmin: prefixes from responses
    -- This is to avoid semicolon ":" in json keys which doesn't work with remove function
    responsejson = gsub(responsejson, "ns2:", "")
    responsejson = gsub(responsejson, "dlwmin:", "")

    -- decode and get table from string after removing :
    -- to perform remove operation for transformation 
    local decodedjson = read_json_body(responsejson)

    ------------------------------------------------------------------------
    -- LOGIC switching per service
    ------------------------------------------------------------------------

    if string.find(responsejson, "enquireAccountDetailsResponse") then
      kong.log.debug("This is a /account enquireAccountDetails response")

      ------------------------------------------------------------------------
      --- EXTRA logic only for /account success responses
      -- remaining APIs are all same with removing just the cong.remove.json
      ------------------------------------------------------------------------

      -- below logic is to save some time rather than running remove on everything
      -- this single key is enough for to remove for /account failures
      local accheadertoremove = "enquireAccountDetailsResponse.AcctDetailsInqRs.RsHeader"

      -- to remove keys from nested array only for success /account response
      -- we get this string AcctDetailsInqData only in success responses
      if string.find(responsejson, "AcctDetailsInqData") then
        kong.log.debug("This is a /account success response")

        -- remove RsHeader
        decodedjson = remove_single_json(decodedjson, accheadertoremove)

        -- remove remaining keys unique to success responses
        decodedjson = remove_enquireAccountDetails(conf, decodedjson)

        -- remove nested accounts in coll[]
        -- encode table to string to count repeating substring
        -- to get number of accounts returned in the response
        local nestedjsontoremove = cjson.encode(decodedjson)

        -- count number of accounts returned in the response within coll[] array
        local count = countSubstring(nestedjsontoremove, "AcctNum")
        kong.log.debug("Number of accounts returned are: "..count)

        -- remove keys not needed for accounts within coll[]
        decodedjson = remove_nested_enquireAccountDetails(conf, decodedjson, count)

        -- remove empty arrays inside coll[] after unneeded accounts are removed
        -- for example in
        -- {"enquireAccountDetailsResponse":{"AcctDetailsInqRs":{"AcctDetailsInqData":{"Coll":[{},{},{},{},{},{},{},{}]}}}}
        local removemptyarrays = cjson.encode(decodedjson)

        -- if any other array element is empty
        removemptyarrays = gsub(removemptyarrays, ",{}", "")
        -- if the first one array element is empty
        removemptyarrays = gsub(removemptyarrays, ":%[{},", ":[")

        -- decode and covert to table for later use
        decodedjson = read_json_body(removemptyarrays)

      else
        kong.log.debug("This is a /account enquireAccountDetails failure response")

          -- remove just the RsHeader for account failures
          decodedjson = remove_single_json(decodedjson, accheadertoremove)
      end

    ----------------------------------------------------------------------
    -- do just remove_json for all other APIs
    ----------------------------------------------------------------------

    ----------------------------------------------------------------------
    -- nPBTransferToDepositAccountResponse
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "nPBTransferToDepositAccountResponse") then
        kong.log.debug("This is a nPBTransferToDepositAccount Response")
        
        decodedjson = remove_nPBTransferToDepositAccount(conf, decodedjson)


    ----------------------------------------------------------------------
    -- nPBTransferToDepositAccountCorrectionResponse
    ----------------------------------------------------------------------
  elseif string.find(responsejson, "nPBTransferToDepositAccountCorrectionResponse") then
    kong.log.debug("This is a nPBTransferToDepositAccountCorrection Response")
    
    decodedjson = remove_nPBTransferToDepositAccountCorrection(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 1
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "pOSPurchaseResponse") then
      kong.log.debug("This is a pOSPurchase Response")

      decodedjson = remove_pOSPurchase(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 2
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "pOSPurchaseCorrectionResponse") then
      kong.log.debug("This is a pOSPurchaseCorrection Response")

      decodedjson = remove_pOSPurchaseCorrection(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 3
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "pOSRefundResponse") then
      kong.log.debug("This is a pOSRefund Response")

      decodedjson = remove_pOSRefund(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 4
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "atmCashWithdrawalResponse") then
      kong.log.debug("This is a atmCashWithdrawal Response")

      decodedjson = remove_atmCashWithdrawal(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 5
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "aTMCashWithdrawalCorrectionResponse") then
      kong.log.debug("This is a aTMCashWithdrawalCorrection Response")

      decodedjson = remove_aTMCashWithdrawalCorrection(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 6
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "inwardNRTCreditResponse") then
      kong.log.debug("This is a inwardNRTCredit Response")

      decodedjson = remove_inwardNRTCredit(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 7
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "inwardNRTCreditCorrectionResponse") then
      kong.log.debug("This is a inwardNRTCreditCorrection Response")

      decodedjson = remove_inwardNRTCreditCorrection(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 8
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "inwardEnDebitResponse") then
      kong.log.debug("This is a inwardEnDebit Response")

      decodedjson = remove_inwardEnDebit(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 9
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "inwardEnDebitCorrectionResponse") then
      kong.log.debug("This is a inwardEnDebitCorrection Response")

      decodedjson = remove_inwardEnDebitCorrection(conf, decodedjson)

    ----------------------------------------------------------------------
    -- 10
    ----------------------------------------------------------------------
    elseif string.find(responsejson, "inwardNRTCreditClearingResponse") then
      kong.log.debug("This is a inwardNRTCreditClearing Response")
      
      decodedjson = remove_inwardNRTCreditClearing(conf, decodedjson)

    end


    -- final encode from table to string before sending response
    ngx.arg[1] = cjson.encode(decodedjson)

----------------------------------------------------------------------
--------------------response transformation END-----------------------
----------------------------------------------------------------------

    kong.log.debug("Response body JSON: "..ngx.arg[1])
end


return SoapTransformerHandler
