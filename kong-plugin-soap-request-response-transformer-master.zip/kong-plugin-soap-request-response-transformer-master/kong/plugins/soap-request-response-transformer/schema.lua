local typedefs = require "kong.db.schema.typedefs"

----------------------------------------------------------------------
--------------------transformation------------------------------------
----------------------------------------------------------------------

-- entries must have colons to set the key and value apart
local strings_array = {
    type = "array",
    default = {},
    elements = { type = "string" }
}

local colon_strings_array = {
    type = "array",
    default = {},
    elements = { type = "string", custom_validator = check_for_value },
  }

----------------------------------------------------------------------
--------------------transformation END--------------------------------
----------------------------------------------------------------------

return {
    name = "soap-request-tranformer-acc",
    fields = {
        {
            consumer = typedefs.no_consumer
        },
        {
            config = {
                type = "record",
                fields = {
----------------------------------------------------------------------
--------------------transformation------------------------------------
----------------------------------------------------------------------
                    { add = { type = "record", fields = {
                        { enquireAccountDetails = colon_strings_array },
                        { nPBTransferToDepositAccount = colon_strings_array },
                        { nPBTransferToDepositAccountCorrection = colon_strings_array },
                        { pOSPurchase = colon_strings_array },
                        { pOSPurchaseCorrection = colon_strings_array },
                        { pOSRefund = colon_strings_array },
                        { atmCashWithdrawal = colon_strings_array },
                        { aTMCashWithdrawalCorrection = colon_strings_array },
                        { inwardNRTCredit = colon_strings_array },
                        { inwardNRTCreditCorrection = colon_strings_array },
                        { inwardEnDebit = colon_strings_array },
                        { inwardEnDebitCorrection = colon_strings_array },
                        { inwardNRTCreditClearing = colon_strings_array },

                    }}},
                    { remove = { type = "record", fields = {
                        { enquireAccountDetails = strings_array },
                        { nPBTransferToDepositAccount = strings_array },
                        { nPBTransferToDepositAccountCorrection = strings_array },
                        { pOSPurchase = strings_array },
                        { pOSPurchaseCorrection = strings_array },
                        { pOSRefund = strings_array },
                        { atmCashWithdrawal = strings_array },
                        { aTMCashWithdrawalCorrection = strings_array },
                        { inwardNRTCredit = strings_array },
                        { inwardNRTCreditCorrection = strings_array },
                        { inwardEnDebit = strings_array },
                        { inwardEnDebitCorrection = strings_array },
                        { inwardNRTCreditClearing = strings_array },

                        { nested_enquireAccountDetails = strings_array },
                    }}},
                    { replace = { type = "record", fields = {
                        { enquireAccountDetails_namibia = colon_strings_array },
                        { nPBTransferToDepositAccount_namibia = colon_strings_array },
                        { nPBTransferToDepositAccountCorrection_namibia = colon_strings_array },
                        { pOSPurchase_namibia = colon_strings_array },
                        { pOSPurchaseCorrection_namibia = colon_strings_array },
                        { pOSRefund_namibia = colon_strings_array },
                        { atmCashWithdrawal_namibia = colon_strings_array },
                        { aTMCashWithdrawalCorrection_namibia = colon_strings_array },
                        { inwardNRTCredit_namibia = colon_strings_array },
                        { inwardNRTCreditCorrection_namibia = colon_strings_array },
                        { inwardEnDebit_namibia = colon_strings_array },
                        { inwardEnDebitCorrection_namibia = colon_strings_array },
                        { inwardNRTCreditClearing_namibia = colon_strings_array },
----------------------------------------------------------------------
                        { enquireAccountDetails_mozambique = colon_strings_array },
                        { nPBTransferToDepositAccount_mozambique = colon_strings_array },
                        { nPBTransferToDepositAccountCorrection_mozambique = colon_strings_array },
----------------------------------------------------------------------
                        { enquireAccountDetails_nigeria = colon_strings_array },
                        { nPBTransferToDepositAccount_nigeria = colon_strings_array },
                        { nPBTransferToDepositAccountCorrection_nigeria = colon_strings_array },
----------------------------------------------------------------------
                        { enquireAccountDetails_tanzania = colon_strings_array },
                        { nPBTransferToDepositAccount_tanzania = colon_strings_array },
                        { nPBTransferToDepositAccountCorrection_tanzania = colon_strings_array },

                    }}},
----------------------------------------------------------------------
--------------------transformation END--------------------------------
----------------------------------------------------------------------      
                },
            },
        },
    }
}