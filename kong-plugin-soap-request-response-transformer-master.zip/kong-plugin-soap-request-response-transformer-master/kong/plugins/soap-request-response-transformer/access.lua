local cjson = require("cjson")
-- local soap = require("kong.plugins.soap-request-transformer.soap") --------
local soap = require("kong.plugins.soap-request-response-transformer.soap")
local kong = kong
local pcall = pcall
local JSON = "application/json"
local insert = table.insert
local _M = {}

----------------------------------------------------------------------
--------------------request transformation----------------------------
----------------------------------------------------------------------

local find = string.find
local sub = string.sub
local gsub = string.gsub
local match = string.match
local lower = string.lower
local next = next
local pl = require ("pl.pretty")
local ngx_re = require("ngx.re")
local get_header = kong.request.get_header
--local lunajson = require("lunajson")

----------------------------------------------------------------------
--------------------request transformation end------------------------
----------------------------------------------------------------------

local function parse_json(body)
    if body then
        local status, res = pcall(cjson.decode, body)
        if status then
            return res
        end
    end
end


local function parse_entries(e, parent)
    if type(e) == "table" then
        for k, v in pairs(e) do
            local el = { ['tag'] = k }
            insert(parent, el)
            parse_entries(v, el)
        end
    else
        insert(parent, e)
    end
end

----------------------------------------------------------------------
--------------------request transformation----------------------------
----------------------------------------------------------------------

local function read_json_body(body)
    if body then
      return cjson.decode(body)
    end
end

local function toboolean(value)
    if value == "true" then
      return true
    else
      return false
    end
end


local function cast_value(value, value_type)
    if value_type == "number" then
      return tonumber(value)
    elseif value_type == "boolean" then
      return toboolean(value)
    else
      return value
    end
end

local function iter(config_array)

    if type(config_array) ~= "table" then
      return noop
    end
  
    return function(config_array, i)
      i = i + 1
  
      local current_pair = config_array[i]
      if current_pair == nil then -- n + 1
        return nil
      end
  
      local current_name, current_value = match(current_pair, "^([^:]+):*(.-)$")
      if current_value == "" then
        current_value = nil
      end
  
      return i, current_name, current_value
    end, config_array, 0
end


-- Navigate json to the value(s) pointed to by path and apply function f to it.
local function navigate_and_apply(json, path, f)
    local head, index, tail
  
    -- Split into a table with three values, e.g. Results[*].info.name becomes {"Results", "[*]", "info.name"}
    local res = ngx_re.split(path, "(\\[[\\d|\\*]*\\])?\\.", nil, nil, 2)

    if res then
    head = res[1]
    if res[2] and res[3] then
        -- Extract index, e.g. "2" from "[2]"
        index = string.sub(res[2], 2, -2)
        tail = res[3]
    else
        tail = res[2]
    end
    end
  
    if type(json) == "table" then
      if index == '*' then
        -- Loop through array
        local array = json
        if head ~= '' then
          array = json[head]
        end
  
        for k, v in ipairs(array) do
          if type(v) == "table" then
            navigate_and_apply(v, tail, f)
          end
        end
  
      elseif index and index ~= '' then
        -- Access specific array element by index
        index = tonumber(index)
        local element = json[index]
        if head ~= '' and json[head] and type(json[head]) == "table" then
          element = json[head][index]
        end
  
        navigate_and_apply(element, tail, f)
  
      elseif tail and tail ~= '' then
        -- Navigate into nested JSON
        navigate_and_apply(json[head], tail, f)
  
      elseif head and head ~= '' then
        -- Apply passed-in function
        f(json, head)
  
      end
    end
end


----------------------------------------------------------------------
----------------------------------------------------------------------
------------ CAN'T MAKE THE BELOW FUNCTIONS GENERIC ------------------
-------- HAD TO BE PER SERVICE even though there is repeating code ---
-------- because conf. value  can't be stored in a variable ----------
------------- It also can't be passed as a function parameter --------
----------------------------------------------------------------------
----------------------------------------------------------------------




---------------------------------------------------------------------------------
-----------------------enquireAccountDetails-----------------------------------
---------------------------------------------------------------------------------


-- add new key:value to body
local function add_enquireAccountDetails_keys(conf, decodedbody)
  kong.log.debug("adding enquireAccountDetails keys ........... ")

    for i, name, value in iter(conf.add.enquireAccountDetails) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_namibia_enquireAccountDetails(conf, decodedbody)
  kong.log.debug("replacing enquireAccountDetails values for namibia ...........")
  
    for i, name, value in iter(conf.replace.enquireAccountDetails_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end

    end
  
  return decodedbody
end


-- replace key:value to body
local function replace_mozambique_enquireAccountDetails(conf, decodedbody)
  kong.log.debug("replacing enquireAccountDetails values for mozambique ...........")
  
    for i, name, value in iter(conf.replace.enquireAccountDetails_mozambique) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end

    end
  
  return decodedbody
end


-- replace key:value to body
local function replace_nigeria_enquireAccountDetails(conf, decodedbody)
  kong.log.debug("replacing enquireAccountDetails values for nigeria...........")
  
    for i, name, value in iter(conf.replace.enquireAccountDetails_nigeria) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end

    end
  
  return decodedbody
end


-- replace key:value to body
local function replace_tanzania_enquireAccountDetails(conf, decodedbody)
  kong.log.debug("replacing enquireAccountDetails values for tanzania...........")
  
    for i, name, value in iter(conf.replace.enquireAccountDetails_tanzania) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end

    end
  
  return decodedbody
end


---------------------------------------------------------------------------------
-----------------------nPBTransferToDepositAccount-----------------------------------
---------------------------------------------------------------------------------


-- add new key:value to body
local function add_nPBTransferToDepositAccount_keys(conf, decodedbody)
  kong.log.debug("adding nPBTransferToDepositAccount keys ........... ")

    for i, name, value in iter(conf.add.nPBTransferToDepositAccount) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_namibia_nPBTransferToDepositAccount(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccount namibia values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccount_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end

-- replace key:value to body
local function replace_mozambique_nPBTransferToDepositAccount(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccount mozambique values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccount_mozambique) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end

-- replace key:value to body
local function replace_nigeria_nPBTransferToDepositAccount(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccount nigeria values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccount_nigeria) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end

-- replace key:value to body
local function replace_tanzania_nPBTransferToDepositAccount(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccount tanzania values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccount_tanzania) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end



---------------------------------------------------------------------------------
-----------------------nPBTransferToDepositAccountCorrection-----------------------------------
---------------------------------------------------------------------------------


-- add new key:value to body
local function add_nPBTransferToDepositAccountCorrection_keys(conf, decodedbody)
  kong.log.debug("adding nPBTransferToDepositAccountCorrection keys ........... ")

    for i, name, value in iter(conf.add.nPBTransferToDepositAccountCorrection) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end



-- replace key:value to body
local function replace_namibia_nPBTransferToDepositAccountCorrection(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccountCorrection namibia values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccountCorrection_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end

-- replace key:value to body
local function replace_mozambique_nPBTransferToDepositAccountCorrection(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccountCorrection mozambique values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccountCorrection_mozambique) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end

-- replace key:value to body
local function replace_nigeria_nPBTransferToDepositAccountCorrection(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccountCorrection nigeria values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccountCorrection_nigeria) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end

-- replace key:value to body
local function replace_tanzania_nPBTransferToDepositAccountCorrection(conf, decodedbody)
  kong.log.debug("replacing nPBTransferToDepositAccountCorrection tanzania values ...........")
  
    for i, name, value in iter(conf.replace.nPBTransferToDepositAccountCorrection_tanzania) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end



---------------------------------------------------------------------------------
-----------------------pOSPurchase-----------------------------------
---------------------------------------------------------------------------------


-- add new key:value to body
local function add_pOSPurchase_keys(conf, decodedbody)
  kong.log.debug("adding pOSPurchase keys ........... ")

    for i, name, value in iter(conf.add.pOSPurchase) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_pOSPurchase_value(conf, decodedbody)
  kong.log.debug("replacing pOSPurchase_namibia values ...........")
  
    for i, name, value in iter(conf.replace.pOSPurchase_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_pOSPurchaseCorrection_keys(conf, decodedbody)
  kong.log.debug("adding pOSPurchaseCorrection keys ........... ")

    for i, name, value in iter(conf.add.pOSPurchaseCorrection) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_pOSPurchaseCorrection_value(conf, decodedbody)
  kong.log.debug("replacing pOSPurchaseCorrection_namibia values ...........")
  
    for i, name, value in iter(conf.replace.pOSPurchaseCorrection_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_pOSRefund_keys(conf, decodedbody)
  kong.log.debug("adding pOSRefund keys ........... ")

    for i, name, value in iter(conf.add.pOSRefund) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_pOSRefund_value(conf, decodedbody)
  kong.log.debug("replacing pOSRefund_namibia values ...........")
  
    for i, name, value in iter(conf.replace.pOSRefund_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_atmCashWithdrawal_keys(conf, decodedbody)
  kong.log.debug("adding atmCashWithdrawal keys ........... ")

    for i, name, value in iter(conf.add.atmCashWithdrawal) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_atmCashWithdrawal_value(conf, decodedbody)
  kong.log.debug("replacing atmCashWithdrawal_namibia values ...........")
  
    for i, name, value in iter(conf.replace.atmCashWithdrawal_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_aTMCashWithdrawalCorrection_keys(conf, decodedbody)
  kong.log.debug("adding aTMCashWithdrawalCorrection keys ........... ")

    for i, name, value in iter(conf.add.aTMCashWithdrawalCorrection) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_aTMCashWithdrawalCorrection_value(conf, decodedbody)
  kong.log.debug("replacing aTMCashWithdrawalCorrection_namibia values ...........")
  
    for i, name, value in iter(conf.replace.aTMCashWithdrawalCorrection_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_inwardNRTCredit_keys(conf, decodedbody)
  kong.log.debug("adding inwardNRTCredit keys ........... ")

    for i, name, value in iter(conf.add.inwardNRTCredit) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_inwardNRTCredit_value(conf, decodedbody)
  kong.log.debug("replacing inwardNRTCredit_namibia values ...........")
  
    for i, name, value in iter(conf.replace.inwardNRTCredit_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_inwardNRTCreditCorrection_keys(conf, decodedbody)
  kong.log.debug("adding inwardNRTCreditCorrection keys ........... ")

    for i, name, value in iter(conf.add.inwardNRTCreditCorrection) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_inwardNRTCreditCorrection_value(conf, decodedbody)
  kong.log.debug("replacing inwardNRTCreditCorrection_namibia values ...........")
  
    for i, name, value in iter(conf.replace.inwardNRTCreditCorrection_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end



-- add new key:value to body
local function add_inwardEnDebit_keys(conf, decodedbody)
  kong.log.debug("adding inwardEnDebit keys ........... ")

    for i, name, value in iter(conf.add.inwardEnDebit) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_inwardEnDebit_value(conf, decodedbody)
  kong.log.debug("replacing inwardEnDebit_namibia values ...........")
  
    for i, name, value in iter(conf.replace.inwardEnDebit_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_inwardEnDebitCorrection_keys(conf, decodedbody)
  kong.log.debug("adding inwardEnDebitCorrection keys ........... ")

    for i, name, value in iter(conf.add.inwardEnDebitCorrection) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_inwardEnDebitCorrection_value(conf, decodedbody)
  kong.log.debug("replacing inwardEnDebitCorrection_namibia values ...........")
  
    for i, name, value in iter(conf.replace.inwardEnDebitCorrection_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end


-- add new key:value to body
local function add_inwardNRTCreditClearing_keys(conf, decodedbody)
  kong.log.debug("adding inwardNRTCreditClearing keys ........... ")

    for i, name, value in iter(conf.add.inwardNRTCreditClearing) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end

    end

    return decodedbody
end


-- replace key:value to body
local function replace_inwardNRTCreditClearing_value(conf, decodedbody)
  kong.log.debug("replacing inwardNRTCreditClearing_namibia values ...........")
  
    for i, name, value in iter(conf.replace.inwardNRTCreditClearing_namibia) do
      kong.log.debug("replacing ........... "..name)

      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
    
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
      
      if v ~= nil then
        navigate_and_apply(decodedbody, name, function (o, p) if o[p] then o[p] = v end end)
      end
      
    end
  
  return decodedbody
end

----------------------------------------------------------------------
----------------------------------------------------------------------
------------ CAN'T MAKE THE ABOVE FUNCTIONS GENERIC ------------------
-------- HAD TO BE PER SERVICE even though there is repeating code ---
-------- because conf. value  can't be stored in a variable ----------
------------- It also can't be passed as a function parameter --------
----------------------------------------------------------------------
----------------------------------------------------------------------


local function transform_json_body_into_soap(conf, body)

    kong.log.debug("ORIGINAL request recieved: "..body)

    -- wrap the request in { "body": request }
    -- soap transformation function looks for this, code breaks without it
    local reqhead = '{"body":'
    local reqtail = '}'
    local body = reqhead..body..reqtail

    -- initiating request method variable to later determine per request based on service
    local req_method = ""

    -- initiating request path variable to later update per request based on service
    local new_path = ""

    -- decode the json string to a lua table
    local parameters = parse_json(body)
    if parameters == nil then
        return false, nil
    end

    ----------------------------------------------------------------------
    -- Consolidating the Plugin for Multiple Services.
    -- So, LOGIC is no longer generic but is specific per service
    ----------------------------------------------------------------------

    ----------------------------------------------------------------------
    -- if request is /account
    ----------------------------------------------------------------------
    if string.find(body, "enquireAccountDetails") then
      kong.log.debug("This is a enquireAccountDetails /account request")

      -- setting method to POST from GET
      kong.service.request.set_method("POST")

      -- set soap method
      req_method = "enquireAccountDetails"
      -- set path
      new_path = "/EnquireAccountDetails/EnquireAccountDetailsInterfaceHttpService"
 
      -- add the request keys with Ghana values
      parameters = add_enquireAccountDetails_keys(conf, parameters)

      -- get country header to replace certain keys based on country
      local country = lower(get_header("country"))   

      if country == "namibia" then
        parameters = replace_namibia_enquireAccountDetails(conf, parameters)

      elseif country == "mozambique" then
        parameters = replace_mozambique_enquireAccountDetails(conf, parameters)

      elseif country == "nigeria" then
        parameters = replace_nigeria_enquireAccountDetails(conf, parameters)

      elseif country == "tanzania" then
        parameters = replace_tanzania_enquireAccountDetails(conf, parameters)

      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- add ban: prefixes to keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","AcctNum","IdNum","IdTyp","CustOrAcctFlag","Entity","AcctSys"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end


      
    ----------------------------------------------------------------------
    -- if request is /account/depositreversal
    ----------------------------------------------------------------------
    elseif string.find(body, "nPBTransferToDepositAccountCorrection") then
      kong.log.debug("This is a nPBTransferToDepositAccountCorrection /account/depositreversal request")

      -- set soap method
      req_method = "nPBTransferToDepositAccountCorrection"
      -- set path
      new_path = "/NPBTransferToDepositAccountCorrection/NPBTransferToDepositAccountCorrectionInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_nPBTransferToDepositAccountCorrection_keys(conf, parameters)

      -- get country header to replace certain keys based on country
      local country = lower(get_header("country"))   

      if country == "namibia" then
        parameters = replace_namibia_nPBTransferToDepositAccountCorrection(conf, parameters)

      elseif country == "mozambique" then
        parameters = replace_mozambique_nPBTransferToDepositAccountCorrection(conf, parameters)

      elseif country == "nigeria" then
        parameters = replace_nigeria_nPBTransferToDepositAccountCorrection(conf, parameters)

      elseif country == "tanzania" then
        parameters = replace_tanzania_nPBTransferToDepositAccountCorrection(conf, parameters)

      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"  (avoiding this)
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseCurAmt", "temp2")
      body = string.gsub(body, "DrDefIntDay", "temp3")
      body = string.gsub(body, "SegNum2", "temp4")
      body = string.gsub(body, "MbrshipJrnlNum", "temp5")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","FrmAcct","Amt","PromoNum","ToAcct","NonValDay","DefIntDay","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","TraceNum","StmtNarr","ChqNum","BkngNum","TrsryRate","MbrshipFlag","MbrshipJrnlDt","MbrshipJrnlNum","NumOfShr","ShareTyp","MembActn1","BalOvrrdInd","CMSTranDesc","CMSRefNum","CMSUsrRefNum","CustIdNum","CustIdTyp","ProcFlag"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseCurAmt")
      body = string.gsub(body, "temp3", "ban:DrDefIntDay")
      body = string.gsub(body, "temp4", "ban:SegNum2")
      body = string.gsub(body, "temp5", "ban:MbrshipJrnlNum")



    ----------------------------------------------------------------------
    -- if request is /account/deposit
    ----------------------------------------------------------------------
  elseif string.find(body, "nPBTransferToDepositAccount") then
    kong.log.debug("This is a nPBTransferToDepositAccount /account/deposit request")

    -- set soap method
    req_method = "nPBTransferToDepositAccount"
    -- set path
    new_path = "/NPBTransferToDepositAccount/NPBTransferToDepositAccountInterfaceHttpService"

    -- add the request keys with Ghana values
    parameters = add_nPBTransferToDepositAccount_keys(conf, parameters)

    -- get country header to replace certain keys based on country
    local country = lower(get_header("country"))   

    if country == "namibia" then
      parameters = replace_namibia_nPBTransferToDepositAccount(conf, parameters)

    elseif country == "mozambique" then
      parameters = replace_mozambique_nPBTransferToDepositAccount(conf, parameters)

    elseif country == "nigeria" then
      parameters = replace_nigeria_nPBTransferToDepositAccount(conf, parameters)

    elseif country == "tanzania" then
      parameters = replace_tanzania_nPBTransferToDepositAccount(conf, parameters)

    end

    -- encode for converting table to string, to perform replace/gsub
    body = cjson.encode(parameters)

    -- replace "test" json values with empty "" strings to avoid nulls in converted json
    body = string.gsub(body, "test", "")

    -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
    -- example while adding "ban:" to "Amt"
    -- it will also add it to "TrnAmt" making it "Trnban:Amt"
    body = string.gsub(body, "MsgTyp", "temp1")
    body = string.gsub(body, "RateTyp", "temp2")
    body = string.gsub(body, "IdTyp", "temp3")
    body = string.gsub(body, "TrnAmt", "temp4")
    body = string.gsub(body, "BaseAmt", "temp5")
    body = string.gsub(body, "Flag1", "temp6")
    body = string.gsub(body, "Flag2", "temp7")
    body = string.gsub(body, "Flag3", "temp8")
    body = string.gsub(body, "Flag4", "temp9")
    body = string.gsub(body, "Flag5", "temp0")
    body = string.gsub(body, "DebtDeferIntDay", "tempa")
    body = string.gsub(body, "DebugFlag", "tempb")
    body = string.gsub(body, "ProcFlag", "tempc")

    -- add the prefix for the remaining unique keys
    local patterns = {"RqHeader","Filler1","Flag","MsgLen","Filler2","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","HdrDt","Filler4","Filler5","Filler6","SprvsrID","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","FrmAcctNum","Amt","PromoNum","ToAcctNum","NonValDay","DeferIntDay","AcctCurCode","TrnCurCode","Comsn","Chng","CurVer","StmtNarr","ChqNum","BkngNum","ConMask","RcptntNum","DisttCode","TrsryRate","JrnlDt","JrnlNum","NumOfUnit","Typ","Actn1","BalOvrWriteInd","CMSTranDesc","CMSRefNum","CMSUserRefNum","IdNum","SrcOfPmt"}
    for i,v in ipairs(patterns) do
        body = string.gsub(body, v, "ban:"..v)
    end

    -- replace temp keys and add ban: prefix
    body = string.gsub(body, "temp1", "ban:MsgTyp")
    body = string.gsub(body, "temp2", "ban:RateTyp")
    body = string.gsub(body, "temp3", "ban:IdTyp")
    body = string.gsub(body, "temp4", "ban:TrnAmt")
    body = string.gsub(body, "temp5", "ban:BaseAmt")
    body = string.gsub(body, "temp6", "ban:Flag1")
    body = string.gsub(body, "temp7", "ban:Flag2")
    body = string.gsub(body, "temp8", "ban:Flag3")
    body = string.gsub(body, "temp9", "ban:Flag4")
    body = string.gsub(body, "temp0", "ban:Flag5")
    body = string.gsub(body, "tempa", "ban:DebtDeferIntDay")
    body = string.gsub(body, "tempb", "ban:DebugFlag")
    body = string.gsub(body, "tempc", "ban:ProcFlag")



    ----------------------------------------------------------------------
    -- 1
    ----------------------------------------------------------------------
    elseif string.find(body, "POSPurchRq") then
      kong.log.debug("This is a pOSPurchase /cbs/account/purchase request")

      -- set soap method
      req_method = "pOSPurchase"
      -- set path
      new_path = "/POSPurchase/POSPurchaseInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_pOSPurchase_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_pOSPurchase_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseAmt", "temp2")
      body = string.gsub(body, "FcyAmt", "temp3")
      body = string.gsub(body, "InfltrAmt", "temp4")
      body = string.gsub(body, "SegNum2", "temp5")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","FrmAcctNum","Amt","PromoNum","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","ExtTermId","PurchDt","BinNum","RetrvRefNum","MerchName","MerchCity","MerchCountryCode","Narr","CardNum","MerchId","AuthznCode","MerchCat","MERISLAMInd","BankCode"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseAmt")
      body = string.gsub(body, "temp3", "ban:FcyAmt")
      body = string.gsub(body, "temp4", "ban:InfltrAmt")
      body = string.gsub(body, "temp5", "ban:SegNum2")

    ----------------------------------------------------------------------
    -- 2
    ----------------------------------------------------------------------
    elseif string.find(body, "POSPurchCorrectionRq") then
      kong.log.debug("This is a pOSPurchaseCorrection /cbs/account/purchasereversal request")

      -- set soap method
      req_method = "pOSPurchaseCorrection"
      -- set path
      new_path = "/POSPurchaseCorrection/POSPurchaseCorrectionInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_pOSPurchaseCorrection_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_pOSPurchaseCorrection_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseAmt", "temp2")
      body = string.gsub(body, "FcyAmt", "temp3")
      body = string.gsub(body, "InfltrAmt", "temp4")
      body = string.gsub(body, "SegNum2", "temp5")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","AcctNum","Amt","PromoNum","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","TraceNum","ExtTermId","PurchDt","BinNum","RetrvRefNum","MerchName","MerchCity","MerchCountryCode","Narr","CardNum","MerchId","AuthznCode","MerchCat","MERISLAMInd","BankCode"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseAmt")
      body = string.gsub(body, "temp3", "ban:FcyAmt")
      body = string.gsub(body, "temp4", "ban:InfltrAmt")
      body = string.gsub(body, "temp5", "ban:SegNum2")

    ----------------------------------------------------------------------
    -- 3
    ----------------------------------------------------------------------
    elseif string.find(body, "POSRfndRq") then
      kong.log.debug("This is a pOSRefund /cbs/account/posrefund request")

      -- set soap method
      req_method = "pOSRefund"
      -- set path
      new_path = "/POSRefund/POSRefundInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_pOSRefund_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_pOSRefund_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "TrnAmtCurCode", "temp2")
      body = string.gsub(body, "BaseCurAmt", "temp3")
      body = string.gsub(body, "FcyAmt", "temp4")
      body = string.gsub(body, "InfltrAmt", "temp5")
      body = string.gsub(body, "SegNum2", "temp6")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","AcctNum","Amt","PromoNum","AcctCurCode","Comsn","Chng","RateTyp","CurVer","ExtTermId","MerchName","MerchCity","MerchCountryCode","Narr","CardNum","MerchId","AuthznCode","MerchCat","MERISLAMInd","BankCode"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:TrnAmtCurCode")
      body = string.gsub(body, "temp3", "ban:BaseCurAmt")
      body = string.gsub(body, "temp4", "ban:FcyAmt")
      body = string.gsub(body, "temp5", "ban:InfltrAmt")
      body = string.gsub(body, "temp6", "ban:SegNum2")

    ----------------------------------------------------------------------
    -- 4
    ----------------------------------------------------------------------
    elseif string.find(body, "ATMCashWdlRq") then
      kong.log.debug("This is a atmCashWithdrawal /cbs/account/atmcashwithdrawal request")

      -- set soap method
      req_method = "atmCashWithdrawal"
      -- set path
      new_path = "/AtmCashWithdrawal/AtmCashWithdrawalInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_atmCashWithdrawal_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_atmCashWithdrawal_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseCurAmt", "temp2")
      body = string.gsub(body, "SegNum2", "temp3")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","AcctNum","Amt","PromoNum","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","Narr","CardNum","AuthznCode","BankCode","TrsryRate"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseCurAmt")
      body = string.gsub(body, "temp3", "ban:SegNum2")

    ----------------------------------------------------------------------
    -- 5
    ----------------------------------------------------------------------
    elseif string.find(body, "ATMCashWdlCorrectionRq") then
      kong.log.debug("This is a aTMCashWithdrawalCorrection /cbs/account/atmcashwithdrawalreversal request")

      -- set soap method
      req_method = "aTMCashWithdrawalCorrection"
      -- set path
      new_path = "/ATMCashWithdrawalCorrection/ATMCashWithdrawalCorrectionInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_aTMCashWithdrawalCorrection_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_aTMCashWithdrawalCorrection_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "TrnAmtCurCode", "temp2")
      body = string.gsub(body, "BaseCurAmt", "temp3")
      body = string.gsub(body, "SegNum2", "temp4")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","AcctNum","Amt","PromoNum","AcctCurCode","Comsn","Chng","RateTyp","CurVer","TraceNum","Narr","CardNum","AuthznCode","BankCode","TrsryRate"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:TrnAmtCurCode")
      body = string.gsub(body, "temp3", "ban:BaseCurAmt")
      body = string.gsub(body, "temp4", "ban:SegNum2")

    ----------------------------------------------------------------------
    -- 6
    ----------------------------------------------------------------------
    elseif string.find(body, "NRTCrInwardRq") then
      kong.log.debug("This is a inwardNRTCredit /cbs/account/inwardcredit request")

      -- set soap method
      req_method = "inwardNRTCredit"
      -- set path
      new_path = "/InwardNRTCredit/InwardNRTCreditInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_inwardNRTCredit_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_inwardNRTCredit_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseAmt", "temp2")
      body = string.gsub(body, "SegNum2", "temp3")
      body = string.gsub(body, "OrdngCustName", "temp4")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","BAcctId","Amt","PromoNum","OBankCode","OBrchCode","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","FacltyNum","UsrRef","StmtNarr","BkngNum","OffsiteAcct","RsnCode","RefNum","BBankCode","BBrchCode","CustName","EFTTranSrvc","NibbsBenBVN","NibbsChannelCode","NibbsBenKYC"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseAmt")
      body = string.gsub(body, "temp3", "ban:SegNum2")
      body = string.gsub(body, "temp4", "ban:OrdngCustName")

    ----------------------------------------------------------------------
    -- 7
    ----------------------------------------------------------------------
    elseif string.find(body, "NRTCrInwardCorrectionRq") then
      kong.log.debug("This is a inwardNRTCreditCorrection /cbs/account/inwardcreditreversal request")

      -- set soap method
      req_method = "inwardNRTCreditCorrection"
      -- set path
      new_path = "/InwardNRTCreditCorrection/InwardNRTCreditCorrectionInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_inwardNRTCreditCorrection_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_inwardNRTCreditCorrection_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseAmt", "temp2")
      body = string.gsub(body, "SegNum2", "temp3")
      body = string.gsub(body, "OrdngCustName", "temp4")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","BAcctId","Amt","PromoNum","OBankCode","OBrchCode","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","FacltyNum","UsrRef","StmtNarr","BkngNum","OffsiteAcct","RsnCode","RefNum","BBankCode","BBrchCode","CustName","EFTTranSrvc"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseAmt")
      body = string.gsub(body, "temp3", "ban:SegNum2")
      body = string.gsub(body, "temp4", "ban:OrdngCustName")

    ----------------------------------------------------------------------
    -- 8
    ----------------------------------------------------------------------
    elseif string.find(body, "EnDrInwardRq") then
      kong.log.debug("This is a inwardEnDebit /cbs/account/inwarddebit request")

      -- set soap method
      req_method = "inwardEnDebit"
      -- set path
      new_path = "/InwardEnDebit/InwardEnDebitInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_inwardEnDebit_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_inwardEnDebit_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseAmt", "temp2")
      body = string.gsub(body, "SegNum2", "temp3")
      body = string.gsub(body, "OrdngCustName", "temp4")
      body = string.gsub(body, "MandatoryRefNum", "temp5")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","SegNum2","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","BAcctId","Amt","PromoNum","OBankCode","OBrchCode","AcctCurCode","TrnAmt","TrnCurCode","BaseAmt","Comsn","Chng","RateTyp","CurVer","FacltyNum","UsrRef","StmtNarr","BkngNum","OffsiteAcct","RsnCode","RefNum","BBankCode","BBrchCode","CustName","EFTTranSrvc","NibbsBenBVN","NibbsChannelCode","NibbsBenKYC"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseAmt")
      body = string.gsub(body, "temp3", "ban:SegNum2")
      body = string.gsub(body, "temp4", "ban:OrdngCustName")
      body = string.gsub(body, "temp5", "ban:MandatoryRefNum")

    ----------------------------------------------------------------------
    -- 9
    ----------------------------------------------------------------------
    elseif string.find(body, "EnDrInwardCorrectionRq") then
      kong.log.debug("This is a inwardEnDebitCorrection /cbs/account/inwarddebitreversal request")

      -- set soap method
      req_method = "inwardEnDebitCorrection"
      -- set path
      new_path = "/InwardEnDebitCorrection/InwardEnDebitCorrectionInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_inwardEnDebitCorrection_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_inwardEnDebitCorrection_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "TrnAmt", "temp1")
      body = string.gsub(body, "BaseAmt", "temp2")
      body = string.gsub(body, "SegNum2", "temp3")
      body = string.gsub(body, "OrdngCustName", "temp4")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","BAcctId","Amt","PromoNum","OBankCode","OBrchCode","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","FacltyNum","UsrRef","StmtNarr","BkngNum","OffsiteAcct","RsnCode","RefNum","BBankCode","BBrchCode","CustName","EFTTranSrvc"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:TrnAmt")
      body = string.gsub(body, "temp2", "ban:BaseAmt")
      body = string.gsub(body, "temp3", "ban:SegNum2")
      body = string.gsub(body, "temp4", "ban:OrdngCustName")

    ----------------------------------------------------------------------
    -- 10
    ----------------------------------------------------------------------
    elseif string.find(body, "NRTCrInwardClrRq") then
      kong.log.debug("This is a inwardNRTCreditClearing /cbs/account/inwardcreditclearing request")
      
      -- set soap method
      req_method = "inwardNRTCreditClearing"
      -- set path
      new_path = "/InwardNRTCreditClearing/InwardNRTCreditClearingInterfaceHttpService"

      -- add the request keys with Ghana values
      parameters = add_inwardNRTCreditClearing_keys(conf, parameters)

      -- get country header to replace certain keys if country is Namibia
      local country = lower(get_header("country"))   
      if country == "namibia" then
        kong.log.debug("replacing keys for Namibia ........... ")
        
        parameters = replace_inwardNRTCreditClearing_value(conf, parameters)
      end

      -- encode for converting table to string, to perform replace/gsub
      body = cjson.encode(parameters)

      -- replace "test" json values with empty "" strings to avoid nulls in converted json
      body = string.gsub(body, "test", "")

      -- repeating sub strings, to avoid incorrect ban: prefixes while replacing
      -- example while adding "ban:" to "Amt"
      -- it will also add it to "TrnAmt" making it "Trnban:Amt"
      body = string.gsub(body, "SegNum2", "temp1")

      -- add the prefix for the remaining unique keys
      local patterns = {"RqHeader","Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","InstNum","BrchNum","WorkstationNum","TellerNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data","AcctNum","Amt","TranDt","RefNum"}
      for i,v in ipairs(patterns) do
          body = string.gsub(body, v, "ban:"..v)
      end

      -- replace temp keys and add ban: prefix
      body = string.gsub(body, "temp1", "ban:SegNum2")
      

    end

    -- print json string
    kong.log.debug("FINAL Request JSON body after adding ban: prefixes "..body)

    -- decode it again to convert string to table, for the soap transformation
    parameters = parse_json(body)

    local req_namespace = "http://schemas.xmlsoap.org/soap/envelope/"
    local req_soap_prefix = "soap"
    local req_soap_version = "1.1"

    -- set the request path
    kong.service.request.set_path(new_path)

    kong.log.debug("new request path is :  "..new_path)

    ----------------------------------------------------------------------
    --------------------request transformation END------------------------
    ----------------------------------------------------------------------

    local body = parameters.body[req_method]
    local encode_args = {}
    local root = {}
    parse_entries(body, root)
    encode_args.namespace = req_namespace
    encode_args.method = req_method
    encode_args.entries = root
    encode_args.soap_prefix = req_soap_prefix
    encode_args.soap_version = req_soap_version
    local soap_doc = soap.encode(encode_args)
    kong.log.debug("Transformed request: "..soap_doc)
    return true, soap_doc
end

function _M.transform_body(conf, body, content_type)
    local is_body_transformed = false

    if content_type == JSON then
        is_body_transformed, body = transform_json_body_into_soap(conf, body)
    end

    return is_body_transformed, body
end

return _M
