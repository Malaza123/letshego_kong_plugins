local helpers = require "spec.helpers"

local PLUGIN_NAME = "soap-request-transformer"

local kong = kong
local request_transformer = require "kong.plugins.soap-request-transformer.access"


  describe(PLUGIN_NAME, function()

    describe("request", function()
      it("converts valid soapy-json", function()

        local config = {}
        config.method = "nPBTransferToDepositAccount"
        config.namespace = "http://schemas.xmlsoap.org/soap/envelope/"
        config.remove_attr_tags = false
        config.soap_prefix = "soapenv"
        config.soap_version = "1.1"

        local json = [[{
          "body": {
              "nPBTransferToDepositAccount": {
                  "XferToDepAcctRq": {
                      "RqHeader": {
                          "Filler1": "",
                          "MsgLen": "",
                          "Filler2": "",
                          "MsgTyp": "",
                          "Filler3": "",
                          "CycNum": "",
                          "MsgNum": "",
                          "SegNum": "",
                          "SegNum2": "",
                          "FrntEndNum": "",
                          "TermNum": "",
                          "InstNum": "0020",
                          "BrchNum": "00001",
                          "WorkstationNum": "",
                          "TellerNum": "999992",
                          "TrnNum": "",
                          "JrnlNum": "",
                          "HdrDt": "",
                          "Filler4": "",
                          "Filler5": "",
                          "Filler6": "",
                          "Flag1": "",
                          "Flag2": "",
                          "Flag3": "",
                          "Flag4": "W",
                          "Flag5": "Y",
                          "SprvsrID": "",
                          "DebugFlag": "",
                          "DebugQue": "",
                          "UUIDSOURCE": "WAL",
                          "UUIDNUM": "",
                          "UUIDSEQNUM": "0001"
                      },
                      "Data": {
                          "FrmAcctNum": "2201036114",
                          "Amt": "100",
                          "PromoNum": "",
                          "ToAcctNum": "22010115138",
                          "NonValDay": "",
                          "DeferIntDay": "",
                          "DebtDeferIntDay": "",
                          "AcctCurCode": "GHS",
                          "TrnAmt": "100",
                          "TrnCurCode": "GHS",
                          "BaseAmt": "",
                          "Comsn": "",
                          "Chng": "",
                          "RateTyp": "",
                          "CurVer": "",
                          "StmtNarr": "Letshego to Wallet Transfer",
                          "ChqNum": "",
                          "BkngNum": "",
                          "ConMask": "",
                          "RcptntNum": "",
                          "DisttCode": "",
                          "TrsryRate": "",
                          "Flag": "",
                          "JrnlDt": "",
                          "JrnlNum": "",
                          "NumOfUnit": "",
                          "Typ": "",
                          "Actn1": "",
                          "BalOvrWriteInd": "",
                          "CMSTranDesc": "",
                          "CMSRefNum": "",
                          "CMSUserRefNum": "",
                          "IdNum": "",
                          "IdTyp": "",
                          "ProcFlag": "",
                          "SrcOfPmt": ""
                      }
                  }
              }
          }
      }
      ]]

        local _,txbody = request_transformer.transform_body(config, json, "application/json")
        print("Request body XML: "..txbody)




      end)
    end)
  end)