local helpers = require "spec.helpers"

local cjson = require("cjson")
local pcall = pcall

local PLUGIN_NAME = "soap-request-transformer"

local kong = kong
local request_transformer = require "kong.plugins.soap-request-transformer.access"
local response_transformer = require "kong.plugins.soap-request-transformer.handler"


  describe(PLUGIN_NAME, function()

    describe("response", function()
      it("converts soap xml response back to json", function()

        local config = {}
        config.method = "nPBTransferToDepositAccount"
        config.namespace = "http://schemas.xmlsoap.org/soap/envelope/"
        config.remove_attr_tags = false
        config.soap_prefix = "soapenv"
        config.soap_version = "1.1"

        local responseXML = [[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Body>
      <dlwmin:nPBTransferToDepositAccountResponse xmlns:dlwmin="http://BaNCS.TCS.com/webservice/NPBTransferToDepositAccountInterface/v1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
         <XferToDepAcctRs xmlns:ns2="http://TCS.BANCS.Adapter/BANCSSchema" xmlns:ns3="http://BaNCS.TCS.com/webservice/NPBTransferToDepositAccountInterface/v1">
            <ns2:RsHeader>
               <ns2:Filler2>00</ns2:Filler2>
               <ns2:Filler3>110</ns2:Filler3>
               <ns2:CycNum>0</ns2:CycNum>
               <ns2:MsgNum>0</ns2:MsgNum>
               <ns2:SegNum>0</ns2:SegNum>
               <ns2:SegNum2>0</ns2:SegNum2>
               <ns2:TermNum>0</ns2:TermNum>
               <ns2:InstNum>8</ns2:InstNum>
               <ns2:BrchNum>1</ns2:BrchNum>
               <ns2:WorkstationNum>0</ns2:WorkstationNum>
               <ns2:TellerNum>999995</ns2:TellerNum>
               <ns2:TrnNum>001045</ns2:TrnNum>
               <ns2:JrnlNum>132848</ns2:JrnlNum>
               <ns2:RsHdrDt>21062021</ns2:RsHdrDt>
               <ns2:Flag1>0</ns2:Flag1>
               <ns2:Flag2>2</ns2:Flag2>
               <ns2:Flag3>0</ns2:Flag3>
               <ns2:Flag4>0</ns2:Flag4>
               <ns2:Flag5>Y</ns2:Flag5>
               <ns2:UUIDSOURCE>WAL</ns2:UUIDSOURCE>
               <ns2:UUIDNUM></ns2:UUIDNUM>
               <ns2:UUIDSEQNUM>1</ns2:UUIDSEQNUM>
               <ns2:OutputType>08</ns2:OutputType>
            </ns2:RsHeader>
            <ns2:Stat>
               <ns2:OkMessage>
                  <ns2:RcptData>O.K.  000132848</ns2:RcptData>
                  <ns2:Filler2>O.K.  000</ns2:Filler2>
                  <ns2:CustNum>132848</ns2:CustNum>
                  <ns2:Filler1>0000</ns2:Filler1>
                  <ns2:AcctNum>132848</ns2:AcctNum>
               </ns2:OkMessage>
            </ns2:Stat>
         </XferToDepAcctRs>
      </dlwmin:nPBTransferToDepositAccountResponse>
   </soapenv:Body>
</soapenv:Envelope>]]

        -- local _,txbody = request_transformer.transform_body(config, json, "application/json")

        local json = response_transformer.convertXMLtoJSON(responseXML, config)
        print("Response json: "..json)
        local status, res = pcall(cjson.decode, json)

        -- assert.equal("London", res["ns2:getCountryResponse"]["ns2:country"]["ns2:capital"])


      end)
    end)
  end)