local access = require "kong.plugins.custom-auto-login.access"


local AutoLogin = {
  VERSION  = "1.0.0",
  PRIORITY = 810,
}


function AutoLogin:access(conf)
  access.execute(conf)
end


return AutoLogin
