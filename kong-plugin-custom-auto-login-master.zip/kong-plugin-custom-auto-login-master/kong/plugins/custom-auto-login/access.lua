local multipart             = require "multipart"
local cjson                 = require "cjson"
local pl_template           = require "pl.template"
local pl_tablex             = require "pl.tablex"

local table_insert          = table.insert
local get_uri_args          = kong.request.get_query
local set_uri_args          = kong.service.request.set_query
local clear_header          = kong.service.request.clear_header
local get_header            = kong.request.get_header
local set_header            = kong.service.request.set_header
local get_headers           = kong.request.get_headers
local set_headers           = kong.service.request.set_headers
local set_method            = kong.service.request.set_method
local set_path              = kong.service.request.set_path
local get_raw_body          = kong.request.get_raw_body
local set_raw_body          = kong.service.request.set_raw_body
local encode_args           = ngx.encode_args
local ngx_decode_args       = ngx.decode_args
local type                  = type
local str_find              = string.find
local pcall                 = pcall
local pairs                 = pairs
local error                 = error
local rawset                = rawset
local pl_copy_table         = pl_tablex.deepcopy

local _M                    = {}

local DEBUG                 = ngx.DEBUG
local CONTENT_LENGTH        = "content-length"
local CONTENT_TYPE          = "content-type"
local HOST                  = "host"
local JSON, MULTI, ENCODED  = "json", "multi_part", "form_encoded"
local EMPTY                 = pl_tablex.readonly({})

local find                  = string.find
local sub                   = string.sub
local gsub                  = string.gsub
local match                 = string.match
local lower                 = string.lower
local next                  = next
local pl                    = require ("pl.pretty")
local ngx_re                = require("ngx.re")
local get_header            = kong.request.get_header
local get_path              = kong.service.request.get_path


local http                  = require "resty.http"
local url                   = require "socket.url"

local kong                  = kong
local cache                 = kong.cache
local time                  = ngx.time
local parse_http_time       = ngx.parse_http_time
local STRATEGY_PATH         = "kong.plugins.proxy-cache.strategies"
local md5                   = ngx.md5



local function read_json_body(body)
  if body then
    return cjson.decode(body)
  end
end

local function toboolean(value)
  if value == "true" then
    return true
  else
    return false
  end
end


local function cast_value(value, value_type)
  if value_type == "number" then
    return tonumber(value)
  elseif value_type == "boolean" then
    return toboolean(value)
  else
    return value
  end
end

local function customiter(config_array)

  if type(config_array) ~= "table" then
    return noop
  end

  return function(config_array, i)
    i = i + 1

    local current_pair = config_array[i]
    if current_pair == nil then -- n + 1
      return nil
    end

    local current_name, current_value = match(current_pair, "^([^:]+):*(.-)$")
    if current_value == "" then
      current_value = nil
    end

    return i, current_name, current_value
  end, config_array, 0
end


-- Navigate json to the value(s) pointed to by path and apply function f to it.
local function navigate_and_apply(conf, json, path, f)
  local head, index, tail

  -- Split into a table with three values, e.g. Results[*].info.name becomes {"Results", "[*]", "info.name"}
  local res = ngx_re.split(path, "(\\[[\\d|\\*]*\\])?\\.", nil, nil, 2)

  if res then
  head = res[1]
  if res[2] and res[3] then
      -- Extract index, e.g. "2" from "[2]"
      index = string.sub(res[2], 2, -2)
      tail = res[3]
  else
      tail = res[2]
  end
  end

  if type(json) == "table" then
    if index == '*' then
      -- Loop through array
      local array = json
      if head ~= '' then
        array = json[head]
      end

      for k, v in ipairs(array) do
        if type(v) == "table" then
          navigate_and_apply(conf, v, tail, f)
        end
      end

    elseif index and index ~= '' then
      -- Access specific array element by index
      index = tonumber(index)
      local element = json[index]
      if head ~= '' and json[head] and type(json[head]) == "table" then
        element = json[head][index]
      end

      navigate_and_apply(conf, element, tail, f)

    elseif tail and tail ~= '' then
      -- Navigate into nested JSON
      navigate_and_apply(conf, json[head], tail, f)

    elseif head and head ~= '' then
      -- Apply passed-in function
      f(json, head)

    end
  end
end


----------------------------------------------------------------------
----------------------------------------------------------------------
------------ CAN'T MAKE THE BELOW FUNCTIONS GENERIC ------------------
-------- HAD TO BE PER COUNTRY even though there is repeating code ---
-------- because conf. value  can't be stored in a variable ----------
------------- It also can't be passed as a function parameter --------
----------------------------------------------------------------------
----------------------------------------------------------------------

---------------------------GHANA-----------------------------------

-- add new key:value to body
local function add_ghana(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_ghana_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end

-- add new key:value to body
local function add_ghana_kong(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_ghana_kongUser_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end


---------------------------NAMIBIA-----------------------------------

-- add new key:value to body
local function add_namibia(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_namibia_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end

-- add new key:value to body
local function add_namibia_kong(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_namibia_kongUser_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end


---------------------------MOZAMBIQUE-----------------------------------

-- add new key:value to body
local function add_mozambique(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_mozambique_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end

-- add new key:value to body
local function add_mozambique_kong(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_mozambique_kongUser_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end


---------------------------NIGERIA-----------------------------------

-- add new key:value to body
local function add_nigeria(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_nigeria_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end

-- add new key:value to body
local function add_nigeria_kong(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_nigeria_kongUser_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end


---------------------------TANZANIA-----------------------------------

-- add new key:value to body
local function add_tanzania(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_tanzania_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end

-- add new key:value to body
local function add_tanzania_kong(conf, decodedbody)
  for i, name, value in customiter(conf.add.mobifin_tanzania_kongUser_json) do
      local v = cjson.encode(value)
      if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
        v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
      end
  
      v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
  
      if v ~= nil then
        navigate_and_apply(conf, decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
      end
  end

  return decodedbody
end


----------------------------------------------------------------------
----------------------------------------------------------------------
------------ CAN'T MAKE THE ABOVE FUNCTIONS GENERIC ------------------
-------- HAD TO BE PER COUNTRY even though there is repeating code ---
-------- because conf. value  can't be stored in a variable ----------
------------- It also can't be passed as a function parameter --------
----------------------------------------------------------------------
----------------------------------------------------------------------

-- remove single key:value to body
local function remove_single_json(conf, decodedbody, name)
  navigate_and_apply(conf, decodedbody, name, function (o, p) o[p] = nil end)

  return decodedbody
end


local function parse_json(body)
  if body then
    local status, res = pcall(cjson.decode, body)
    if status then
      return res
    end
  end
end

------------------------------------------------------------------------------------------
-- set cache -----------------------------------------------
------------------------------------------------------------------------------------------

local function set_cache(conf, jwt_token, cache_key)
  kong.log.debug("setting cache ...... ")

  local strategy = require(STRATEGY_PATH)({
    strategy_name = conf.strategy,
    strategy_opts = conf[conf.strategy],
  })

  local res = {
    body      = jwt_token,
    body_len  = #jwt_token,
    timestamp = time(),
    ttl       = conf.cache_ttl,
  }

  local ok, err = strategy:store(cache_key, res, conf.cache_ttl)
  if not ok then
    kong.log(err)
  end

end

------------------------------------------------------------------------------------------
-- check cache -----------------------------------------------
------------------------------------------------------------------------------------------

local function check_cache(conf, cache_key)
  kong.log.debug("inside check_cache for ...... "..cache_key)

  local cache_value = ""

  -- try to fetch the cached object from the cache key
  local strategy = require(STRATEGY_PATH)({
    strategy_name = conf.strategy,
    strategy_opts = conf[conf.strategy],
  })

  local res, err = strategy:fetch(cache_key)

  if err then
    -- log error and do not set cache key because unable to fetch the value
    kong.log.err(err)
    
  elseif time() - res.timestamp < conf.cache_ttl then
    -- set cache_value from response if cache is valid i.e., not expired
    cache_value = res.body
    -- kong.log.debug("cached token is ......... "..cache_value)

  elseif time() - res.timestamp > conf.cache_ttl then
    -- purge cache
    kong.log.debug("Purging cache with ......... "..cache_key)
    strategy:purge(cache_key)

  end

  return cache_value -- either empty "" or has a value
end


------------------------------------------------------------------------------------------
-- Flush / Purge cache -----------------------------------------------
------------------------------------------------------------------------------------------

local function flush_cache(conf)
  kong.log.debug("inside flush_cache for retry request ..... ")

  -- try to fetch the cached object from the cache key
  local strategy = require(STRATEGY_PATH)({
    strategy_name = conf.strategy,
    strategy_opts = conf[conf.strategy],
  })

  local ok, err = strategy:flush(true)
  if not ok then
    kong.log.err("error in flushing cache data: ", err)
    return false
  else
    return true
  end

end


------------------------------------------------------------------------------------------
-- make the login call and return response -----------------------------------------------
------------------------------------------------------------------------------------------

local function make_login_call(conf)
  local parsed_url = url.parse(conf.login_url)

  local host = parsed_url.host
  local is_https = parsed_url.scheme == "https"
  local port = parsed_url.port or (is_https and 443 or 80)
  local path = parsed_url.path
  local login_method = "POST"

  local login_headers = {
    Accept = "application/json",
    apikey = conf.apikey
  }

  -- country header needed for SMEAO and MOBIFIN
  local country = ""
  -- query params needed only for SMEAO
  local querystring = ""
  -- setting empty body - No body needed for SMEAO
  local encodedbody = ""


  ----------------------------------------------------------------------------------------

  if conf.isGHQRPayments then

    login_headers["Content-Type"] = "application/x-www-form-urlencoded"

    encodedbody = conf.GHQRPayments_Parameters

  end

  ----------------------------------------------------------------------------------------
  if conf.isSMEAO then

    login_headers["Content-Type"] = "application/json"

    country = lower(get_header("country"))
    
    login_method = "GET" -- change method to GET for SMEAO

    -- change query parameters per country
    if country == "namibia" then
      host = conf.host_namibia
      querystring = conf.SMEAO_querystring_namibia

    elseif country == "ghana" then
      host = conf.host_ghana -- we default url used in conf to ghana, but making sure
      querystring = conf.SMEAO_querystring_ghana

    elseif country == "mozambique" then
      host = conf.host_mozambique
      querystring = conf.SMEAO_querystring_mozambique

    elseif country == "nigeria" then
      host = conf.host_nigeria
      querystring = conf.SMEAO_querystring_nigeria

    elseif country == "tanzania" then
      host = conf.host_tanzania
      querystring = conf.SMEAO_querystring_tanzania

    elseif country == "botswana" then
      host = conf.host_botswana
      querystring = conf.SMEAO_querystring_botswana

    elseif country == "lesotho" then
      host = conf.host_lesotho
      querystring = conf.SMEAO_querystring_lesotho

    elseif country == "swaziland" then
      host = conf.host_swaziland
      querystring = conf.SMEAO_querystring_swaziland

    elseif country == "uganda" then
      host = conf.host_uganda
      querystring = conf.SMEAO_querystring_uganda

    elseif country == "kenya" then
      host = conf.host_kenya
      querystring = conf.SMEAO_querystring_kenya

    end

  end

  ----------------------------------------------------------------------------------------
  if conf.isMobiFin then

    login_headers["Content-Type"] = "application/json"

    local country_header = get_header("country")

    if country_header == nil then
      kong.log.debug("MobiFin country header not recieved .. defaulting to Ghana .........")
      country = "ghana"
    else
      country = lower(country_header)
    end
    
    local reqpath = kong.request.get_path()
    -- kong.log.debug("request path is ..... "..reqpath)

    -- flag to different the below two requests which need a different login user
    local reqflag = false
    if string.find(reqpath, "confirmPayment") or string.find(reqpath, "externalBankToWallet") then
      -- kong.log.debug("request is either /confirmPayment or /externalBankToWallet .... will be using KONG user for MobiFin Login")

      reqflag = true
    end

    -- filler json string to initialize transformations -- will be removed later
    encodedbody = '{"data":{"test":"test"}}'
    -- decode to convert to a lua table
    local decodedbody = parse_json(encodedbody)

    -- add respective keys
    -- checking if the request is confirmPayment or externalBankToWallet to use KONG user
    -- and then adding per country
    if reqflag then
      if country == "ghana" then
        login_headers["Authorization"] = conf.MobiFinGhanaAuth_base64encoded
        decodedbody = add_ghana_kong(conf,decodedbody)

      elseif country == "namibia" then
        login_headers["Authorization"] = conf.MobiFinNamibiaAuth_base64encoded
        decodedbody = add_namibia_kong(conf,decodedbody)

      elseif country == "mozambique" then
        login_headers["Authorization"] = conf.MobiFinMozambiqueAuth_base64encoded
        decodedbody = add_mozambique_kong(conf,decodedbody)

      elseif country == "nigeria" then
        login_headers["Authorization"] = conf.MobiFinNigeriaAuth_base64encoded
        decodedbody = add_nigeria_kong(conf,decodedbody)

      elseif country == "tanzania" then
        login_headers["Authorization"] = conf.MobiFinTanzaniaAuth_base64encoded
        decodedbody = add_tanzania_kong(conf,decodedbody)

      end

    -- else if it is a request for the other APIs, we need to use DigitalMall user
    else
      if country == "ghana" then
        login_headers["Authorization"] = conf.MobiFinGhanaAuth_base64encoded
        decodedbody = add_ghana(conf,decodedbody)

      elseif country == "namibia" then
        login_headers["Authorization"] = conf.MobiFinNamibiaAuth_base64encoded
        decodedbody = add_namibia(conf,decodedbody)

      elseif country == "mozambique" then
        login_headers["Authorization"] = conf.MobiFinMozambiqueAuth_base64encoded
        decodedbody = add_mozambique(conf,decodedbody)

      elseif country == "nigeria" then
        login_headers["Authorization"] = conf.MobiFinNigeriaAuth_base64encoded
        decodedbody = add_nigeria(conf,decodedbody)

      elseif country == "tanzania" then
        login_headers["Authorization"] = conf.MobiFinTanzaniaAuth_base64encoded
        decodedbody = add_tanzania(conf,decodedbody)

      end

    end

    -- remove test key
    decodedbody = remove_single_json(conf, decodedbody, "data.test")
    -- encode the body to string
    encodedbody = cjson.encode(decodedbody)

  end


----------------------------------------------------------------------------------------


  -- kong.log.debug("making request - "..login_method.." "..host..":"..port..path..querystring.." - "..encodedbody)
  -- pl.dump(login_headers)

  -- Trigger request
  local client = http.new()

  client:set_timeout(conf.timeout)

  local ok, err = client:connect(host, port)
  if not ok then
    return false, err
  end

  if is_https then
    ok, err = client:ssl_handshake()
    if not ok then
      return false, err
    end
  end

  -- make the request
  local res, err = client:request {
    method = login_method,
    path = path,
    body = encodedbody,
    query = querystring,
    headers = login_headers,
  }

  if not res then
    -- kong.log.debug("FAILED LOGIN CALL for ... "..host..":"..port..path..querystring)
    return false, err
  end

  local status = res.status
  local body = res:read_body()

  kong.log.debug("login response: "..body)

  -- handle mobifin failed login calls
  if conf.isMobiFin then
    local restable = parse_json(body)
    if restable.responseCode ~= "1" then
      return false, body
    end
  end


  ok, err = client:set_keepalive(conf.keepalive)
  if not ok then
    ngx_log(WARN, "failed moving conn to keepalive pool: ", err)
  end

  return status == 200, body
end

------------------------------------------------------------------------------------------
-- extract token from response and set it in the headers ----- ---------------------------
------------------------------------------------------------------------------------------

local function auto_login(conf)
  kong.log.debug("in autologin plugin...................")

  -- Auth token to get after login call
  local token_value = ""
  local cached_token = ""

  local found_in_cache = false

  -- construct cache_key for the respective service per country
  local cache_key = ""
  local current_service = ""

  -- check retry header to decide weather to refresh cache with new token
  local retry_header = get_header("retry")

  -- set a retry flag
  local retry_flag = false

  -- set a flag to check differentiate between the two mobifin services
  -- this is to use a different cache key for the new confirmPayment service
  -- which sends the request with apikey as "Authorization"
  local isNewMobifinService = false

  -- change flag if header is received in the request
  if retry_header == "true" then
    retry_flag = true
  end

  if conf.isSMEAO then
    local country = lower(get_header("country"))
    cache_key = md5("smeao_token_"..country)
    current_service = "SMEAO "..country

  elseif conf.isGHQRPayments then
    cache_key = md5("GHQRPayments_token")
    current_service = "GHQRPayments"
    clear_header("host")

  elseif conf.isMobiFin then
    local country_header = get_header("country")
    local country = ""

    if country_header == nil then
      kong.log.debug("MobiFin country header not recieved .. defaulting to Ghana .........")
      country = "ghana"
      isNewMobifinService = true
    else
      country = lower(country_header)
    end
    
    current_service = "MobiFin "..country

    local req_path = kong.request.get_path()
    local req_flag = false
    if string.find(req_path, "confirmPayment") or string.find(req_path, "externalBankToWallet") then
      req_flag = true
    end

    -- different cache key if token is obtained with Kong user
    if req_flag then
      kong.log.debug("setting cache key with KONG user for mobiFin login")

      if isNewMobifinService then
        cache_key = md5("mobifin_token_2_kong_"..country)
      else
        cache_key = md5("mobifin_token_kong_"..country)
      end

    else
      cache_key = md5("mobifin_token_"..country)
    end

  end

  -- kong.log.debug("cache_key is ...... "..cache_key)
  -- kong.log.debug("upstream service is ...... "..current_service)

  -- check cache
  if conf.cache_control then
    kong.log.debug("cache_control is ...... enabled / true")

    -- flush / purge cache if the request is a retry
    if retry_flag then
      local is_flushed = flush_cache(conf)
      if is_flushed then
        kong.log.debug("cache flushed successfully ........... will fetch new token")
      else
        kong.log.debug("cache flush was unsuccessful ....... ")
      end

    else
      -- check cache for key
      cached_token = check_cache(conf, cache_key)
      -- kong.log.debug("cached_token after checking cache ...... "..cached_token)

      -- set found_in_cache to true if cache is found and is valid i.e., ttl not expired
      -- and also the request is not retried i.e., cache does not need to be refreshed
      if cached_token ~= "" and cached_token ~= nil then
        kong.log.debug("found_in_cache is ...... true and the request is not a retry")

        found_in_cache = true
      end

    end

  else
    kong.log.debug("cache_control is ...... disabled / false")

  end


  -- set token from cache or fetch a new one
  if found_in_cache then
    -- get token from cache and set token_value
    kong.log.debug("cache_control is enabled and key found in cache ........ ")
    token_value = cached_token

  else
    kong.log.debug("cache_control is disabled (or) key not found in cache ........ making login call")
    
    -- MAKE THE LOGIN CALL
    local ok, res = make_login_call(conf)
    if not ok then
      -- retry login call
      -- kong.log.debug("sleep 101ms")
      ngx.sleep(0.101) -- 101ms
      ok, res = make_login_call(conf)
      if not ok then
        kong.log.debug("FAILED login call "..res.." - please retry the request")
        return { err = { status = 500, message = res} }
      end
    end

    -- store decoded json response as table
    local resjson = cjson.decode(res)

    -- extract token from successful login response
    -- add Bearer if request is for mfselite MobiFin
    if conf.isMobiFin then
      kong.log.debug("got Mobifin token..............")
      token_value = resjson.data.access_token
      token_value = "Bearer "..token_value

    elseif conf.isSMEAO then
      kong.log.debug("got SMEAO token..............")
      token_value = resjson.jwtToken

    elseif conf.isGHQRPayments then
      kong.log.debug("got isGHQRPayments token..............")
      token_value = resjson.idToken
      token_value = "Bearer "..token_value

    end

    -- set cache
    if conf.cache_control then
      set_cache(conf, token_value, cache_key)
    end

  end


  -- clear header before proceeding further for confirmPayment
  if isNewMobifinService then
    kong.log.debug("clearing Authorization header before setting the new one ..............")
    clear_header("Authorization")
  end

  -- get request headers
  local reqheaders = get_headers()

  -- add Token to request headers
  reqheaders["Authorization"] = token_value

  --set headers before passing to the next plugin / upstream
  -- kong.log.debug("setting Auth header with .. "..token_value)
  set_headers(reqheaders)

  -- DEBUG
  local new_auth_header = get_header("Authorization")
  -- kong.log.debug("new_auth_header of the request is ............... "..new_auth_header)

end

------------------------------------------------------------------------------------------
--- execute fuctions below ---------------------------------------------------------------
------------------------------------------------------------------------------------------

function _M.execute(conf)
  auto_login(conf)
end

return _M
