local pl_template = require "pl.template"
local tx = require "pl.tablex"
local typedefs = require "kong.db.schema.typedefs"
local validate_header_name = require("kong.tools.utils").validate_header_name

local strategies = require "kong.plugins.proxy-cache.strategies"
local ngx = ngx

local compile_opts = {
  escape = "\xff", -- disable '#' as a valid template escape
}


local function check_shdict(name)
  if not ngx.shared[name] then
    return false, "missing shared dict '" .. name .. "'"
  end

  return true
end


-- entries must have colons to set the key and value apart
local function check_for_value(entry)
  local name, value = entry:match("^([^:]+):*(.-)$")
  if not name or not value or value == "" then
    return false, "key '" ..name.. "' has no value"
  end

  local status, res, err = pcall(pl_template.compile, value, compile_opts)
  if not status or err then
    return false, "value '" .. value ..
            "' is not in supported format, error:" ..
            (status and res or err)
  end
  return true
end


local colon_strings_array = {
  type = "array",
  default = {},
  required = true,
  elements = { type = "string", custom_validator = check_for_value }
}

local add_colon_strings_array_record = {
  type = "record",
  fields = {
    ----------------------DIGITAL MALL USER LOGINS-----------------------------
    { mobifin_ghana_json = colon_strings_array },
    { mobifin_namibia_json = colon_strings_array },
    { mobifin_mozambique_json = colon_strings_array },
    { mobifin_nigeria_json = colon_strings_array },
    { mobifin_tanzania_json = colon_strings_array },
    ----------------------KONG USERS LOGINS-----------------------------------
    { mobifin_ghana_kongUser_json = colon_strings_array },
    { mobifin_namibia_kongUser_json = colon_strings_array },
    { mobifin_mozambique_kongUser_json = colon_strings_array },
    { mobifin_nigeria_kongUser_json = colon_strings_array },
    { mobifin_tanzania_kongUser_json = colon_strings_array },
  },
}


return {
  name = "auto login with cache enabled",
  fields = {
    { config = {
        type = "record",
        fields = {
          { login_url = typedefs.url { required = true} },
          { host_namibia = {type = "string", required = false,}, },
          { host_ghana = {type = "string", required = false,}, },
          { host_nigeria = {type = "string", required = false,}, },
          { host_mozambique = {type = "string", required = false,}, },
          { host_tanzania = {type = "string", required = false,}, },
          { host_botswana = {type = "string", required = false,}, },
          { host_lesotho = {type = "string", required = false,}, },
          { host_swaziland = {type = "string", required = false,}, },
          { host_uganda = {type = "string", required = false,}, },
          { host_kenya = {type = "string", required = false,}, },
          { isSMEAO = {type = "boolean", required = false, default = false,}, },
          { isMobiFin = {type = "boolean", required = false, default = false,}, },
          { isGHQRPayments = {type = "boolean", required = false, default = false,}, },
          { apikey = {type = "string", required = true,}, },
          { add = add_colon_strings_array_record },
          { SMEAO_querystring_ghana = {type = "string", required = false,}, },
          { SMEAO_querystring_namibia = {type = "string", required = false,}, },
          { SMEAO_querystring_nigeria = {type = "string", required = false,}, },
          { SMEAO_querystring_mozambique = {type = "string", required = false,}, },
          { SMEAO_querystring_tanzania = {type = "string", required = false,}, },
          { SMEAO_querystring_botswana = {type = "string", required = false,}, },
          { SMEAO_querystring_lesotho = {type = "string", required = false,}, },
          { SMEAO_querystring_swaziland = {type = "string", required = false,}, },
          { SMEAO_querystring_uganda = {type = "string", required = false,}, },
          { SMEAO_querystring_kenya = {type = "string", required = false,}, },
          { MobiFinGhanaAuth_base64encoded = {type = "string", required = false,}, },
          { MobiFinNamibiaAuth_base64encoded = {type = "string", required = false,}, },
          { MobiFinNigeriaAuth_base64encoded = {type = "string", required = false,}, },
          { MobiFinMozambiqueAuth_base64encoded = {type = "string", required = false,}, },
          { MobiFinTanzaniaAuth_base64encoded = {type = "string", required = false,}, },
          { GHQRPayments_Parameters = {type = "string", required = false,}, },
          { timeout = { type = "integer", default = 10000 } },
          { keepalive = { type = "integer", default = 60000 } },
          { cache_ttl = {
            type = "integer",
            default = 300,
            gt = 0,
          }},
          { strategy = {
            type = "string",
            one_of = strategies.STRATEGY_TYPES,
            required = true,
            default = "memory",
          }},
            { cache_control = {
            type = "boolean",
            default = true,
            required = true,
          }},
          { memory = {
            type = "record",
            fields = {
              { dictionary_name = {
                type = "string",
                required = true,
                default = "kong_db_cache",
              }},
            },
          }},
        }
      },
    },
  },

  entity_checks = {
    { custom_entity_check = {
      field_sources = { "config" },
      fn = function(entity)
        local config = entity.config

        if config.strategy == "memory" then
          local ok, err = check_shdict(config.memory.dictionary_name)
          if not ok then
            return nil, err
          end

        end

        return true
      end
    }},
  },
}
