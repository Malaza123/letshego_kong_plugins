local typedefs = require "kong.db.schema.typedefs"

-- entries must have colons to set the key and value apart
local strings_array = {
    type = "array",
    default = {},
    elements = { type = "string" }
}

return {
    name = "cbs-soap-tranformer",
    fields = {
        {
            consumer = typedefs.no_consumer
        },
        {
            config = {
                type = "record",
                fields = {
                    { add = { type = "record", fields = {
                        
                        -- common keys for all services
                        { common_keys = strings_array },

                        -- EDIT to add new services
                        -- add unique keys in request Data per service

                        -- 1. account-info
                        { account_info = strings_array },

                        -- 2. prompt-amend-cust-details
                        { prompt_amend_cust_details = strings_array },

                        -- 3. loan-details-by-cust-number
                        { loan_details_by_cust_number = strings_array },

                        -- 4. search-cust-by-mobile
                        { search_cust_by_mobile = strings_array },

                        -- 5. search-cust-by-id
                        { search_cust_by_id = strings_array },

                        -- 6. repayment-schedule
                        { repayment_schedule = strings_array },

                        -- 7. statement
                        { statement = strings_array },

                        -- 8. loan-details-by-acc-number 
                        { loan_details_by_acc_number = strings_array },

                        -- 9. reversal
                        { reversal = strings_array },

                        -- 10. kyc-status
                        -- { kyc_status = strings_array },

                        -- 11. balance-info
                        { balance_info = strings_array },

                        -- 12. discharge-via-transfer
                        { discharge_via_transfer = strings_array },

                        -- 13. discharge-figure
                        { discharge_figure = strings_array },

                        -- 14. loan-repay-by-transfer
                        { loan_repay_by_transfer = strings_array },

                        -- 15. transfer-to-no-passbook-depo-acc
                        { transfer_to_no_passbook_depo_acc = strings_array },

                        -- 16. enquire-cust-search-by-name
                        { enquire_cust_search_by_name = strings_array },

                        -- 17. enquire-discharge-figure
                        { enquire_discharge_figure = strings_array },

                         -- 18. transfer-to-deposit
                         { transfer_to_deposit = strings_array },

                        -- 19. rtgs-inbound
                         { rtgs_inbound = strings_array },

                        -- 20. rtgs-reversal
                         { rtgs_reversal = strings_array },

                        -- 21. enquire-user-transaction-details
                         { enquire_user_transaction_details = strings_array },

                        -- 22. amend-cust-details
                        { amend_cust_details = strings_array },

                        -- 23. repayment-schedule-2
                        { repayment_schedule_2 = strings_array },

                        -- 24. deposit-acc-full-statment
                        { deposit_acc_full_statment = strings_array },

                        -- EDIT to add new countries
                        { namibia = strings_array },
                        { tanzania = strings_array },
                        { nigeria = strings_array },
                        { ghana = strings_array },
                        { botswana = strings_array },
                        { kenya = strings_array },
                        { uganda = strings_array },
                        { lesotho = strings_array },
                        { mozambique = strings_array },
                        { eswatini = strings_array },
                        { rwanda = strings_array },
                    }}},
                    -- to remove keys from response
                    { remove = { type = "record", fields = {

                        -- same keys for all other APIs - RsHeader
                        { common_keys = strings_array },

                        -- below ONLY for account-info success response
                        { account_info = strings_array },
                        { nested_account_info = strings_array },
                        
                    }}},    
                },
            },
        },
    }
}