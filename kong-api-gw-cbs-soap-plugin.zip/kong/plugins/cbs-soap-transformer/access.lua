local cjson = require("cjson")
local soap = require("kong.plugins.cbs-soap-transformer.soap")
local kong = kong
local pcall = pcall
local JSON = "application/json"
local insert = table.insert
local _M = {}
local debug = kong.log.debug
local find = string.find
local sub = string.sub
local gsub = string.gsub
local match = string.match
local lower = string.lower
local next = next
local pl = require ("pl.pretty")
local ngx_re = require("ngx.re")
local get_header = kong.request.get_header
local set_header = kong.service.request.set_header


local function parse_json(body)
    if body then
        local status, res = pcall(cjson.decode, body)
        if status then
            return res
        end
    end
end


local function parse_entries(e, parent)
    if type(e) == "table" then
        for k, v in pairs(e) do
            local el = { ['tag'] = k }
            insert(parent, el)
            parse_entries(v, el)
        end
    else
        insert(parent, e)
    end
end

local function read_json_body(body)
    if body then
      return cjson.decode(body)
    end
end

local function toboolean(value)
    if value == "true" then
      return true
    else
      return false
    end
end


local function cast_value(value, value_type)
    if value_type == "number" then
      return tonumber(value)
    elseif value_type == "boolean" then
      return toboolean(value)
    else
      return value
    end
end

local function iter(config_array)

    if type(config_array) ~= "table" then
      return noop
    end
  
    return function(config_array, i)
      i = i + 1
  
      local current_pair = config_array[i]
      if current_pair == nil then -- n + 1
        return nil
      end
  
      local current_name, current_value = match(current_pair, "^([^:]+):*(.-)$")
      if current_value == "" then
        current_value = nil
      end
  
      return i, current_name, current_value
    end, config_array, 0
end


-- Navigate json to the value(s) pointed to by path and apply function f to it.
local function navigate_and_apply(json, path, f)
    local head, index, tail
  
    -- Split into a table with three values, e.g. Results[*].info.name becomes {"Results", "[*]", "info.name"}
    local res = ngx_re.split(path, "(\\[[\\d|\\*]*\\])?\\.", nil, nil, 2)

    if res then
    head = res[1]
    if res[2] and res[3] then
        -- Extract index, e.g. "2" from "[2]"
        index = string.sub(res[2], 2, -2)
        tail = res[3]
    else
        tail = res[2]
    end
    end
  
    if type(json) == "table" then
      if index == '*' then
        -- Loop through array
        local array = json
        if head ~= '' then
          array = json[head]
        end
  
        for k, v in ipairs(array) do
          if type(v) == "table" then
            navigate_and_apply(v, tail, f)
          end
        end
  
      elseif index and index ~= '' then
        -- Access specific array element by index
        index = tonumber(index)
        local element = json[index]
        if head ~= '' and json[head] and type(json[head]) == "table" then
          element = json[head][index]
        end
  
        navigate_and_apply(element, tail, f)
  
      elseif tail and tail ~= '' then
        -- Navigate into nested JSON
        navigate_and_apply(json[head], tail, f)
  
      elseif head and head ~= '' then
        -- Apply passed-in function
        f(json, head)
  
      end
    end
end

---------------------------------------------------------------------------------

-- remove single key:value from body
local function remove_single_json(decodedbody, name)
  navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)

  return decodedbody
end

-- remove key:value from body
local function remove_json(decodedbody, requestKeysToRemove)

  for i,v in ipairs(requestKeysToRemove) do
    navigate_and_apply(decodedbody, "Data."..v, function (o, p) o[p] = nil end)
  end

  return decodedbody
end

local function add_Keys(decodedbody, Keys)
  for i, name, value in iter(Keys) do

    local v = cjson.encode(value)
    if v and sub(v, 1, 1) == [["]] and sub(v, -1, -1) == [["]] then
      v = gsub(sub(v, 2, -2), [[\"]], [["]]) -- To prevent having double encoded quotes
    end
  
    v = v and gsub(v, [[\/]], [[/]]) -- To prevent having double encoded slashes
    
    if v ~= nil then
      navigate_and_apply(decodedbody, name, function (o, p) if not o[p] then o[p] = v end end)
    end

  end
  return decodedbody
end

local function add_temps(body, repeatingKeysforBan)
  -- example make TrnAmt as temp1
  for i, v in ipairs(repeatingKeysforBan) do
    body = gsub(body, v, "temp"..i)
  end

  return body
end

local function replace_temps(body, repeatingKeysforBan)
  -- example make temp1 as ban:TrnAmt
  for i, v in ipairs(repeatingKeysforBan) do
    body = gsub(body, "temp"..i, "ban:"..v)
  end
  
  return body
end

----------------------------------------------------------------------
-- EDIT BELOW TO ADD NEW SERVICES ------------------------------------
----------------------------------------------------------------------

-- add new key:value to body
local function add_service_keys(conf, decodedbody)
  -- get x-method header
  local xmethod = lower(get_header("x-method")) 
  local serviceKeys = {} -- decide per service below
  local commonKeys = conf.add.common_keys -- common keys for all

  -- select the keys to add by service header
  -- 1. account-info
  if xmethod == "account-info" then
    serviceKeys = conf.add.account_info

  -- 2. prompt-amend-cust-details
  elseif xmethod == "prompt-amend-cust-details" then
    serviceKeys = conf.add.prompt_amend_cust_details

  -- 3. loan-details-by-cust-number
  elseif xmethod == "loan-details-by-cust-number" then
    serviceKeys = conf.add.loan_details_by_cust_number

  -- 4. search-cust-by-mobile
  elseif xmethod == "search-cust-by-mobile" then
    serviceKeys = conf.add.search_cust_by_mobile

  -- 5. search-cust-by-id
  elseif xmethod == "search-cust-by-id" then
    serviceKeys = conf.add.search_cust_by_id

  -- 6. repayment-schedule
  elseif xmethod == "repayment-schedule" then
    serviceKeys = conf.add.repayment_schedule
    
  -- 7. statement
  elseif xmethod == "statement" then
    serviceKeys = conf.add.statement

  -- 8. loan-details-by-acc-number
  elseif xmethod == "loan-details-by-acc-number" then
    serviceKeys = conf.add.loan_details_by_acc_number

  -- 9. reversal
  elseif xmethod == "reversal" then
    serviceKeys = conf.add.reversal

  -- 10. kyc-status -- UNIQUE service, see modify_kyc_request

  -- 11. balance-info
  elseif xmethod == "balance-info" then
    serviceKeys = conf.add.balance_info

  -- 12. discharge-via-transfer
  elseif xmethod == "discharge-via-transfer" then
    serviceKeys = conf.add.discharge_via_transfer

  -- 13. discharge-figure
  elseif xmethod == "discharge-figure" then
    serviceKeys = conf.add.discharge_figure

  -- 14. loan-repay-by-transfer
  elseif xmethod == "loan-repay-by-transfer" then
    serviceKeys = conf.add.loan_repay_by_transfer

  -- 15. transfer-to-no-passbook-depo-acc
  elseif xmethod == "transfer-to-no-passbook-depo-acc" then
    serviceKeys = conf.add.transfer_to_no_passbook_depo_acc

  -- 16. enquire-cust-search-by-name
  elseif xmethod == "enquire-cust-search-by-name" then
    serviceKeys = conf.add.enquire_cust_search_by_name

  -- 17. enquire-discharge-figure
  elseif xmethod == "enquire-discharge-figure" then
    serviceKeys = conf.add.enquire_discharge_figure

  -- 18. transfer-to-deposit
  elseif xmethod == "transfer-to-deposit" then
    serviceKeys = conf.add.transfer_to_deposit

  -- 19. rtgs-inbound
  elseif xmethod == "rtgs-inbound" then
    serviceKeys = conf.add.rtgs_inbound

  -- 20. rtgs-reversal
  elseif xmethod == "rtgs-reversal" then
    serviceKeys = conf.add.rtgs_reversal

  -- 21. enquire-user-transaction-details
  elseif xmethod == "enquire-user-transaction-details" then
    serviceKeys = conf.add.enquire_user_transaction_details

  -- 22. amend-cust-details
  elseif xmethod == "amend-cust-details" then
    serviceKeys = conf.add.amend_cust_details

  -- 23. repayment-schedule-2
  elseif xmethod == "repayment-schedule-2" then
    serviceKeys = conf.add.repayment_schedule_2

  -- 24. deposit-acc-full-statment
  elseif xmethod == "deposit-acc-full-statment" then
    serviceKeys = conf.add.deposit_acc_full_statment

  end

  decodedbody = add_Keys(decodedbody, serviceKeys)
  decodedbody = add_Keys(decodedbody, commonKeys)

  return decodedbody
end

----------------------------------------------------------------------
-- EDIT BELOW TO ADD NEW COUNTRIES -----------------------------------
----------------------------------------------------------------------

-- add key:value to body
local function add_country_keys(conf, decodedbody)
  -- get country header to add certain keys based on country
  local country = lower(get_header("x-country")) 
  local countryKeys = {} -- decide per service below

  if country == "namibia" then
    countryKeys = conf.add.namibia

  elseif country == "mozambique" then
    countryKeys = conf.add.mozambique

  elseif country == "nigeria" then
    countryKeys = conf.add.nigeria

  elseif country == "tanzania" then
    countryKeys = conf.add.tanzania

  elseif country == "ghana" then
    countryKeys = conf.add.ghana

  elseif country == "botswana" then
    countryKeys = conf.add.botswana

  elseif country == "kenya" then
    countryKeys = conf.add.kenya

  elseif country == "uganda" then
    countryKeys = conf.add.uganda

  elseif country == "lesotho" then
    countryKeys = conf.add.lesotho

  elseif country == "eswatini" then
    countryKeys = conf.add.eswatini

  elseif country == "rwanda" then
    countryKeys = conf.add.rwanda

  end
  
  decodedbody = add_Keys(decodedbody, countryKeys)
  
  return decodedbody
end


local function add_ban_to_header_keys(body)

  local headerKeys = {"Filler1","MsgLen","Filler2","MsgTyp","Filler3","CycNum","MsgNum","SegNum","FrntEndNum","TermNum","WorkstationNum","TrnNum","JrnlNum","HdrDt","Filler4","Filler5","Filler6","Flag1","Flag2","Flag3","Flag4","Flag5","SprvsrID","DebugFlag","DebugQue","UUIDSOURCE","UUIDNUM","UUIDSEQNUM","Data"}

  for i,v in ipairs(headerKeys) do
    body = gsub(body, v, "ban:"..v)
  end

  return body
end

local function modify_request(conf, body, requestKeysToRemove, uniqueDataKeysToAdd, repeatingKeysforBan)
  -- get x-method header
  local xmethod = lower(get_header("x-method")) 

  -- decode the json string to a lua table
  local parameters = parse_json(body)
  if parameters == nil then
      return false, nil
  end
  -- remove unused keys from the original request body
  parameters = remove_json(parameters, requestKeysToRemove)
  -- add keys needed for SOAP request
  parameters = add_service_keys(conf, parameters) 
  -- encode for converting table to string, to perform replace/gsub
  body = cjson.encode(parameters)
  -- replace "test" json values with empty "" strings to avoid nulls in converted json
  body = gsub(body, "test", "")
  -- reversal service has repeating common keys liks Amt, TrnAmt
  -- so including both would result in ban:Amt and Trnban:Amt
  -- Hence, to avoid this, saving conflicting keys to be replaced separately
  body = add_temps(body, repeatingKeysforBan)
  -- add ban: prefix to common keys for all services
  body = add_ban_to_header_keys(body)
  -- add ban: prefixes to unique keys per service in request Data block
  for i,v in ipairs(uniqueDataKeysToAdd) do
      body = gsub(body, v, "ban:"..v)
  end
  -- adding the temp keys back to body
  body = replace_temps(body, repeatingKeysforBan)

  return body
end

local function modify_kyc_request(conf, body)

  -- decode the json string to a lua table
  local parameters = parse_json(body)
  if parameters == nil then
      return false, nil
  end

  local person_id = parameters.person_id
  local kyc_username,kyc_pass,Kyc_type = 'SvcBW00','SvcBW00','BW00'

  local soap_doc = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:kyc="http://kyc.impl.ws.sironkyc.tonbeller.com" xmlns:xsd="http://in.data.kyc.impl.ws.sironkyc.tonbeller.com/xsd"><soapenv:Header/><soapenv:Body><kyc:getPersonStatus><kyc:loginData><xsd:pass>'..
                    kyc_pass..'</xsd:pass><xsd:type>'..
                    Kyc_type..'</xsd:type><xsd:userName>'..
                    kyc_username..'</xsd:userName></kyc:loginData><kyc:searchMode/><kyc:personIDs>'..
                    person_id..'</kyc:personIDs></kyc:getPersonStatus></soapenv:Body></soapenv:Envelope>'

  return soap_doc
end

----------------------------------------------------------------------

local function transform_json_body_into_soap(conf, body)
  -- initiating request method variable to later determine per request based on service
  local req_method,req_name = "",""
  -- initiating request path variable to later update per request based on service
  local new_path,soap_doc = "",""
  -- get x-method header
  local xmethod = get_header("x-method")
  if not xmethod == nil then
    xmethod = lower(xmethod)
  end
  -- get country header to add certain keys based on country
  local country = get_header("x-country")
  if not country == nil then
    country = lower(country)  
  end
  -- declare JSON table array for later use
  local parameters,requestKeysToRemove,uniqueDataKeysToAdd,repeatingKeysforBan = {},{},{},{}
  -- check if request is kyc
  local isKyc = (xmethod == "kyc-status")
  if not isKyc then
    -- putting request inside Data blocks for rest of services
    body = '{"RqHeader":{"dummy":"dummy"},"Data":'..body..'}'
  end

  ----------------------------------------------------------------------
  -- EDIT BELOW TO ADD NEW SERVICES ------------------------------------
  ----------------------------------------------------------------------
  -- 1. account_info - This service logic is different than others
  ------------------------------------ see next service for others
  ----------------------------------------------------------------------
  if xmethod == "account-info" then
    debug("This is an enquireAccountDetails account-info request ......... ")
    -- set soap method
    req_method = "enquireAccountDetails"
    -- set request name for SOAP XML body
    req_name = "AcctDetailsInqRq"
    -- set path
    new_path = "/EnquireAccountDetails/EnquireAccountDetailsInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"customer_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","IdNum","IdTyp","CustOrAcctFlag","Entity","AcctSys"}

  ----------------------------------------------------------------------
  -- 2. prompt-amend-cust-details
  ----------------------------------------------------------------------
  elseif xmethod == "prompt-amend-cust-details" then
    debug("This is a prompt-amend-cust-details request ......... ")
    -- set soap method
    req_method = "promptAmendCustomerDetails"
    -- set request name for SOAP XML body
    req_name = "ModCustDetailsPrmptRq"
    -- set path
    new_path = "/PromptAmendCustomerDetails/PromptAmendCustomerDetailsInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "customer_number", "CustNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"account_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"CustNum","Opt"}

  ----------------------------------------------------------------------
  -- 3. loan-details-by-cust-number
  ----------------------------------------------------------------------
  elseif xmethod == "loan-details-by-cust-number" then
    debug("This is a loan-details-by-cust-number request ......... ")
    -- set soap method
    req_method = "enquireAccountDetails"
    -- set request name for SOAP XML body
    req_name = "AcctDetailsInqRq"
    -- set path
    new_path = "/EnquireAccountDetails/EnquireAccountDetailsInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "customer_number", "AcctNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"account_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","IdNum","IdTyp","CustOrAcctFlag","Entity","AcctSys"}

  ----------------------------------------------------------------------
  -- 4. search-cust-by-mobile
  ----------------------------------------------------------------------
  elseif xmethod == "search-cust-by-mobile" then
    debug("This is a search-cust-by-mobile request ......... ")
    -- set soap method
    req_method = "enquireCustomerSearchByName"
    -- set request name for SOAP XML body
    req_name = "CustSearchByNameInqRq"
    -- set path
    new_path = "/EnquireCustomerSearchByName/EnquireCustomerSearchByNameInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "mobile_number", "MobileNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"account_number","customer_number","id_type","id_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"CustLastName","CustFirstName","CustAddr","PstCode","HomePhnNum","StrtFrm","LangCode","CustMidName","IdNum","IdTyp","LastCustNum","Entity","VehicleNum","Name1","NameTyp1","MobileNum"}

  ----------------------------------------------------------------------
  -- 5. search-cust-by-id
  ----------------------------------------------------------------------
  elseif xmethod == "search-cust-by-id" then
    debug("This is a search-cust-by-id request ......... ")
    -- set soap method
    req_method = "enquireCustomerSearchByName"
    -- set request name for SOAP XML body
    req_name = "CustSearchByNameInqRq"
    -- set path
    new_path = "/EnquireCustomerSearchByName/EnquireCustomerSearchByNameInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "id_type", "IdTyp")
    body = gsub(body, "id_number","IdNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"mobile_number","account_number","customer_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"CustLastName","CustFirstName","CustAddr","PstCode","HomePhnNum","StrtFrm","LangCode","CustMidName","IdNum","IdTyp","LastCustNum","Entity","VehicleNum","Name1","NameTyp1","MobileNum"}

  ----------------------------------------------------------------------
  -- 6. repayment-schedule
  ----------------------------------------------------------------------
  elseif xmethod == "repayment-schedule" then
    debug("This is a repayment-schedule request ......... ")
    -- set soap method
    req_method = "enquireRepaymentSchedule"
    -- set request name for SOAP XML body
    req_name = "RepmtSchdInqRq"
    -- set path
    new_path = "/EnquireRepaymentSchedule/EnquireRepaymentScheduleInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"customer_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","Opt"}

  ----------------------------------------------------------------------
  -- 7. statement
  ----------------------------------------------------------------------
  elseif xmethod == "statement" then
    debug("This is a statement request ......... ")
    -- set soap method
    req_method = "printDepositAccountStatement"
    -- set request name for SOAP XML body
    req_name = "DepAcctStmtPrntRq"
    -- set path
    new_path = "/PrintDepositAccountStatement/PrintDepositAccountStatementInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"customer_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","FrmDt","SkipNumOfTrn","RsFmt","ToDt","BrkdwnCnsldtTrn","PromoNum","ExmptChrg","StmtRef"}
    -- add ban: to repeating keys avoiding Prtban:FrnDt as just "FrmDt" key exists separately
    repeatingKeysforBan = {"PrtFrmDt"}
    
  ----------------------------------------------------------------------
  -- 8. loan-details-by-acc-number 
  ----------------------------------------------------------------------
  elseif xmethod == "loan-details-by-acc-number" then
    debug("This is an enquireLoanAccount loan-details-by-acc-number request ......... ")
    -- set soap method
    req_method = "enquireLoanAccount"
    -- set request name for SOAP XML body
    req_name = "LoanAcctInqRq"
    -- set path
    new_path = "/EnquireLoanAccount/EnquireLoanAccountInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"customer_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","Opt","Yr","TrnCode","VNum","LoanPromo"}

  ----------------------------------------------------------------------
  -- 9. reversal
  ----------------------------------------------------------------------
  elseif xmethod == "reversal" then
    debug("This is a reversal request ......... ")
    -- set soap method
    req_method = "nPBTransferToDepositAccountCorrection"
    -- set request name for SOAP XML body
    req_name = "XferToDepAcctCorrectionRq"
    -- set path
    new_path = "/NPBTransferToDepositAccountCorrection/NPBTransferToDepositAccountCorrectionInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "from_account", "FrmAcct")
    body = gsub(body, "transaction_amount", "TrnAmt")
    body = gsub(body, "promo_number", "PromoNum")
    body = gsub(body, "to_account", "ToAcct")
    body = gsub(body, "amount", "Amt")
    body = gsub(body, "trace_number", "TraceNum")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"FrmAcct","Amt","PromoNum","ToAcct","NonValDay","DefIntDay","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","TraceNum","StmtNarr","ChqNum","BkngNum","TrsryRate","Mbrship","NumOfShr","ShareTyp","MembActn1","BalOvrrdInd","CMS","Cust","ProcFlag"}
    -- add ban: to repeating keys avoiding Trnban:Amt as just "Amt" key exists separately
    repeatingKeysforBan = {"TrnAmt","BaseCurAmt","DrDefIntDay","MbrshipJrnlNum"}

  ----------------------------------------------------------------------
  -- 10. kyc-status - THIS IS DIFFERENT THAN OTHER SOAP REQUESTS
  ----------------------------------------------------------------------
  elseif isKyc then
    debug("This is a kyc-status request ......... ")
    -- set soap method
    req_method = "kyc:getPersonStatus"
    -- set scheme - change protocol to http
    kong.service.request.set_scheme("http")
    -- set SOAPAction
    set_header("SOAPAction", "getPersonStatus")
    --set path
    new_path = "/axis2/services/KYCService01.KYCService01HttpSoap12Endpoint/"
  
  ----------------------------------------------------------------------
  -- 11. balance-info
  ----------------------------------------------------------------------
  elseif xmethod == "balance-info" then
    debug("This is a balance-info request ......... ")
    -- set soap method
    req_method = "enquireDepositAccount"
    -- set request name for SOAP XML body
    req_name = "DepAcctInqRq"
    -- set path
    new_path = "/EnquireDepositAccount/EnquireDepositAccountInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    body = gsub(body, "promo_code", "DepPromo")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","Opt","FrmDt","ToDt","StatStcsForYr","DepPromo"}
    -- add ban: to repeating keys avoiding PrdBalban:Opt1 as just "Opt" key exists separately
    repeatingKeysforBan = {"PrdBalOpt1","PrdBalOpt2"}

  ----------------------------------------------------------------------
  -- 12. discharge-via-transfer
  ----------------------------------------------------------------------
  elseif xmethod == "discharge-via-transfer" then
    debug("This is a discharge-via-transfer request ......... ")
    -- set soap method
    req_method = "dischargeViaTransfer"
    -- set request name for SOAP XML body
    req_name = "DischrgViaXferRq"
    -- set path
    new_path = "/DischargeViaTransfer/DischargeViaTransferInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "transfer_account_number", "XferAcctNum")
    body = gsub(body, "discharge_amount", "DischrgAmt")
    body = gsub(body, "waive_discharge_penalty", "WaiveDischrgPnlty")
    body = gsub(body, "transaction_date", "TrnDt")
    body = gsub(body, "account_number", "AcctNum")
    body = gsub(body, "account_currency_code", "AcctCurCode")
    body = gsub(body, "transaction_currency_code", "TrnCurCode")
    body = gsub(body, "base_currency_amount", "BaseCurAmt")
    body = gsub(body, "rate_type", "RateType")
    body = gsub(body, "statement_narration", "StmtNarr")
    body = gsub(body, "account_sys", "AcctSys")
    body = gsub(body, "discharge_reason", "DischrgRsn")
    body = gsub(body, "closure_opt", "ClosureOpt")
    body = gsub(body, "nostroDr_amount", "NostroDrAmt")
    body = gsub(body, "recon_required_flag", "ReconReqdFlag")
    body = gsub(body, "amount", "Amt")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","Amt","Closure","SubLedgCode","WaiveDischrgPnlty","IntRebatePrcntToCust","TrnDt","PromoNum","AcctCurCode","TrnCurCode","Comsn1","Chng","RateType","CurVer","StmtNarr","AcctSys","BkngNum","DischrgRsn","PstProfitOrLossFlag","PnltyDay","CashBackRebatePctg","ChngOfSrvc","SrcOfPmt","SupplierAcctName","EstDischrg","ReconReqdFlag","ReconRefNum"}
    -- add ban: to repeating keys avoiding Xferban:AcctNum as just "AcctNum" key exists separately
    repeatingKeysforBan = {"ChngOfSrvc","XferAcctNum","ProfitOrLossAcctNum","NostroDrAmt","PartialClosureAmt","BaseCurAmt","DiscntAmt","DischrgAmt"}

  ----------------------------------------------------------------------
  -- 13. discharge-figure
  ----------------------------------------------------------------------
  elseif xmethod == "discharge-figure" then
    debug("This is a discharge-figure request ......... ")
    -- set soap method
    req_method = "enquireDischargeFigure"
    -- set request name for SOAP XML body
    req_name = "DischrgFigureInqRq"
    -- set path
    new_path = "/EnquireDischargeFigure/EnquireDischargeFigureInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    body = gsub(body, "waive_discharge_penalty", "WaiveDischrgPnlty")
    body = gsub(body, "interest_rebate_percent", "IntRebatePrcnt")
    body = gsub(body, "discharge_date", "DischrgDt")
    body = gsub(body, "discharge_reason", "DischrgRsn")
    body = gsub(body, "closure_opt", "ClosureOpt")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","ExpryDt","SavPendDischrgStat","WaiveDischrgPnlty","IntRebatePrcnt","DischrgDt","PromoNum","DischrgRsn","PnltyDay","CashBckRebatePrcnt","ClosureOpt","ClosureTyp","PartialClosureAmt","Ind","SupplierAcctName"}
    -- add ban: to repeating keys avoiding Xferban:AcctNum as just "AcctNum" key exists separately
    -- repeatingKeysforBan = {}

  ----------------------------------------------------------------------
  -- 14. loan-repay-by-transfer
  ----------------------------------------------------------------------
  elseif xmethod == "loan-repay-by-transfer" then
    debug("This is a loan-repay-by-transfer request ......... ")
    -- set soap method
    req_method = "loanRepaymentByTransfer"
    -- set request name for SOAP XML body
    req_name = "RepmtByXferRq"
    -- set path
    new_path = "/LoanRepaymentByTransfer/LoanRepaymentByTransferInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "to_account_number", "ToAcctNum")
    body = gsub(body, "from_account_number", "FrmAcctNum")
    body = gsub(body, "account_currency_code", "AcctCurCode")
    body = gsub(body, "transaction_amount", "TrnAmt")
    body = gsub(body, "transaction_currency_code", "TrnCurCode")
    body = gsub(body, "statement_narration", "StmtNarr")
    body = gsub(body, "sys", "Sys")
    body = gsub(body, "epf_payment_2", "EPFPmt2")
    body = gsub(body, "recon_flag", "ReconFlg")
    body = gsub(body, "recon_journal", "ReconJrnl")
    body = gsub(body, "amount", "Amt")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"Amt","Recon","Rjctn","ToAcctNum","LedgCode","SubLedgCode","PromoNum","FrmAcctNum","AcctCurCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","StmtNarr","Sys","EPFPmt2","Instlmnt","FeesDue","LpiDue","AdvPay","PrinciplePay","PayBreakTtl","BkngNum","SchdReturnInq","PriorityTyp","NegoStl","ProcFlag","SrcOfPmt","Filler"}
    -- add ban: to repeating keys avoiding Xferban:AcctNum as just "AcctNum" key exists separately
    repeatingKeysforBan = {"TrnAmt","BaseCurAmt","PrincipleAmt","LpiAmt","IntAmt","FeesAmt","ApprvdAmt"}

  ----------------------------------------------------------------------
  -- 15. transfer-to-no-passbook-depo-acc
  ----------------------------------------------------------------------
  elseif xmethod == "transfer-to-no-passbook-depo-acc" then
    debug("This is a transfer-to-no-passbook-depo-acc ......... ")
    -- set soap method
    req_method = "transferToNoPassbookDepositAccount"
    -- set request name for SOAP XML body
    req_name = "XferToNoPsbkDepAcctRq"
    -- set path
    new_path = "/TransferToNoPassbookDepositAccount/TransferToNoPassbookDepositAccountInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "to_deposit_number", "ToDepAcct")
    body = gsub(body, "bgl_account_number", "BGLAcctNum")
    body = gsub(body, "account_currency_code1", "AcctCurCode1")
    body = gsub(body, "account_currency_code2", "AcctCurCode2")
    body = gsub(body, "statement_narration", "StmtNarr")
    body = gsub(body, "rate_type", "RateTyp1")
    body = gsub(body, "recon_flag", "ReconFlg")
    body = gsub(body, "recon_journal", "ReconJrnl")
    body = gsub(body, "recon_required_flag", "ReconReqdFlag")
    body = gsub(body, "amount_1", "Amt1")
    body = gsub(body, "recon_reference_number", "ReconRefNum")
    body = gsub(body, "base_currency_amount", "BaseCurAmt")
    body = gsub(body, "amount", "Amt")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"ToDepAcct","Amt","PromoNum","RefNum","BGLAcctNum","Descptn","AcctCurCode1","Amt1","AcctCurCode2","Comsn1","Chg1","RateTyp1","CurVer","SDVAcct","SDVFlag","MnemCode","SubscrbrIdNum","DefIntDay","NonValDay","StmtNarr","ReconReqdFlag","BkngNum","MRN","VchrNum","SubscrbrIdTyp","CostCentreCode","SrcOfPmt","ReconFlg","ReconJrnl","ReconDt","Filler","RjctnBankCode","RjctnPayDt","RjctnBrchCode"}
    -- add ban: to repeating keys avoiding Xferban:AcctNum as just "AcctNum" key exists separately
    repeatingKeysforBan = {"Filler","Amt1","BaseCurAmt","RjctnJrnlNum","DrDefIntDay","ReconRefNum","FWRRefNum","DrTrnDescptn","RjctnMsgTyp"}
    
  ----------------------------------------------------------------------
  -- 16. enquire-cust-search-by-name
  ----------------------------------------------------------------------
  elseif xmethod == "enquire-cust-search-by-name" then
    debug("This is a enquire-cust-search-by-name request ......... ")
    -- set soap method
    req_method = "enquireCustomerSearchByName"
    -- set request name for SOAP XML body
    req_name = "CustSearchByNameInqRq"
    -- set path
    new_path = "/EnquireCustomerSearchByName/EnquireCustomerSearchByNameInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "mobile_number", "MobileNum")
    -- remove unused keys from the original request body
    requestKeysToRemove = {"account_number","customer_number","id_type","id_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"CustLastName","CustFirstName","CustAddr","PstCode","HomePhnNum","StrtFrm","LangCode","CustMidName","IdNum","IdTyp","LastCustNum","Entity","VehicleNum","Name1","NameTyp1","MobileNum"}
    
  ----------------------------------------------------------------------
  -- 17. enquire-discharge-figure
  ----------------------------------------------------------------------
  elseif xmethod == "enquire-discharge-figure" then
    debug("This is a enquire-discharge-figure request ......... ")
    -- set soap method
    req_method = "enquireDischargeFigure"
    -- set request name for SOAP XML body
    req_name = "DischrgFigureInqRq"
    -- set path
    new_path = "/EnquireDischargeFigure/EnquireDischargeFigureInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    body = gsub(body, "waive_discharge_penalty", "WaiveDischrgPnlty")
    body = gsub(body, "interest_rebate_percent", "IntRebatePrcnt")
    body = gsub(body, "discharge_date", "DischrgDt")
    body = gsub(body, "discharge_reason", "DischrgRsn")
    body = gsub(body, "closure_opt", "ClosureOpt")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","ExpryDt","SavPendDischrgStat","WaiveDischrgPnlty","IntRebatePrcnt","DischrgDt","PromoNum","DischrgRsn","PnltyDay","CashBckRebatePrcnt","ClosureOpt","ClosureTyp","PartialClosureAmt","Ind","SupplierAcctName"}
    -- add ban: to repeating keys avoiding Xferban:AcctNum as just "AcctNum" key exists separately
    -- repeatingKeysforBan = {}
  
  ----------------------------------------------------------------------
  -- 18. transfer-to-deposit
  ----------------------------------------------------------------------
  elseif xmethod == "transfer-to-deposit" then
    debug("This is a transfer-to-deposit request ......... ")
    -- set soap method
    req_method = "nPBTransferToDepositAccount"
    -- set request name for SOAP XML body
    req_name = "XferToDepAcctRq"
    -- set path
    new_path = "/NPBTransferToDepositAccount/NPBTransferToDepositAccountInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "from_account_number", "FrmAcctNum")
    body = gsub(body, "transaction_amount", "TrnAmt")
    body = gsub(body, "amount", "Amt")
    body = gsub(body, "promo_number", "PromoNum")
    body = gsub(body, "to_account_number", "ToAcctNum")
    body = gsub(body, "transaction_currency_code", "TrnCurCode")
    body = gsub(body, "account_currency_code", "AcctCurCode")
    body = gsub(body, "statement_narration", "StmtNarr")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"Flag","FrmAcctNum","Amt","PromoNum","ToAcctNum","NonValDay","DeferIntDay","AcctCurCode","TrnCurCode","Comsn","Chng","CurVer","StmtNarr","ChqNum","BkngNum","ConMask","RcptntNum","DisttCode","TrsryRate","JrnlDt","NumOfUnit","Typ","Actn1","BalOvrWriteInd","CMSTranDesc","CMSRefNum","CMSUserRefNum","IdNum","SrcOfPmt"}
    -- add ban: to repeating keys avoiding Msgban:Typ as just "Typ" key exists separately
    repeatingKeysforBan = {"JrnlNum","MsgTyp","RateTyp","IdTyp","TrnAmt","BaseAmt","Flag1","Flag2","Flag3","Flag4","Flag5","DebtDeferIntDay","DebugFlag","ProcFlag"}

  ----------------------------------------------------------------------
  -- 19. rtgs-inbound
  ----------------------------------------------------------------------
  elseif xmethod == "rtgs-inbound" then
    debug("This is a rtgs-inbound request ......... ")
    -- set soap method
    req_method = "inwardDirectCreditTransaction"
    -- set request name for SOAP XML body
    req_name = "InwardDirCrTrnRq"
    -- set path
    new_path = "/InwardDirectCreditTransaction/InwardDirectCreditTransactionInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    --body = gsub(body, "uuidsource", "UUIDSOURCE")
    body = gsub(body, "uuidnumber", "UUIDNUM")
    body = gsub(body, "creditoraccount", "AcctNum")
    body = gsub(body, "amount", "Amt")
    body = gsub(body, "statementnarrative", "StmtNarr")
    body = gsub(body, "benefiaciaryname", "BnfcryCustName")
    body = gsub(body, "currency", "AcctCurCode")
    body = gsub(body, "sendernib", "Iban")
    body = gsub(body, "promonum", "PromoCode")
    body = gsub(body, "efttype", "EftTrnSrvc")
    body = gsub(body, "description", "Descptn")
    body = gsub(body, "motive", "Motive")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctCurCode","AcctNum","Amt","PromoCode","TrnCurCode","Comsn","Chng","RateTyp","CurVer","UsrRef","StmtNarr","Iban","RsnCode","BSB","PstDt","BnfcryCustName","EftTrnSrvc","IdCode","Descptn","Motive"}
    -- add ban: to repeating keys avoiding Msgban:Typ as just "Typ" key exists separately
    repeatingKeysforBan = {"TrnAmt","TrnCurCode","BaseAmt","Flag1","Flag2","Flag3","Flag4","Flag5","TrnBrch","BsbBank","TrnTyp"}
  ----------------------------------------------------------------------
  -- 20. rtgs-reversal
  ----------------------------------------------------------------------
  elseif xmethod == "rtgs-reversal" then
    debug("This is a rtgs-reversal request ......... ")
    -- set soap method
    req_method = "internalDirectDebitCorrection"
    -- set request name for SOAP XML body
    req_name = "IntrnDirDrCorrectionRq"
    -- set path
    new_path = "/InternalDirectDebitCorrection/InternalDirectDebitCorrectionInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    --body = gsub(body, "uuidsource", "UUIDSOURCE")
    --body = gsub(body, "uuidnumber", "UUIDNUM")
    body = gsub(body, "creditoraccount", "AcctNum1")
    body = gsub(body, "amount", "Amt1")
    body = gsub(body, "statementnarrative", "Stmtnrtv1")
    body = gsub(body, "currency", "AcctCurCode1")
    body = gsub(body, "receivingnibaccount", "Iban")
    --body = gsub(body, "promonum", "PromoCode")
    body = gsub(body, "tracenumber", "Tracer1")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"TxnCurCode1","AcctCurCode1","AcctNum1","Amt1","Comsn1","Chng1","RateTyp1","CurVer1","Stmtnrtv1","Iban","BkngNum1","Opt","Tracer1","DfltStr1","DefInt2"}
    -- add ban: to repeating keys avoiding Msgban:Typ as just "Typ" key exists separately
    repeatingKeysforBan = {"TxnAmt1","AcctNum2","BaseAmt1","DfltStr2","DfltStr3","DfltStr4","DfltStr5","DfltStr6","DfltStr7","DfltStr8"}


  ----------------------------------------------------------------------
  -- 21. enquire-user-transaction-details
    ----------------------------------------------------------------------
  elseif xmethod == "enquire-user-transaction-details" then
    debug("This is a enquire-user-transaction-details request ......... ")
    -- set soap method
    req_method = "enquireUserTransactionDetails"
    -- set request name for SOAP XML body
    req_name = "UsrTrnDetailInqRq"
    -- set path
    new_path = "/EnquireUserTransactionDetails/EnquireUserTransactionDetailsInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "customer_number", "CustNum")
    body = gsub(body, "user_number", "UsrNum")
    body = gsub(body, "func", "Func")
    body = gsub(body, "inst", "Inst")
    body = gsub(body, "eff_dt", "EffDt")
    body = gsub(body, "src_by", "SrchBy")
    -- remove unused keys from the original request body
    -- requestKeysToRemove = {}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"CustNum","UsrNum","Func","Inst","EffDt","SrchBy"}
    -- add ban: to repeating keys avoiding Xferban:AcctNum as just "AcctNum" key exists separately
    -- repeatingKeysforBan = {}

  ----------------------------------------------------------------------
  -- 22. amend-cust-details
  ----------------------------------------------------------------------
  elseif xmethod == "amend-cust-details" then
    debug("This is a amend-cust-details request ......... ")
    -- set soap method
    req_method = "amendCustomerDetails"
    -- set request name for SOAP XML body
    req_name = "CustDetailsModRq"
    -- set path
    new_path = "/AmendCustomerDetails/AmendCustomerDetailsInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "customer_number", "CustNum")
    body = gsub(body, "customer_type", "CustTyp")
    body = gsub(body, "relationship_mgr", "RelnshpMgr")
    body = gsub(body, "title", "Title")
    body = gsub(body, "customer_firstname", "CustFirstName")
    body = gsub(body, "customer_lastname", "CustLastName")
    body = gsub(body, "language_code", "LangCode")
    body = gsub(body, "dmcle", "Dmcle")
    body = gsub(body, "id_number", "IdNum")
    body = gsub(body, "id_type", "IdTyp")
    body = gsub(body, "dmstc_risk", "DmstcRisk")
    body = gsub(body, "crossbrdr_risk", "CrossBrdrRisk")
    body = gsub(body, "home_branch", "HomeBrch")
    body = gsub(body, "kyc_flag", "KycFlag")
    body = gsub(body, "mobile_number", "MobileNum")
    body = gsub(body, "gender", "Gndr")
    body = gsub(body, "dob", "DOB")
    body = gsub(body, "employer_code", "EmprCode")

    uniqueDataKeysToAdd = {"SpouseName","SpouseMarriageDt","SpouseMobNum","SpouseHomeTelNum","SpouseWorkTelNum","SpouseEmployer","kin2Name1","kin2Add1","kin2Add2","kin2Add3","Filler7","Filler8","Filler9","Buss","Biometric","Contact","Addr","Sup","Attr","Kin","Comm","IDD","CustNum","CustTyp","RelnshpMgr","Title","CustFirstName","CustLastName","PstCode","Dmcle","HomeNum","FaxNum","Natlty","HomeOwnership","LangCode","IdNum","IdIssueDt","IdIssueAt","IdTyp","DmstcRisk","CrossBrdrRisk","VipCust","Stat","SegCode","TfnProvided","HomeBrch","CustLmt","Parent","Indust","Country","Sec","IndCode1","GrpCode","CityCode","WthldngTaxExmptn","IvrFlag","KycFlag","KyDtChng","Email","MobileNum","IdExpryDt","BlcklstngComnt","Gndr","GrntrLnkdProcFlag","PolitclyExposedPerson","PEPTyp","ReviewDt","SpecProvsn","CustRiskGrd","EmplTyp","StaffID","DOB","CoopJoinDt","NetIncome","DfltStr","AncPwr","HomeVillage","Headman","MobNetwrk","EmprCode","Initials","Acctnum","CardTyp","BankCode","BrchCode","BankName","BrchName","AppDt","Posn","DtRetrmnt","GrossMnthlyIncome","Occupaction","PlaceOfBirth","TaxRef","MarraigeCont","MaidenName","Edu","PermPrvnc","LicenseNum","HowlongYrs","CurrDepCode","PhotoCapDt","AlertCode","ChngInd","ClntLegNum","GrpFlag","LoanAlwd","BVNNum","YrsOper","LastMaintainDt"}
    repeatingKeysforBan = {"ContactPosn","SpouseDOB","SpouseMaidenName","SpouseAddr1","SpouseAddr2","SpouseAddr3","SpouseIdCode","SpouseGrossMnthlyIncome","CommPstCode","CommCountry","BussSecCode","CorpGrpCode","MaritalStat","EmplStat","LegalStat","PassportCountry","CountryRisk","CustMidName","PEPQult","IdCode","HomeWard","AcctTyp","CardNum","CardExpDt","AcctName","PermHowLong","CurrDepName","GrpName","LastMaintaintime"}    

  ---------------------------------------------------------------------
  -- 23. repayment-schedule-2
  ----------------------------------------------------------------------
  elseif xmethod == "repayment-schedule-2" then
    debug("This is a repayment-schedule-2 request ......... ")
    -- set soap method
    req_method = "repaymentSchedule"
    -- set request name for SOAP XML body
    req_name = "RepmtSchdRq"
    -- set path
    new_path = "/RepaymentSchedule/RepaymentScheduleInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    body = gsub(body, "customer_number", "CustId")
    body = gsub(body, "loan_amount", "LoanAmt")
    body = gsub(body, "intrest_rate", "IntRate")
    body = gsub(body, "loan_term", "LoanTerm")
    body = gsub(body, "amortz", "Amortz")
    body = gsub(body, "approval_date", "ApprvlDt")
    body = gsub(body, "prod_type", "ProdTyp")
    body = gsub(body, "sub_cat", "SubCat")
    body = gsub(body, "page_number", "PgNum")
    body = gsub(body, "term_basis", "TermBasis")
    body = gsub(body, "prncpl_freq", "PrncplFreq")
    body = gsub(body, "int_freq", "IntFreq")
    body = gsub(body, "cap_freq", "CapFreq")

    -- remove unused keys from the original request body
    --requestKeysToRemove = {"customer_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","Opt","CustId","LoanAmt","IntRate","LoanTerm","Amortz","ApprvlDt","ProdTyp","SubCat","PgNum","TermBasis","PrncplFreq","IntFreq","CapFreq","RamadanDef","GracePrd","ProdDescptn","TtlCapFees","TtlDeductFees","TtlMnthlyFees","TtlMnthlyRepay","MnthlyInsu","OrigLoan","LoanPrncpl","EmplrCode","AdvDt","OnceOffInsuTyp","BPFees","BPInsu","BPInt","RepayDay","BPMnthInsu","BPMnthFees","BPMnthInt","BPMthd","TopUpAmt","AdhocFees","BPPendInt","BPPendInsu","BPPendFee","InsuMthd","FirstRepayDt","Coll","SrlNum","RepmtDt","PrncplAmt","IntAmt","TaxAmt","InsuAmt","TtlRepmtAmtDup","Bal","UnearnedInt","InsuNotChrg"}
    
    --uniqueDataKeysToAdd = {"AcctNum","Opt","CustId","LoanAmt","IntRate","LoanTerm","Amortz","ApprvlDt","ProdTyp","SubCat","PgNum","TermBasis","PrncplFreq","IntFreq","CapFreq","RamadanDef","GracePrd","UnearnedInt1","BalloonAmt","ProdDescptn","Ttl","MnthlyInsu","OrigLoan","CollChrg","LoanPrncpl","EmplrCode","AdvDt","OnceOffInsuTyp","BP","RepayDay","TopUpAmt","AdhocFees","InsuMthd","FirstRepayDt","SrlNum","RepmtDt","PrncplAmt","IntAmt","TaxAmt","InsuAmt","Bal","UnearnedInt","InsuNotChrg"}
    
    repeatingKeysforBan = {"OnceOffInsu","CustName","CollChrg","UnearnedInt1","BalloonAmt"}
  
  ---------------------------------------------------------------------
  -- 24. deposit-acc-full-statment
  ----------------------------------------------------------------------
  elseif xmethod == "deposit-acc-full-statment" then
    debug("This is a deposit-acc-full-statment ......... ")
    -- set soap method
    req_method = "depositAccoountFullStatement"
    -- set request name for SOAP XML body
    req_name = "DepAcctFullStmtRq"
    -- set path
    new_path = "/DepositAccoountFullStatement/DepositAccoountFullStatementInterfaceHttpService"
    -- change the name of keys we use for SOAP request
    body = gsub(body, "account_number", "AcctNum")
    body = gsub(body, "prt_from_date", "PrtFrmDt")
    body = gsub(body, "from_date", "FrmDt")
    body = gsub(body, "skip_number_of_trn", "SkipNumOfTrn")
    body = gsub(body, "rs_fmt", "RsFmt")
    body = gsub(body, "to_date", "ToDt")
    body = gsub(body, "brkdwn_cnsldt_trn", "BrkdwnCnsldtTrn")
    body = gsub(body, "promo_number", "PromoNum")
    body = gsub(body, "exmpt_charge", "ExmptChrg")
    body = gsub(body, "statment_referance", "StmtRef")
    body = gsub(body, "email_statment", "EmailStmt")

    -- remove unused keys from the original request body
    --requestKeysToRemove = {"customer_number","id_type","id_number","mobile_number","person_id","trnx_code"}
    -- add ban: prefixes to unique keys per service in request Data block
    uniqueDataKeysToAdd = {"AcctNum","FrmDt","SkipNumOfTrn","RsFmt","ToDt","BrkdwnCnsldtTrn","PromoNum","ExmptChrg","StmtRef","EmailStmt"}
    
    --uniqueDataKeysToAdd = {"AcctNum","Opt","CustId","LoanAmt","IntRate","LoanTerm","Amortz","ApprvlDt","ProdTyp","SubCat","PgNum","TermBasis","PrncplFreq","IntFreq","CapFreq","RamadanDef","GracePrd","UnearnedInt1","BalloonAmt","ProdDescptn","Ttl","MnthlyInsu","OrigLoan","CollChrg","LoanPrncpl","EmplrCode","AdvDt","OnceOffInsuTyp","BP","RepayDay","TopUpAmt","AdhocFees","InsuMthd","FirstRepayDt","SrlNum","RepmtDt","PrncplAmt","IntAmt","TaxAmt","InsuAmt","Bal","UnearnedInt","InsuNotChrg"}
    
    repeatingKeysforBan = {"PrtFrmDt"}




  end

  -------------------------------------------------------------------------
  ------- END OF SETTING SERVICE PARAMETERS
  -------------------------------------------------------------------------
  -- set the request path
  kong.service.request.set_path(new_path)

  local kycid = ""

  if isKyc then
    soap_doc = modify_kyc_request(conf, body)

  else
    body = modify_request(conf, body, requestKeysToRemove, uniqueDataKeysToAdd, repeatingKeysforBan)
    -- decode it again to convert string to table, for the soap transformation
    parameters = parse_json(body)
    if parameters == nil then
      return false, nil
    end
    -- remove dummy
    parameters = remove_single_json(parameters, "RqHeader.dummy")
    -- add country specific keys InstNum, BrchNum, TellerNum
    parameters = add_country_keys(conf, parameters)
    -- encode and covert table to string to transform the country specific keys
    body = cjson.encode(parameters)
    -- add ban: prefixes to unique keys per service in request Data block
    local keysToAdd_ban = {"RqHeader","InstNum","BrchNum","TellerNum"}
    for i,v in ipairs(keysToAdd_ban) do
        body = gsub(body, v, "ban:"..v)
    end
    -- wrap the request in { "body": request } and with method specific values
    -- soap transformation function looks for this, code breaks without it
    body = '{"body":{"'..req_method..'":{"'..req_name..'":'..body..'}}}'

    -- once again decode the json string to a lua table
    parameters = parse_json(body)
    if parameters == nil then
        return false, nil
    end
    local req_namespace = "http://schemas.xmlsoap.org/soap/envelope/"
    local req_soap_prefix = "soap"
    local req_soap_version = "1.1"
    -- transform to XML
    local body = parameters.body[req_method]
    local encode_args = {}
    local root = {}
    parse_entries(body, root)
    encode_args.namespace = req_namespace
    encode_args.method = req_method
    encode_args.entries = root
    encode_args.soap_prefix = req_soap_prefix
    encode_args.soap_version = req_soap_version
    soap_doc = soap.encode(encode_args)

  end

  debug("Transformed request: "..soap_doc)

  return true, soap_doc
end

function _M.transform_body(conf, body, content_type)
    local is_body_transformed = false

    if content_type == JSON then
        is_body_transformed, body = transform_json_body_into_soap(conf, body)
    end

    return is_body_transformed, body
end

return _M
