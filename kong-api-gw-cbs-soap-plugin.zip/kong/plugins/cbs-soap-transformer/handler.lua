local access = require("kong.plugins.cbs-soap-transformer.access")
local kong = kong
local get_raw_body = kong.request.get_raw_body
local set_raw_body = kong.service.request.set_raw_body
local get_header = kong.request.get_header
local set_header = kong.service.request.set_header
local handler = require("xmlhandler.tree")
local xml2lua = require("xml2lua")
local concat = table.concat
local cjson = require("cjson")

local CONTENT_TYPE = "content-type"
local CONTENT_LENGTH = "content-length"

local find = string.find
local sub = string.sub
local gsub = string.gsub
local match = string.match
local lower = string.lower
local next = next
local len = string.len
local pl = require ("pl.pretty")
local ngx_re = require("ngx.re")

-- decode to convert json string to lua table
local function read_json_body(body)
  if body then
    return cjson.decode(body)
  end
end

local function toboolean(value)
  if value == "true" then
    return true
  else
    return false
  end
end

local function cast_value(value, value_type)
  if value_type == "number" then
    return tonumber(value)
  elseif value_type == "boolean" then
    return toboolean(value)
  else
    return value
  end
end

local function iter(config_array)

  if type(config_array) ~= "table" then
    return noop
  end

  return function(config_array, i)
    i = i + 1

    local current_pair = config_array[i]
    if current_pair == nil then -- n + 1
      return nil
    end

    local current_name, current_value = match(current_pair, "^([^:]+):*(.-)$")
    if current_value == "" then
      current_value = nil
    end

    return i, current_name, current_value
  end, config_array, 0
end

  
-- Navigate json to the value(s) pointed to by path and apply function f to it.
local function navigate_and_apply(json, path, f)
  local head, index, tail

  -- Split into a table with three values, e.g. Results[*].info.name becomes {"Results", "[*]", "info.name"}
  local res = ngx_re.split(path, "(\\[[\\d|\\*]*\\])?\\.", nil, nil, 2)

  if res then
  head = res[1]
  if res[2] and res[3] then
      -- Extract index, e.g. "2" from "[2]"
      index = string.sub(res[2], 2, -2)
      tail = res[3]
  else
      tail = res[2]
  end
  end

  if type(json) == "table" then
    if index == '*' then
      -- Loop through array
      local array = json
      if head ~= '' then
        array = json[head]
      end

      for k, v in ipairs(array) do
        if type(v) == "table" then
          navigate_and_apply(v, tail, f)
        end
      end

    elseif index and index ~= '' then
      -- Access specific array element by index
      index = tonumber(index)
      local element = json[index]
      if head ~= '' and json[head] and type(json[head]) == "table" then
        element = json[head][index]
      end

      navigate_and_apply(element, tail, f)

    elseif tail and tail ~= '' then
      -- Navigate into nested JSON
      navigate_and_apply(json[head], tail, f)

    elseif head and head ~= '' then
      -- Apply passed-in function
      f(json, head)

    end
  end
end

-- add key:values
local function add_account_temp_json(body, tempKeys, tempValues)
  local decodedbody = read_json_body(body)
  local jsonHead = "Data."

  for i, v in ipairs(tempValues) do
    navigate_and_apply(decodedbody, jsonHead..tempKeys[i], function (o, p) if not o[p] then o[p] = v end end)
  end

  return cjson.encode(decodedbody)
end

-- remove key:values
local function remove_account_temp_json(decodedbody, tempKeys)
  local jsonHead = "Data."
  for _, name in iter(tempKeys) do
    navigate_and_apply(decodedbody, jsonHead..name, function (o, p) o[p] = nil end)
  end

  return cjson.encode(decodedbody)
end

local function remove_kyc_ns(body)
  body = gsub(body, 'ns:', '')
  body = gsub(body, 'ax%d:', '')
  body = gsub(body, 'ax%d%d:', '')

  return body
end

-- "TheoreticalBal": "33.00-" --> "-33.00"
local function modify_loan_acc_bal(body)
  local isModified = false
  local s = read_json_body(body)
  local balance = s.enquireLoanAccountResponse.LoanAcctInqRs.LoanAcctInqData.TheoreticalBal
  if balance ~= nil and find(balance, "-") then
    balance = gsub(balance, '-', '')
    balance = '-'..balance
    navigate_and_apply(s, "enquireLoanAccountResponse.LoanAcctInqRs.LoanAcctInqData.TheoreticalBal", function (o, p) if o[p] then o[p] = balance end end)
    body = cjson.encode(s)
    isModified = true
  end

  return body,isModified
end

----------------------------------------------------------------------
-- EDIT BELOW TO ADD NEW SERVICES ------------------------------------
----------------------------------------------------------------------

-- remove key:value
local function remove_keys_and_transform(conf, responsejson, account_info_flag)

  -- decode and get table from string after removing :
  -- to perform remove operation for transformation 
  local decodedbody = read_json_body(responsejson)

  -- declaring a table array to store config keys
  local serviceKeys = {}
  -- declaring strings to decide on the JSON mapping based on service
  local reqResponse,reqRs,reqData,reqData2 = "","","",""
  -- declare flags to determine response transformation
  local renameStat,renameData,renameData2,removeKyc,removeJustResponse = false,false,false,false,false
  -- check if the response is an error
  local isError = find(responsejson, "ErrorMessage")

  -- 1. account-info, 3. loan-details-by-cust-number
  if find(responsejson, "enquireAccountDetailsResponse") then
    reqResponse = "enquireAccountDetailsResponse"
    reqRs = "AcctDetailsInqRs"
    reqData = "AcctDetailsInqData"
    renameData = true

  -- 2. prompt-amend-cust-details
  elseif find(responsejson, "promptAmendCustomerDetailsResponse") then
    reqResponse = "promptAmendCustomerDetailsResponse"
    reqRs = "ModCustDetailsPrmptRs"
    reqData = "ModCustDetailsPrmptData"
    renameData = true

  -- 4. search-cust-by-mobile, 5. search-cust-by-id, 16. enquire-cust-search-by-name 
  elseif find(responsejson, "enquireCustomerSearchByNameResponse") then
    reqResponse = "enquireCustomerSearchByNameResponse"
    reqRs = "CustSearchByNameInqRs"
    reqData = "CustSearchByNameInqData"
    reqData2 = "Coll"
    renameData2 = true

  -- 6. repayment-schedule
  elseif find(responsejson, "enquireRepaymentScheduleResponse") then
    reqResponse = "enquireRepaymentScheduleResponse"
    reqRs = "RepmtSchdInqRs"
    reqData = "RepmtSchdInqData" 
    renameData = true 

  -- 7. statement
  elseif find(responsejson, "printDepositAccountStatementResponse") then
    reqResponse = "printDepositAccountStatementResponse"
    reqRs = "DepAcctStmtPrntRs"
    reqData = "DepAcctStmtPrntData" 
    renameData = true 

  -- 8. loan-details-by-acc-number
  elseif find(responsejson, "enquireLoanAccountResponse") then
    reqResponse = "enquireLoanAccountResponse"
    reqRs = "LoanAcctInqRs"
    reqData = "LoanAcctInqData"
    renameData = true
    -- "TheoreticalBal": "33.00-" --> "-33.00"
    local isModified = false
    if not isError then
      responsejson,isModified = modify_loan_acc_bal(responsejson)
    end
    if isModified then
      decodedbody = read_json_body(responsejson)
    end

  -- 9. reversal
  elseif find(responsejson, "nPBTransferToDepositAccountCorrectionResponse") then
    reqResponse = "nPBTransferToDepositAccountCorrectionResponse"
    reqRs = "XferToDepAcctCorrectionRs"
    renameStat = true

  -- 10. kyc-status
  elseif find(responsejson, "getPersonStatusResponse") then
    reqResponse = "getPersonStatusResponse"
    removeKyc = true
    responsejson = remove_kyc_ns(responsejson)
    decodedbody = read_json_body(responsejson)

  -- 11. balance-info
  elseif find(responsejson, "enquireDepositAccountResponse") then
    reqResponse = "enquireDepositAccountResponse"
    reqRs = "DepAcctInqRs"
    reqData = "DepAcctInqData"
    renameData = true

  -- 12. discharge-via-transfer
  elseif find(responsejson, "dischargeViaTransferResponse") then
    reqResponse = "dischargeViaTransferResponse"
    reqRs = "DischrgViaXferRs"
    renameStat = true

  -- 13. discharge-figure, 17. enquire-discharge-figure
  elseif find(responsejson, "enquireDischargeFigureResponse") then
    reqResponse = "enquireDischargeFigureResponse"
    reqRs = "DischrgFigureInqRs"
    reqData = "DischrgFigureInqData"
    renameData = true

  -- 14. loan-repay-by-transfer
  elseif find(responsejson, "loanRepaymentByTransferResponse") then
    reqResponse = "loanRepaymentByTransferResponse"
    reqData = "RepmtByXferRs"
    removeJustResponse = true

  -- 15. transfer-to-no-passbook-depo-acc
  elseif find(responsejson, "transferToNoPassbookDepositAccountResponse") then
    reqResponse = "transferToNoPassbookDepositAccountResponse"
    reqRs = "XferToNoPsbkDepAcctRs"
    renameStat = true

  -- 18. transfer-to-deposit
  elseif find(responsejson, "nPBTransferToDepositAccountResponse") then
    reqResponse = "nPBTransferToDepositAccountResponse"
    reqRs = "XferToDepAcctRs"
    renameStat = true

  -- 19. rtgs-inbound
  elseif find(responsejson, "inwardDirectCreditTransactionResponse") then
    reqResponse = "inwardDirectCreditTransactionResponse"
    reqRs = "InwardDirCrTrnRs"
    renameStat = true

  -- 20. rtgs-reversal
  elseif find(responsejson, "internalDirectDebitCorrectionResponse") then
    reqResponse = "internalDirectDebitCorrectionResponse"
    reqRs = "IntrnDirDrCorrectionRs"
    renameStat = true

  -- 7. enquire-user-transaction-details
  elseif find(responsejson, "enquireUserTransactionDetailsResponse") then
    reqResponse = "enquireUserTransactionDetailsResponse"
    reqRs = "UsrTrnDetailInqRs"
    reqData = "UsrTrnDetailInqData" 
    renameData = true 


  -- 22. amend-cust-details
  elseif find(responsejson, "amendCustomerDetailsResponse") then
    reqResponse = "amendCustomerDetailsResponse"
    reqRs = "CustDetailsModRs"
    renameStat = true

  -- 23. repayment-schedule-2
  elseif find(responsejson, "repaymentScheduleResponse") then
    reqResponse = "repaymentScheduleResponse"
    reqRs = "RepmtSchdRs"
    reqData = "RepmtSchdData" 
    renameData = true

  -- 24. deposit-acc-full-statment
  elseif find(responsejson, "depositAccoountFullStatementResponse") then
    reqResponse = "depositAccoountFullStatementResponse"
    reqRs = "DepAcctFullStmtRs"
    reqData = "DepAcctFullStmtData" 
    renameData = true

  end

  -- choose the keys to remove
  if not account_info_flag then
    -- common keys for all other services including account_info failures
    -- remove just RsHeader
    serviceKeys = conf.remove.common_keys
    
  else
    -- if account_info success
    serviceKeys = conf.remove.account_info
  end

  for _, name in iter(serviceKeys) do

    navigate_and_apply(decodedbody, reqResponse..'.'..reqRs..'.'..name, function (o, p) o[p] = nil end)
  end

  --------------- TRANSFORM RESPONSE ------------------------------

  local transformedResponse = cjson.encode(decodedbody)
  local headToRemove = ""
  local endBracketsToRemove = 0

  -- ERROR
  if isError then
    headToRemove = '{"'..reqResponse..'":{"'..reqRs..'":{"Stat":'
    endBracketsToRemove = 3

  -- 9. 12. 15. 18. 19. 20. 22. responses
  -- remove responseHead and change Stat to Data
  elseif renameStat then
    headToRemove = '{"'..reqResponse..'":{"'..reqRs..'":'
    transformedResponse = gsub(transformedResponse, '{"Stat":' , '{"Data":')
    endBracketsToRemove = 2

  -- 1. 2. 3. 6. 7. 8. 11. 13. 17. 21. 23. 24. responses
  -- remove responseHead and rename Data
  elseif account_info_flag or renameData then
    headToRemove = '{"'..reqResponse..'":{"'..reqRs..'":'
    endBracketsToRemove = 2

  -- 4. 5. 16. responses
  elseif renameData2 then
    headToRemove = '{"'..reqResponse..'":{"'..reqRs..'":{"'..reqData..'":'
    reqData = reqData2
    endBracketsToRemove = 3

  -- kyc 10. response
  elseif removeKyc then
    headToRemove = '{"'..reqResponse..'":'
    endBracketsToRemove = 1

  -- 14. response
  elseif removeJustResponse then
    headToRemove = '{"'..reqResponse..'":'
    endBracketsToRemove = 1

  -- 19. response
  --elseif rtgs then
    --headToRemove = '{"'..reqResponse..'":'
    --endBracketsToRemove = 1

  end

  transformedResponse = gsub(transformedResponse, headToRemove , "")
  -- remove ending } brackets
  local length = len(transformedResponse)
  transformedResponse = sub(transformedResponse, 1, length-endBracketsToRemove)
  -- change initial required element to Data
  if reqData ~= "" then
    transformedResponse = gsub(transformedResponse, reqData , "Data")
  end

  return transformedResponse
end

----------------------------------------------------------------------

-- remove nested key:value in a nested json array only for account_info
local function remove_nested_enquireAccountDetails(conf , finalResponse, count)

  -- flag to change after executing
  local singleAccountFlag = true
  -- for json mapping
  local responseKey = "enquireAccountDetailsResponse.AcctDetailsInqRs."
  -- covert string to json table array
  local decodedbody = read_json_body(finalResponse)

  for _, name in iter(conf.remove.nested_account_info) do

    -- change the max index to the number of accounts returned in response
    -- by replacing filler "index" in the plugin config with count
    name = gsub(name, "index", count)

    -- remove the keys in each array one by one
    for i=count,1,-1 do
      
      -- If response has only one account, then coll[] is no longer an array
      -- So, this is to convert it into one and then do the manipulation
      if count == 1 and singleAccountFlag then
        -- change to false if already isModified
        singleAccountFlag = false

        -- example change sub {} to [] by
        -- "Coll":{ to "Coll":[{
        -- ending }}} to }]}}
        finalResponse = gsub(finalResponse, '"Coll":{', '"Coll":[{')
        -- get length
        local n = len(finalResponse)
        -- remove ending 3 brackets }}}
        local lastbracketsremoved = sub(finalResponse, 1, n-3)

        -- replace with array ] bracket inserted
        finalResponse = lastbracketsremoved.."}]}}"

        -- debug
        -- kong.log.debug("response after array transfomation : "..finalResponse)

        -- decode again
        decodedbody = read_json_body(finalResponse)

      end
      
      navigate_and_apply(decodedbody, responseKey..name, function (o, p) o[p] = nil end)    
      -- coll[0] doesn't exist as indexes in LUA start from 1 rather than 0
      name = gsub(name, i, i - 1)
    end
  end

  return cjson.encode(decodedbody)
end


-- find repeating strings
local function countSubstring(s1, s2)
  local count = 0
  for eachMatch in s1:gmatch(s2) do 
    count = count + 1 
  end
  return count
end

----------------------------------------------------------------------

local SoapTransformerHandler = {
  VERSION = "0.0.2",
  PRIORITY = 799,
}

local function remove_attr_tags(e)
  if type(e) == "table" then
    for k, v in pairs(e) do
      if k == '_attr' then
        e[k] = nil  
      end
      remove_attr_tags(v)
    end
  end
end

function SoapTransformerHandler.convertXMLtoJSON(xml, conf)
  local xmlHandler = handler:new()
  local parser = xml2lua.parser( xmlHandler )
  parser:parse(xml)
  local SOAPPrefix = "soapenv"

  if     match(xml,"soapenv:Envelope") then SOAPPrefix = "soapenv"
  elseif match(xml,"soap:Envelope"   ) then SOAPPrefix = "soap" 
  elseif match(xml,"soap12:Envelope" ) then SOAPPrefix = "soap12" end

  local t = xmlHandler.root[SOAPPrefix .. ":Envelope"][SOAPPrefix .. ":Body"]
  
  remove_attr_tags(t)

  return cjson.encode(t)
end

function SoapTransformerHandler:access(conf)
  local body = get_raw_body()
  local is_body_transformed, body = access.transform_body(conf, body,get_header(CONTENT_TYPE))

  if is_body_transformed then
      set_raw_body(body)
      set_header(CONTENT_LENGTH, #body)
      set_header(CONTENT_TYPE, "text/xml;charset=UTF-8")
  end
end

function SoapTransformerHandler:header_filter(conf)
  kong.response.clear_header("Content-Length")
  kong.response.set_header("Content-Type", "application/json")
end

function SoapTransformerHandler:body_filter(conf)
  local ctx = ngx.ctx
  local chunk, eof = ngx.arg[1], ngx.arg[2]

  ctx.rt_body_chunks = ctx.rt_body_chunks or {}
  ctx.rt_body_chunk_number = ctx.rt_body_chunk_number or 1

  -- if eof wasn't received keep buffering
  if not eof then
      ctx.rt_body_chunks[ctx.rt_body_chunk_number] = chunk
      ctx.rt_body_chunk_number = ctx.rt_body_chunk_number + 1
      ngx.arg[1] = nil
      return
  end

  -- if bad gateway status recieved return
  if kong.response.get_status() == 502 then
      return nil
  end

  -- last piece of body is ready
  local resp_body = concat(ctx.rt_body_chunks)

  if not resp_body or resp_body == '' then
      return nil
  end

  kong.log.debug("Response body XML: "..resp_body)
  -- ngx.arg[1] = self.convertXMLtoJSON(resp_body, conf)

----------------------------------------------------------------------

  -- storing the encoded json, converted from table to string
  local responsejson = self.convertXMLtoJSON(resp_body, conf)

  -- remove ns2:, dlwmin: prefixes from responses
  -- This is to avoid semicolon ":" in json keys which doesn't work with remove function
  responsejson = gsub(responsejson, "ns2:", "")
  responsejson = gsub(responsejson, "dlwmin:", "")

  -- isAccount_info_Success_response
  local account_info_flag = find(responsejson, "AcctDetailsInqData")

  -- all other APIs and also for account_info failures remove just RsHeader
  local finalResponse = remove_keys_and_transform(conf, responsejson, account_info_flag)

  if account_info_flag then
    -- kong.log.debug("This is a account-info success response")
    -- remove nested accounts in coll[]

    -- count number of accounts returned in the response within coll[] array
    local count = countSubstring(finalResponse, "AcctNum")
    -- kong.log.debug("Number of accounts returned are: "..count)

    -- if count == 1
    -- save keys within AcctDetailsInqData apart from coll to re-add later
    -- this is for manipulating coll to a json array of 1 element
    -- because coll defaults to being a string instead of an array for 1 account
    local tempJson = {}
    local CustNum_value,Name_value,CurCode1_value,IdNum_value,KYCFlag_value,IdTyp_value,NibbsBVN_value = "","","","","","",""
    local tempKeys = {"CustNum","Name","CurCode1","IdNum","KYCFlag","IdTyp","NibbsBVN"}

    if count == 1 then
      tempJson =  read_json_body(finalResponse)
      -- save key values before removing
      CustNum_value = tempJson.Data.CustNum
      Name_value = tempJson.Data.Name
      CurCode1_value = tempJson.Data.CurCode1
      IdNum_value = tempJson.Data.IdNum
      KYCFlag_value = tempJson.Data.KYCFlag
      IdTyp_value = tempJson.Data.IdTyp
      NibbsBVN_value = tempJson.Data.NibbsBVN
      -- remove now and re-add them later
      finalResponse = remove_account_temp_json(tempJson, tempKeys)
    end
    
    -- remove other keys not needed for nested accounts within coll[]
    finalResponse = remove_nested_enquireAccountDetails(conf, finalResponse, count)
    
    -- remove empty arrays inside coll[] after unneeded accounts are removed
    -- for example in -
    -- {"enquireAccountDetailsResponse":{"AcctDetailsInqRs":{"AcctDetailsInqData":{"Coll":[{},{},{},{},{},{},{},{}]}}}}
    
    -- if any other array element is empty
    finalResponse = gsub(finalResponse, ",{}", "")
    -- if the first array element is empty
    finalResponse = gsub(finalResponse, ":%[{},", ":[")

    if count == 1 then
      -- re-add the tempKeys
      local tempValues = {CustNum_value,Name_value,CurCode1_value,IdNum_value,KYCFlag_value,IdTyp_value,NibbsBVN_value}
      finalResponse = add_account_temp_json(finalResponse, tempKeys, tempValues)
    end

  end

  -- removing empty arrays and making them empty strings
  finalResponse = gsub(finalResponse, "{}", '""')
  finalResponse = gsub(finalResponse, '""' , "null")
  ngx.arg[1] = finalResponse

----------------------------------------------------------------------

  kong.log.debug("Response body JSON: "..ngx.arg[1])
end


return SoapTransformerHandler
