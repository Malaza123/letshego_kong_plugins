local cjson = require "cjson"
local cjson_safe = require "cjson.safe"
local ngx_re = require("ngx.re")
local url = require "socket.url"
local _M = {}
local type = type
local pcall = pcall
local find = string.find
local sub = string.sub
local gsub = string.gsub
local match = string.match
local lower = string.lower
local next = next
local get_raw_body = kong.request.get_raw_body
local set_raw_body = kong.service.request.set_raw_body
local get_header = kong.request.get_header
local get_path = kong.service.request.get_path
local set_header = kong.service.request.set_header
local set_headers = kong.service.request.set_headers
local set_method = kong.service.request.set_method
local set_path = kong.service.request.set_path
local clear_header = kong.service.request.clear_header


local function toboolean(value)
  if value == "true" then
    return true
  else
    return false
  end
end


local function cast_value(value, value_type)
  if value_type == "number" then
    return tonumber(value)
  elseif value_type == "boolean" then
    return toboolean(value)
  else
    return value
  end
end

local function iter(config_array)

  if type(config_array) ~= "table" then
    return noop
  end

  return function(config_array, i)
    i = i + 1

    local current_pair = config_array[i]
    if current_pair == nil then -- n + 1
      return nil
    end

    local current_name, current_value = match(current_pair, "^([^:]+):*(.-)$")
    if current_value == "" then
      current_value = nil
    end

    return i, current_name, current_value
  end, config_array, 0
end


-- Navigate json to the value(s) pointed to by path and apply function f to it.
local function navigate_and_apply(json, path, f)
  local head, index, tail

  -- Split into a table with three values, e.g. Results[*].info.name becomes {"Results", "[*]", "info.name"}
  local res = ngx_re.split(path, "(\\[[\\d|\\*]*\\])?\\.", nil, nil, 2)

  if res then
  head = res[1]
  if res[2] and res[3] then
      -- Extract index, e.g. "2" from "[2]"
      index = sub(res[2], 2, -2)
      tail = res[3]
  else
      tail = res[2]
  end
  end

  if type(json) == "table" then
    if index == '*' then
      -- Loop through array
      local array = json
      if head ~= '' then
        array = json[head]
      end

      for k, v in ipairs(array) do
        if type(v) == "table" then
          navigate_and_apply(v, tail, f)
        end
      end

    elseif index and index ~= '' then
      -- Access specific array element by index
      index = tonumber(index)
      local element = json[index]
      if head ~= '' and json[head] and type(json[head]) == "table" then
        element = json[head][index]
      end

      navigate_and_apply(element, tail, f)

    elseif tail and tail ~= '' then
      -- Navigate into nested JSON
      navigate_and_apply(json[head], tail, f)

    elseif head and head ~= '' then
      -- Apply passed-in function
      f(json, head)

    end
  end
end

local function add_key_value(jsonbody, key, value)
  navigate_and_apply(jsonbody, key, function (o, p) o[p] = value end)

  return jsonbody
end

local function remove_Keys(jsonbody, Keys)
  for i,name in ipairs(Keys) do
    navigate_and_apply(jsonbody, name, function (o, p) o[p] = nil end)
  end

  return jsonbody
end

local function to_json(body)
  if body then
    local status, res = pcall(cjson_safe.decode, body)
    if status then
      return res
    end
  end
end

local function to_string(json)
  return cjson_safe.encode(json)
end

local function clearHeaders()
  local headers_to_remove = {"x-country","x-service","x-method","x-api-key"}
  for i,name in ipairs(headers_to_remove) do
    clear_header(name)
  end

end

local function transform_payment(xcountry, xmethod, body, auth)
  clearHeaders()
  local headers = {}
  headers["Authorization"] = auth

  local jsonbody = to_json(body)
  local new_path,keys_to_remove = "/api/v1",""

  if xmethod == "lookup-merchants" then
    set_method("GET")
    new_path = new_path..'/p2m/look-up-merchants'
    body = ""
    clear_header("Content-Type")

    if jsonbody.page ~= nil and jsonbody.page ~= "" then
      new_path = new_path..'?page='..jsonbody.page..
                '&search='..url.escape(jsonbody.search)..
                '&perPage='..jsonbody.perPage
    end

  else
    
    if xmethod == "pay-merchant" then
      new_path = new_path..'/p2m/pay-merchant'
      keys_to_remove = {'transaction_type','transaction_id','user_wallet','wicode','account_number','page','search','perPage'}

    ------------- WICODE --------------------
    elseif xmethod == "gen-wicode" then
      new_path = new_path..'/wicode'
      keys_to_remove = {'wicode','account_number','currency','supplier_id','process_cbs','customer','cbs_data','page','search','perPage'}

    elseif xmethod == "wicode-transact" then
      local transaction_type = jsonbody.transaction_type
      keys_to_remove = {'transaction_type','transaction_id','user_wallet','amount','currency','supplier_id','customer','page','search','perPage'}

      if transaction_type == "payment" then
        new_path = new_path..'/wicode/payment'

      elseif transaction_type == "deposit" then
        new_path = new_path..'/wicode/deposit'

      elseif transaction_type == "withdrawal" then
        new_path = new_path..'/wicode/withdraw'

      end

    elseif xmethod == "wicode-reversal" then
      new_path = new_path..'/wicode/reversal'
      keys_to_remove = {'transaction_id','user_wallet','account_number','amount','currency','supplier_id','process_cbs','customer','cbs_data','page','search','perPage'}
      
    end

    jsonbody = remove_Keys(jsonbody, keys_to_remove)
    body = to_string(jsonbody)
  end

  kong.log.debug("new body is ....... "..body)
  set_raw_body(body)
  kong.log.debug("new path is ....... "..new_path)
  set_path(new_path)
  set_headers(headers)

end

local function transform_utility(xcountry, xmethod, body, auth)
  clearHeaders()
  local headers = {}
  headers["Authorization"] = auth
  headers["country"] = xcountry
  
  local new_path = '/api/v1/utility'

  if xmethod == "purchase-vas" then
    local jsonbody = to_json(body)
    headers["utility_type"] = jsonbody.utility_type
    jsonbody["utility_type"] = nil
    body = to_string(jsonbody) 

  elseif xmethod == "lookup-categories" then
    body = ""
    set_method("GET")
    new_path = new_path..'/flutterwave/categories'
    clear_header("Content-Type")
  end

  kong.log.debug("new body is ....... "..body)
  set_raw_body(body)
  kong.log.debug("new path is ....... "..new_path)
  set_path(new_path)
  set_headers(headers)

end

local function transform_onboarding(xcountry, xmethod, body, auth)
  clearHeaders()
  local headers = {}
  headers["Authorization"] = auth
  headers["country"] = xcountry

  
  local jsonbody = to_json(body)
  local new_path = "/letsgo-api/v1"

  if xmethod == "profiles" then
    new_path = new_path..'/userOnboarding'
    --headers["onboarding_type"] = jsonbody.onboarding_type
    --jsonbody["onboarding_type"] = nil
    --body = to_string(jsonbody) 

  elseif xmethod == "profileupdate" then
    new_path = new_path..'/updateAccountStatus'
    --headers["onboarding_type"] = jsonbody.onboarding_type
    --jsonbody["onboarding_type"] = nil
    --body = to_string(jsonbody)

  elseif xmethod == "userprofiles" then
    new_path = new_path..'/getUserAccounts'

  elseif xmethod == "userprofile" then
    new_path = new_path..'/getUserAccount'

  elseif xmethod == "updatekyc" then
    new_path = new_path..'/updateKycLevel'

  end
    headers["onboarding_type"] = jsonbody.onboarding_type
    jsonbody["onboarding_type"] = nil
    body = to_string(jsonbody)

  kong.log.debug("new body is ....... "..body)
  set_raw_body(body)
  kong.log.debug("new path is ....... "..new_path)
  set_path(new_path)
  set_headers(headers)

end


local function transform_wallets(xcountry, xmethod, body, auth)
  clearHeaders()
  local headers = {}
  headers["Authorization"] = auth
  headers["country"] = xcountry
  
  local jsonbody = to_json(body)
  local new_path = "/letsgo-api/v1"

  if xmethod == "balances" then
    new_path = new_path..'/getBalance'

  elseif xmethod == "sendmoney" then
    new_path = new_path..'/sendMoney'

  --elseif xmethod == "balances" then
  --  body = ""
   -- set_method("GET")
   -- new_path = new_path..'/getBalance'
   -- clear_header("Content-Type")
  end
  headers["wallets_type"] = jsonbody.wallets_type
  jsonbody["wallets_type"] = nil
  body = to_string(jsonbody)

  kong.log.debug("new body is ....... "..body)
  set_raw_body(body)
  kong.log.debug("new path is ....... "..new_path)
  set_path(new_path)
  set_headers(headers)

end

local function transform(conf)
  -- get x-country header
  local xcountry = lower(get_header("x-country")) 
  -- get x-service header
  local xservice = lower(get_header("x-service")) 
  -- get x-method header
  local xmethod = lower(get_header("x-method")) 
  -- get body
  local body = get_raw_body()
  -- set auth header
  local auth = conf.esb_auth

  if xservice == "payment" then
    transform_payment(xcountry, xmethod, body, auth)

  elseif xservice == "utility" then
    transform_utility(xcountry, xmethod, body, auth)

  elseif xservice == "onboarding" then
    transform_onboarding(xcountry, xmethod, body, auth)

  elseif xservice == "wallets" then
    transform_wallets(xcountry, xmethod, body, auth)

  end

end

function _M.execute(conf)
  transform(conf)

end

return _M