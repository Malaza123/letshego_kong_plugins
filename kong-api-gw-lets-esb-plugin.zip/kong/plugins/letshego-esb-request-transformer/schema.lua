local typedefs = require "kong.db.schema.typedefs"

-- entries must have colons to set the key and value apart
local strings_array = {
    type = "array",
    default = {},
    elements = { type = "string" }
}

return {
    name = "letshego-esb-request-tranformer",
    fields = {
        {
            consumer = typedefs.no_consumer
        },
        {
            config = {
                type = "record",
                fields = {
                    { esb_auth = {type = "string", required = true, default = 'Basic ABCDEF123'}, }, 
                },
            },
        },
    }
}