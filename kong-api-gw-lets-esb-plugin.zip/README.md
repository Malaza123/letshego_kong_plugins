# Kong SOAP Transformer Plugin

This plugin transformers a letshego ESB requests

## Supported Kong Releases
Kong >= 1.3.x