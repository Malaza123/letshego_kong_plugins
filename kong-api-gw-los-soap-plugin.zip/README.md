# Kong SOAP Transformer Plugin

This plugin transformers a JSON request into a SOAP XML request, and then transforms corresponding SOAP XML response
into a JSON response. 

## Supported Kong Releases
Kong >= 1.3.x