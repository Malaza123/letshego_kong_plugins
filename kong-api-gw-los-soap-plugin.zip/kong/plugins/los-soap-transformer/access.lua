local cjson = require("cjson")
local kong = kong
local pcall = pcall
local JSON = "application/json"
local insert = table.insert
local _M = {}

local find = string.find
local sub = string.sub
local gsub = string.gsub
local match = string.match
local lower = string.lower
local next = next
local pl = require ("pl.pretty")
local ngx_re = require("ngx.re")
local get_header = kong.request.get_header

local function parse_json(body)
    if body then
        local status, res = pcall(cjson.decode, body)
        if status then
            return res
        end
    end
end

local function read_json_body(body)
    if body then
      return cjson.decode(body)
    end
end

----------------------------------------------------------------------
-- EDIT BELOW TO ADD NEW SERVICES ------------------------------------
----------------------------------------------------------------------

-- 1. los document-params
local function modify_los_doc_request(conf, body)
  -- decode the json string to a lua table
  local parameters = parse_json(body)
  if parameters == nil then
      return false, nil
  end
  local application_number = parameters.application_number
  local loan_id = parameters.loan_id
  local soap_doc = '<soapenv:Envelope '..
  'xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '..
  'xmlns:com="http://com.los.dsa.webservice/" '..
  'xmlns:los="urn:los/model/loan/dsa/documentParameters/LOSReqRespDocumentParameters" '..
  'xmlns:req="urn:los/model/loan/dsa/RequestType/RequestType" '..
  'xmlns:doc="urn:los/model/loan/dsa/documentParameters/DocumentParametersInput" '..
  'xmlns:doc1="urn:los/model/loan/dsa/documentParameters/DocumentParametersOutput"'..
  '><soapenv:Header/><soapenv:Body><com:LOSReqDocumentParameters><los:DocParam><req:RequestType><RequestType>S</RequestType><UserID>30003</UserID><Password>Los@1234</Password><Language>EN</Language><ResponseStatus>0</ResponseStatus><ResponseErrorCode>0</ResponseErrorCode><ResponseErrorMessage>0</ResponseErrorMessage></req:RequestType><doc:DocParamInput><LoanApplicationNumber>'..
  application_number..'</LoanApplicationNumber><LoanId>'..loan_id..
  '</LoanId></doc:DocParamInput><doc1:DocParamOutput/></los:DocParam></com:LOSReqDocumentParameters></soapenv:Body></soapenv:Envelope>'

  return soap_doc
end


-- 2. los completeness-check
local function modify_los_compCheck_request(conf, body)
  -- decode the json string to a lua table
  local parameters = parse_json(body)
  if parameters == nil then
      return false, nil
  end
  local application_number = parameters.application_number
  local loan_id = parameters.loan_id
  local soap_doc = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:com="http://com.los.dsa.webservice/" xmlns:los="urn:los/model/loan/dsa/completeness/LOSReqRespCompletenessCheck" xmlns:req="urn:los/model/loan/dsa/RequestType/RequestType" xmlns:loan="urn:los/model/loan/dsa/loanidentifiers/LoanIdentifiers" xmlns:mes="urn:los/model/loan/dsa/messagelist/MessageList" xmlns:mes1="urn:los/model/loan/dsa/message/Message"><soapenv:Header/><soapenv:Body><com:LOSReqCompletenessCheck><!--Optional:--><los:Loan><req:RequestType><RequestType>S</RequestType><UserID>30015</UserID><Password>Los@1234</Password><ResponseStatus>0</ResponseStatus><ResponseErrorCode>0</ResponseErrorCode><ResponseErrorMessage>0</ResponseErrorMessage></req:RequestType><loan:LoanIdentifiers><LoanApplicationNumber>'..
  application_number..'</LoanApplicationNumber><LoanId>'..
  loan_id..'</LoanId><LoanStatus></LoanStatus><CompletenessPassFlag></CompletenessPassFlag><CorrectenessPassFlag></CorrectenessPassFlag><AffordabilityRepaymentCheckFlag></AffordabilityRepaymentCheckFlag></loan:LoanIdentifiers><mes:Messages><!--1 or more repetitions:--><mes1:Message><Code></Code><Text></Text></mes1:Message></mes:Messages></los:Loan></com:LOSReqCompletenessCheck></soapenv:Body></soapenv:Envelope>'

  return soap_doc
end


-- 3. los eligibilty-check
local function modify_los_eligibilityCheck_request(conf, body)
  -- decode the json string to a lua table
  local parameters = parse_json(body)
  if parameters == nil then
      return false, nil
  end
  local customer_number = parameters.customer_number
  local type_of_deduction = parameters.type_of_deduction
  local total_non_statutory_deduction = parameters.total_non_statutory_deduction
  local basic_pay = parameters.basic_pay
  local gross_pay = parameters.gross_pay
  local total_statutory_deduction = parameters.total_statutory_deduction
  local netpay = parameters.netpay
  local other_fixed_income = parameters.other_fixed_income
  local total_deductions = parameters.total_deductions
  local loan_purpose = parameters.loan_purpose
  local emi2 = parameters.emi2
  local employer_code = parameters.employer_code
  local loan_term = parameters.loan_term
  local marital_status = parameters.marital_status
  local expected_disbursement_date = parameters.expected_disbursement_date
  local disbursement_mode = parameters.disbursement_mode
  local product_list_flag = parameters.product_list_flag
  local soap_doc = '<soapenv:Envelope '..
	'xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '..
	'xmlns:com="http://com.los.dsa.webservice/" '..
	'xmlns:elig="urn:los/model/loan/dsa/eligibilitycheckrequest/EligibilityCheckRequest" '..
	'xmlns:req="urn:los/model/loan/dsa/RequestType/RequestType" '..
	'xmlns:prod="urn:los/model/loan/dsa/productsearch/ProductSearch" '..
	'xmlns:ref="urn:los/model/loan/dsa/productsearch/ReferenceNumList" '..
	'xmlns:ref1="urn:los/model/loan/dsa/productsearch/ReferenceNum"><soapenv:Header/><soapenv:Body><com:EligibilityCheckReq><elig:LoanEligibility><req:RequestType><RequestType>P</RequestType><UserID>999912</UserID><Password>Los@1234</Password><ResponseStatus>0</ResponseStatus><ResponseErrorCode>0</ResponseErrorCode><ResponseErrorMessage>0</ResponseErrorMessage></req:RequestType><prod:ProductSearch><TypeOfDeduction>'..
  type_of_deduction..'</TypeOfDeduction><TotalNonStatutoryDeduction>'..
  total_non_statutory_deduction..'</TotalNonStatutoryDeduction><BasicPay>'..
  basic_pay..'</BasicPay><GrossPay>'..
  gross_pay..'</GrossPay><TotalStatutoryDeduction>'..
  total_statutory_deduction..'</TotalStatutoryDeduction><NetPay>'..
  netpay..'</NetPay><TotalOtherInstalments /><OtherFixedIncome>'..
  other_fixed_income..'</OtherFixedIncome><TotalDeductions>'..
  total_deductions..'</TotalDeductions><TotalPayrollEmiExitLoans /><TotalNonPayrollEmiExitLoans /><ConsolidationAmount /><LoanPurpose>'..
  loan_purpose..'</LoanPurpose><NewLoanEMI /><LoanAmount2></LoanAmount2><Emi2 >'..
  emi2..'</Emi2><EmployerCode>'..
  employer_code..'</EmployerCode><PrimApplVipStatus /><LoanTerm>'..
  loan_term..'</LoanTerm><CentralRegistryAmount /><MaritalStatus>'..
  marital_status..'</MaritalStatus><TopupAmount /><TotalPartialDisbursementAmount /><ExpectedDisbursementDate>'..
  expected_disbursement_date..'</ExpectedDisbursementDate><RollOverContractEMI /><TotalThirdPartyEMI /><BrokerCode /><BrokerName /><FirstRepaymentDate /><RepaymentDay /><RepaymentFrequency /><ApprovedLoanAmount /><AffordableLoanAmount /><AdhocFeeAmount /><AdhocFeeType /><CollateralIndicator /><GuarantorRequired /><DisbursementMode>'..
  disbursement_mode..'</DisbursementMode><CentralRegistryAmountFlag /><ProductListFlag>'..
  product_list_flag..'</ProductListFlag><productCategory/><ref:ReferenceNumList><ref1:ReferenceNum><ReferenceNum></ReferenceNum></ref1:ReferenceNum></ref:ReferenceNumList><productCategory /><CifNumber>'..
  customer_number..'</CifNumber></prod:ProductSearch></elig:LoanEligibility></com:EligibilityCheckReq></soapenv:Body></soapenv:Envelope>'

  return soap_doc
end


-- 4. los application-search
local function modify_los_appSearch_request(conf, body)
  -- decode the json string to a lua table
  local parameters = parse_json(body)
  if parameters == nil then
      return false, nil
  end
  local customer_number = parameters.customer_number
  local soap_doc = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:com="http://com.los.dsa.webservice/" xmlns:los="urn:los/model/loan/dsa/applicationSearch/LOSApplicationSearch" xmlns:req="urn:los/model/loan/dsa/RequestType/RequestType" xmlns:cus="urn:los/model/loan/dsa/customerSearchInput/CustomerSearchInput" xmlns:loan="urn:los/model/loan/dsa/loanApplicationsList/LoanApplicationsList" xmlns:loan1="urn:los/model/loan/dsa/loanDetail/LoanApplicationDetails" xmlns:loan2="urn:los/model/loan/dsa/loanApplication/LoanApplication" xmlns:app="urn:los/model/loan/dsa/applicantsList/ApplicantsList" xmlns:app1="urn:los/model/loan/dsa/applicantInfo/ApplicantInfo"><soapenv:Header/><soapenv:Body><com:LOSReqApplicationSearch><!--Optional:--><los:Loan><req:RequestType><RequestType>S</RequestType><UserID>999912</UserID><Password>Los@1234</Password><ResponseStatus>0</ResponseStatus><ResponseErrorCode>0</ResponseErrorCode><ResponseErrorMessage>0</ResponseErrorMessage></req:RequestType><cus:CustomerSearchInput><CIFNumber>'..
  customer_number..'</CIFNumber></cus:CustomerSearchInput><loan:LoanApplications><!--1 or more repetitions:--><loan1:LoanApplicationDetails><loan2:LoanApplication><LoanApplicationNumber/><LoanId/><DateOfSubmission/><LoanPurpose/><LoanAmount/><TermsPeriod/><Status/><BancsLoanAccountNo/><ProductCode/><DateOfCreation/><LoanType/><QueueName/></loan2:LoanApplication><app:Applicants><!--1 or more repetitions:--><app1:ApplicantInfo><FirstName/><LastName/><ApplicantType/><CIFNumber/></app1:ApplicantInfo></app:Applicants></loan1:LoanApplicationDetails></loan:LoanApplications></los:Loan></com:LOSReqApplicationSearch></soapenv:Body></soapenv:Envelope>'

  return soap_doc
end


-- 5. los loan-input-request


-- 6. los loan-amend-request
local function modify_los_amend_request(conf, body)
  -- decode the json string to a lua table
  local parameters = parse_json(body)
  if parameters == nil then
      return false, nil
  end
  local loan_number = parameters.loan_number
  local soap_doc = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:com="http://com.los.dsa.webservice/" xmlns:loan="urn:los/model/loan/dsa/amend/LoanInputOutput" xmlns:req="urn:los/model/loan/dsa/RequestType/RequestType" xmlns:loan1="urn:los/model/loan/dsa/amend/LoanEnquiryInput" xmlns:loan2="urn:los/model/loan/dsa/amend/LoanDetailsAmend" xmlns:app="urn:los/model/loan/dsa/amend/ApplicantDetailsListAmend" xmlns:app1="urn:los/model/loan/dsa/amend/ApplicantAmend" xmlns:per="urn:los/model/loan/dsa/amend/PersonalDetailsAmend" xmlns:con="urn:los/model/loan/dsa/amend/ContactDetailsAmend" xmlns:per1="urn:los/model/loan/dsa/amend/PermanentAddressAmend" xmlns:pos="urn:los/model/loan/dsa/amend/PostalAddressAmend" xmlns:con1="urn:los/model/loan/dsa/amend/ContactInfoAmend" xmlns:emp="urn:los/model/loan/dsa/amend/EmploymentAmend" xmlns:inc="urn:los/model/loan/dsa/amend/IncomeAndExpensesAmend" xmlns:ban="urn:los/model/loan/dsa/amend/BankDetailsAmend" xmlns:spo="urn:los/model/loan/dsa/amend/SpouseDetailsAmend" xmlns:nex="urn:los/model/loan/dsa/amend/NextOfKinDetailsListAmend" xmlns:nex1="urn:los/model/loan/dsa/amend/NextOfKinAmend" xmlns:loan3="urn:los/model/loan/dsa/amend/LoanDisbursementDetailsListAmend" xmlns:loan4="urn:los/model/loan/dsa/amend/LoanDisbursementDetailAmend" xmlns:loan5="urn:los/model/loan/dsa/amend/LoanProductDetailsAmend" xmlns:loan6="urn:los/model/loan/dsa/amend/LoanOutputDefinationAmend"><soapenv:Header/><soapenv:Body><com:LoanAmendRequest><!--Optional:--><loan:Loan><req:RequestType><RequestType>F</RequestType><UserID>0000000000030015</UserID><Password>Los@1234</Password><Language>EN</Language><ResponseStatus>0</ResponseStatus><ResponseErrorCode>0</ResponseErrorCode><ResponseErrorMessage>0</ResponseErrorMessage></req:RequestType><loan1:LoanEnquiryInput><LoanNumber>'..
  loan_number..'</LoanNumber></loan1:LoanEnquiryInput><loan2:LoanDetails><LoanType></LoanType><IntendedUseOfLoan></IntendedUseOfLoan><NewLoan></NewLoan><DeductionType></DeductionType><ThirdPartySettlement></ThirdPartySettlement><ExpectedDateOfDisbursement></ExpectedDateOfDisbursement><DisbursementMode></DisbursementMode><SalesSource></SalesSource><SalesType></SalesType><SalesConsultant></SalesConsultant><SalesConsultantBranch></SalesConsultantBranch><BrokerCode></BrokerCode><BrokerName></BrokerName><BranchCode></BranchCode><User></User><Source></Source><CIFAmendFlag></CIFAmendFlag><CIFNumber/><AmendFlag></AmendFlag><LoanNumber/></loan2:LoanDetails><app:ApplicantDetails><!--1 or more repetitions:--><app1:Applicant><per:PersonalDetails><CIFNumber></CIFNumber><CustomerType></CustomerType><Title></Title><BusinessName></BusinessName><RegisteredBusinessNumber></RegisteredBusinessNumber><FirstName></FirstName><MiddleName></MiddleName><LastName></LastName><VIPStatus></VIPStatus><ActiveSalaryAccountWithLetshego></ActiveSalaryAccountWithLetshego><CustomerStatus></CustomerStatus><DateOfBirth></DateOfBirth><DateOfIncorporation></DateOfIncorporation><RegisteredCompanyNumber></RegisteredCompanyNumber><Gender></Gender><Age></Age><NPAStatus></NPAStatus><LegalName></LegalName><PlaceOfBirth></PlaceOfBirth><MaritalStatus></MaritalStatus><ANCPower></ANCPower><IDType></IDType><IDDateOfIssue></IDDateOfIssue><AdditionalIdType></AdditionalIdType><TaxNumber></TaxNumber><SeniorCitizen></SeniorCitizen><EducationCode></EducationCode><LegacyClientNumber></LegacyClientNumber><Initials></Initials><MaidenName></MaidenName><KnownName></KnownName><MarriageType></MarriageType><Nationality></Nationality><IDNumber></IDNumber><IDDateOfExpiry></IDDateOfExpiry><AdditionalIdNumber></AdditionalIdNumber><NoOfDependents></NoOfDependents><IsGuarantor></IsGuarantor><IDPlaceOfIssue></IDPlaceOfIssue><LGFAccountNumber></LGFAccountNumber><ApplicantRole></ApplicantRole><AmendFlag></AmendFlag></per:PersonalDetails><con:ContactDetails><per1:PermanentAddress><AddressLine1></AddressLine1><AddressLine2></AddressLine2><AddressLine3></AddressLine3><AddressLine4></AddressLine4><ResidentialStatus></ResidentialStatus><Country></Country><Province></Province><City></City><PostCode></PostCode><HowLong></HowLong></per1:PermanentAddress><pos:PostalAddress><AddressLine1></AddressLine1><AddressLine2></AddressLine2><AddressLine3></AddressLine3><AddressLine4></AddressLine4><Country></Country><Province></Province><City></City><PostCode></PostCode></pos:PostalAddress><con1:ContactInfo><HomeTelephoneNo></HomeTelephoneNo><WorkTelephoneNo></WorkTelephoneNo><MobilePhoneNo></MobilePhoneNo><PreferredLanguage></PreferredLanguage><HomeVillage></HomeVillage><HomeVillageHeadman></HomeVillageHeadman><AlertMode></AlertMode><FaxNo></FaxNo><MobileNetworkProvider></MobileNetworkProvider><EmailAddress></EmailAddress><HomeVillageWard></HomeVillageWard><HomeTelephoneIdd></HomeTelephoneIdd><WorkTelephoneIdd></WorkTelephoneIdd><MobilePhoneIdd></MobilePhoneIdd><FaxIdd></FaxIdd></con1:ContactInfo><AmendFlag></AmendFlag></con:ContactDetails><emp:Employment><EmploymentStatus></EmploymentStatus><EmployerCode></EmployerCode><DepartmentCode></DepartmentCode><EmployerType></EmployerType><Industry></Industry><PayrollNumber></PayrollNumber><PayrollContactName></PayrollContactName><Designation></Designation><EmployeeNo></EmployeeNo><DateOfEmployment></DateOfEmployment><LineManagerName></LineManagerName><LineManagerTelephoneNo></LineManagerTelephoneNo><Past2Rating></Past2Rating><UnionName></UnionName><NameOfPreviousEmployer></NameOfPreviousEmployer><ActivelyWorking></ActivelyWorking><EmployerName></EmployerName><DepartmentName></DepartmentName><VoteNumber></VoteNumber><PayrollArea></PayrollArea><PayrollContactNumber></PayrollContactNumber><PayGrade></PayGrade><DateOfRetirement></DateOfRetirement><LineManagerDesignation></LineManagerDesignation><AnyDisciplinaryChargeOnFile></AnyDisciplinaryChargeOnFile><UnionMember></UnionMember><UnionNumber></UnionNumber><AmendFlag></AmendFlag></emp:Employment><inc:IncomeAndExpenses><BasicPay></BasicPay><TotalFixedAllowances></TotalFixedAllowances><OtherFixedIncome></OtherFixedIncome><GrossPay></GrossPay><StatutoryDeductions></StatutoryDeductions><LoanDeductions></LoanDeductions><OtherNonStatutoryDeductions></OtherNonStatutoryDeductions><TotalPayrollDeductions></TotalPayrollDeductions><NetPay></NetPay><PersonalLoans></PersonalLoans><MortgageLoans></MortgageLoans><CarLoans></CarLoans><OtherNonPayrollDeductions></OtherNonPayrollDeductions><TotalOtherDeductions></TotalOtherDeductions><NetPayLessTotalOtherDeductions></NetPayLessTotalOtherDeductions><CentralRegistryRef></CentralRegistryRef><CentralRegistryAmount></CentralRegistryAmount><AmendFlag></AmendFlag></inc:IncomeAndExpenses><ban:BankDetails><BankName></BankName><BankCode></BankCode><AccountType></AccountType><AccountName></AccountName><CardType></CardType><CardExpiryDate></CardExpiryDate><BranchName></BranchName><BranchCode></BranchCode><AccountNumber></AccountNumber><YearsAccountHeld></YearsAccountHeld><CardNumber></CardNumber><AmendFlag></AmendFlag></ban:BankDetails><spo:SpouseDetails><SpouseName></SpouseName><MaidenName></MaidenName><DateOfBirth></DateOfBirth><DateOfMarriage></DateOfMarriage><IDType></IDType><IDNumber></IDNumber><AddressLine1></AddressLine1><AddressLine2></AddressLine2><AddressLine3></AddressLine3><Employer></Employer><HomeTelephoneNo></HomeTelephoneNo><WorkTelephoneNo></WorkTelephoneNo><GrossMonthlyIncome></GrossMonthlyIncome><MobilePhoneNo></MobilePhoneNo><HomeTelephoneIdd></HomeTelephoneIdd><WorkTelephoneIdd></WorkTelephoneIdd><MobilePhoneIdd></MobilePhoneIdd><AmendFlag></AmendFlag></spo:SpouseDetails><nex:NextOfKinDetails><!--1 or more repetitions:--><nex1:NextOfKin><Name></Name><AddressLine1></AddressLine1><AddressLine2></AddressLine2><AddressLine3></AddressLine3><Employer></Employer><Relationship></Relationship><HomeTelephoneNo></HomeTelephoneNo><WorkTelephoneNo></WorkTelephoneNo><MobilePhoneNo></MobilePhoneNo><HomeTelephoneIdd></HomeTelephoneIdd><WorkTelephoneIdd></WorkTelephoneIdd><MobilePhoneIdd></MobilePhoneIdd><AmendFlag></AmendFlag></nex1:NextOfKin></nex:NextOfKinDetails></app1:Applicant></app:ApplicantDetails><loan3:LoanDisbursementDetails><!--1 or more repetitions:--><loan4:LoanDisbursementDetail><DisbursementTo></DisbursementTo><SupplierCode></SupplierCode><ReferenceNo></ReferenceNo><EMIAmount></EMIAmount><SettlementQuotationExpiryDate></SettlementQuotationExpiryDate><SupplierName></SupplierName><DisbursementAmount></DisbursementAmount><TypeOfDeduction></TypeOfDeduction><Stage></Stage><ItemsWork></ItemsWork><Duration></Duration><DisbursementMode></DisbursementMode><DisbursementModeFee></DisbursementModeFee><ExpectedDisbursementDate></ExpectedDisbursementDate><BankCode></BankCode><BranchCode></BranchCode><AccountType></AccountType><LoanDisbursementId></LoanDisbursementId><OperationFlag></OperationFlag><AmendFlag></AmendFlag></loan4:LoanDisbursementDetail></loan3:LoanDisbursementDetails><loan5:LoanProductDetails><CentralRegistryComplianceAmount></CentralRegistryComplianceAmount><ExpectedDisbursementDate></ExpectedDisbursementDate><BrokerCode></BrokerCode><LoanPrincipal></LoanPrincipal><TotalMonthlyRepayment></TotalMonthlyRepayment><ApprovedLoanAmount></ApprovedLoanAmount><AdhocFeeAmount></AdhocFeeAmount><AdhocFeeType></AdhocFeeType><CollateralIndicator></CollateralIndicator><MaximumEMIAffordable></MaximumEMIAffordable><TotalConsolidationAmount></TotalConsolidationAmount><TotalPartialDisbursementAmount></TotalPartialDisbursementAmount><TotalThirdPartyEMI></TotalThirdPartyEMI><BrokerName></BrokerName><Tenure></Tenure><TypeOfDeduction></TypeOfDeduction><AffordableLoanAmount></AffordableLoanAmount><RepaymentFrequency></RepaymentFrequency><FirstRepaymentDate></FirstRepaymentDate><RepaymentDay></RepaymentDay><GuarantorRequired></GuarantorRequired><StatementFrequency></StatementFrequency><Cycle></Cycle><Day></Day><Copies></Copies><ConsolidatedStatements></ConsolidatedStatements><ModeOfStatementDelivery></ModeOfStatementDelivery><AlertMode></AlertMode><ProductCode></ProductCode><ProductDescription></ProductDescription><InterestRate></InterestRate><TotalCapitalisedFees></TotalCapitalisedFees><TotalCapitalAmount></TotalCapitalAmount><TotalInterestDue></TotalInterestDue><BrokenPeriodInterest></BrokenPeriodInterest><DisbFeePromoCode></DisbFeePromoCode><DisbursementModeFee></DisbursementModeFee><TotalDeductedFees></TotalDeductedFees><OnceOffInsurance></OnceOffInsurance><MonthlyInsurance></MonthlyInsurance><BrokenPeriodInsurance></BrokenPeriodInsurance><CollectionCharge></CollectionCharge><EMIPayable></EMIPayable><TotalDisbursed></TotalDisbursed><BrokenPeriodFees></BrokenPeriodFees><BrokenPeriodCategory></BrokenPeriodCategory><OnceOffInsuranceCategory></OnceOffInsuranceCategory><DisbursementAmount></DisbursementAmount><BranchFlag></BranchFlag><BulkDisbursementFlag></BulkDisbursementFlag><StampDuty></StampDuty><EmiAmount></EmiAmount><BpCompType></BpCompType><OneTimeFee></OneTimeFee><OneTimeFeeCap></OneTimeFeeCap><TotalLoanAmount></TotalLoanAmount><TotalInterestAmount></TotalInterestAmount><MonthlyFees></MonthlyFees><AmendFlag></AmendFlag></loan5:LoanProductDetails><loan6:LoanOutputDefination><LoanNumber></LoanNumber><LoanId></LoanId><CriticalChange></CriticalChange><MessageCode></MessageCode></loan6:LoanOutputDefination></loan:Loan></com:LoanAmendRequest></soapenv:Body></soapenv:Envelope>'

  return soap_doc
end


----------------------------------------------------------------------

local function transform_json_body_into_soap(conf, body)
  -- initiating request path variable to later update per request based on service
  local new_path,SOAPAction,soap_doc = "","",""
  -- get x-method header
  local xmethod = get_header("x-method")
  if not xmethod == nil then
    xmethod = lower(xmethod)
  end

  ----------------------------------------------------------------------
  -- EDIT BELOW TO ADD NEW SERVICES ------------------------------------
  ----------------------------------------------------------------------
  
  -- 1. los document-params
  if xmethod == "document-params" then
    kong.log.debug("This is a document-params los request ......... ")
    -- set path
    new_path = "/LOSWebApp/LOSDocumentParametersServiceImplService"
    -- set SOAPAction
    SOAPAction = "GetDocumentParameters"
    -- transformed xml
    soap_doc = modify_los_doc_request(conf, body)

    -- 2. los completeness-check
  elseif xmethod == "completeness-check" then
    kong.log.debug("This is a completeness-check los request ......... ")
    -- set path
    new_path = "/LOSWebApp/LOSCompletenessCheckServiceImplService"
    -- set SOAPAction
    SOAPAction = "CompletenessQuery"
    -- transformed xml
    soap_doc = modify_los_compCheck_request(conf, body)
    
    -- 3. los eligibilty-check
  elseif xmethod == "eligibilty-check" then
    kong.log.debug("This is a completeness-check los request ......... ")
    -- set path
    new_path = "/LOSWebApp/LOSEligibilityCheckServiceImplService"
    -- set SOAPAction
    SOAPAction = "EligibilityCheckQuery"
    -- transformed xml
    soap_doc = modify_los_eligibilityCheck_request(conf, body)
    
    -- 4. los application-search
  elseif xmethod == "application-search" then
    kong.log.debug("This is a application-search los request ......... ")
    -- set path
    new_path = "/LOSWebApp/LOSApplicationSearchServiceImplService"
    -- set SOAPAction
    SOAPAction = "ApplicationSearch"
    -- transformed xml
    soap_doc = modify_los_appSearch_request(conf, body)
    
    -- 5. los loan-input-request
  elseif xmethod == "loan-input-request" then

    
    -- 6. los loan-amend-request
  elseif xmethod == "loan-amend-request" then
    kong.log.debug("This is a loan-amend-request los request ......... ")
    -- set path
    new_path = "/LOSWebApp/LOSAmendApplicationServiceImplService"
    -- set SOAPAction
    SOAPAction = "LoanSaveAmend"
    -- transformed xml
    soap_doc = modify_los_amend_request(conf, body)

  end

  -- set the request path
  kong.service.request.set_path(new_path)

  kong.log.debug("Transformed request: "..soap_doc)
  return true, soap_doc, SOAPAction
end

function _M.transform_body(conf, body, content_type)
    local is_body_transformed = false
    local SOAPAction = ""

    if content_type == JSON then
        is_body_transformed, body, SOAPAction = transform_json_body_into_soap(conf, body)
    end

    return is_body_transformed, body, SOAPAction
end

return _M
