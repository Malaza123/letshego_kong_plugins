local access = require("kong.plugins.los-soap-transformer.access")
local kong = kong
local get_raw_body = kong.request.get_raw_body
local set_raw_body = kong.service.request.set_raw_body
local get_header = kong.request.get_header
local set_header = kong.service.request.set_header
local handler = require("xmlhandler.tree")
local xml2lua = require("xml2lua")
local concat = table.concat
local cjson = require("cjson")

local CONTENT_TYPE = "content-type"
local CONTENT_LENGTH = "content-length"

local find = string.find
local sub = string.sub
local gsub = string.gsub
local match = string.match
local lower = string.lower
local len = string.len
local next = next
local pl = require ("pl.pretty")
local ngx_re = require("ngx.re")

-- decode to convert json string to lua table
local function read_json_body(body)
  if body then
    return cjson.decode(body)
  end
end

-- Navigate json to the value(s) pointed to by path and apply function f to it.
local function navigate_and_apply(json, path, f)
  local head, index, tail

  -- Split into a table with three values, e.g. Results[*].info.name becomes {"Results", "[*]", "info.name"}
  local res = ngx_re.split(path, "(\\[[\\d|\\*]*\\])?\\.", nil, nil, 2)

  if res then
  head = res[1]
  if res[2] and res[3] then
      -- Extract index, e.g. "2" from "[2]"
      index = sub(res[2], 2, -2)
      tail = res[3]
  else
      tail = res[2]
  end
  end

  if type(json) == "table" then
    if index == '*' then
      -- Loop through array
      local array = json
      if head ~= '' then
        array = json[head]
      end

      for k, v in ipairs(array) do
        if type(v) == "table" then
          navigate_and_apply(v, tail, f)
        end
      end

    elseif index and index ~= '' then
      -- Access specific array element by index
      index = tonumber(index)
      local element = json[index]
      if head ~= '' and json[head] and type(json[head]) == "table" then
        element = json[head][index]
      end

      navigate_and_apply(element, tail, f)

    elseif tail and tail ~= '' then
      -- Navigate into nested JSON
      navigate_and_apply(json[head], tail, f)

    elseif head and head ~= '' then
      -- Apply passed-in function
      f(json, head)

    end
  end
end

-- remove single key:value from body
local function remove_single_json(decodedbody, name)
  navigate_and_apply(decodedbody, name, function (o, p) o[p] = nil end)

  return decodedbody
end

-- find repeating strings
local function countSubstring(head, s2)
  local count = 0
  for eachMatch in head:gmatch(s2) do 
    count = count + 1 
  end
  return count
end

-- generic change to an array
local function change_to_array(s, subS)

  -- kong.log.debug("in change_to_array ..............")
  -- kong.log.debug("string recieved: "..s)
  -- kong.log.debug("sub string recieved: "..subS)

  local n = len(s)
  local i,j = find(s, subS)
  -- split at {
  local head = sub(s, 1, j)
  local s2 = sub(s, j+1, n)
  -- split at next }
  local k = find(s2, '}')
  local middle = sub(s2, 1, k)
  local tail = sub(s2, k+1, n)

  -- kong.log.debug("head: "..head)
  -- kong.log.debug("s2: "..s2)
  -- kong.log.debug("middle: "..middle)
  -- kong.log.debug("tail: "..tail)

  return head..'['..middle..']'..tail
end

----------------------------------------------------------------------
-- EDIT BELOW TO ADD NEW SERVICES ------------------------------------
----------------------------------------------------------------------

-- remove ns2: nmiddle4: etc .. prefixes from responses
-- This is to avoid semicolon ":" in json keys
-- remove function doesn't work if : is present
local function remove_ns(body)
  body = gsub(body, 'ns%d:', '')
  body = gsub(body, 'ns%d%d:', '')

  return body
end

-- remove key:value
local function remove_keys_and_transform(responsejson)

  -- declaring strings to decide on the JSON mapping based on service
  local reqResponse,reqRs,inputStr,arrayStr = "","","",""
  local count = 0
  local transform = false

  -- 1. los document-params
  if find(responsejson, "LOSRespDocumentParameters") then
    reqResponse = "LOSRespDocumentParameters"
    reqRs = "DocParam"
    responsejson = gsub(responsejson, "DocParamOutput" , "Data")
    -- DocParamInput string in response
    inputStr = "DocParamInput"
    transform = true

    -- 2. los completeness-check
  elseif find(responsejson, "LOSRespCompletenessCheck") then
    reqResponse = "LOSRespCompletenessCheck"
    reqRs = "Loan"
    responsejson = gsub(responsejson, "LoanIdentifiers" , "Data")
    -- DocParamInput string in response
    inputStr = "Messages"
    transform = true
  
    -- 3. los eligibilty-check
  elseif find(responsejson, "EligibilityCheckResp") then
    reqResponse = "EligibilityCheckResp"
    reqRs = "LoanEligibility"
    -- inputStr = ""
    responsejson = gsub(responsejson, "EligibilityOutput" , "Data")
  
    -- 4. los application-search
  elseif find(responsejson, "LOSRespApplicationSearch") then
    reqResponse = "LOSRespApplicationSearch"
    reqRs = "Loan"
    responsejson = gsub(responsejson, "LoanApplications" , "Data")
    -- CustomerSearchInput string in response
    inputStr = "CustomerSearchInput"
    -- count number of loans returned
    count = countSubstring(responsejson, "LoanApplicationNumber")
    -- when only one "LoanApplicationNumber" is returned
    -- change "LoanApplicationDetails" to an array
    arrayStr = 'LoanApplicationDetails":'
    transform = true
  
    -- 5. los loan-input-request
  
  
    -- 6. los loan-amend-request
  elseif find(responsejson, "LoanAmendResponse") then
    reqResponse = "LoanAmendResponse"
    reqRs = "Loan"
    -- responsejson = gsub(responsejson, "LoanDetails" , "Data")
    -- LoanEnquiryInput string in response
    inputStr = "LoanEnquiryInput"
    -- count number of NextOfKin returned
    count = countSubstring(responsejson, "Relationship")

    --kong.log.debug("Response body count: "..count)
    -- when only one "Relationship" is returned
    -- change "NextOfKin" to an array
    arrayStr = 'NextOfKin":'

   -- kong.log.debug("Response body arrayStr: "..arrayStr)
    transform = true
  
  end


  if transform then

    -----------------------------------------------------------------
    ---------------- REMOVE LOS KEYS --------------------------------
    
    local decodedbody = read_json_body(responsejson)
    local removeRequestType,removeInputStr = "",""
    removeRequestType = reqResponse..'.'..reqRs..'.RequestType'
    if inputStr ~= "" then
      removeInputStr = reqResponse..'.'..reqRs..'.'..inputStr
    end
    local toRemove = {removeRequestType,removeInputStr}
    for i,v in ipairs(toRemove) do
      decodedbody = remove_single_json(decodedbody,v)
      
    end
    

    -----------------------------------------------------------------
    --------------- TRANSFORM LOS RESPONSE --------------------------

    responsejson = cjson.encode(decodedbody)
    local n = len(responsejson)

    if reqResponse == "LoanAmendResponse" then

      local headToReplce = '{"'..reqResponse..'":{"'..reqRs..'":'
      -- remove last bracket
      responsejson = sub(responsejson, 1, n-1)
      responsejson = gsub(responsejson, headToReplce , '{"Data":')

      --kong.log.debug("Response body TRANSFORM LOS RESPONSE: "..responsejson)

    else

      local headToRemove = '{"'..reqResponse..'":{"'..reqRs..'":'
      -- remove last 2 brackets }}
      responsejson = sub(responsejson, 1, n-2)
      responsejson = gsub(responsejson, headToRemove , "")
      --kong.log.debug("Response body TRANSFORM LOS RESPONSE in else block...: "..responsejson)
    end

    -----------------------------------------------------------------
    ---------------------- CHANGE TO ARRAY --------------------------

    if count == 1 then

      -- if we need to change one of the initial objects to array
      if reqResponse == "LOSRespApplicationSearch" then
        
        -- add opening [
        responsejson = gsub(responsejson, arrayStr , arrayStr..'[')
        local n = len(responsejson)
        responsejson = sub(responsejson, 1, n-2)
        -- add closing ]
        responsejson = responsejson..']}}'

      -- if we need to change a middle object to an array
      -- which does not have nested objects but is single object
      elseif reqResponse == "LoanAmendResponse" then

        responsejson = change_to_array(responsejson,arrayStr)

        --kong.log.debug("Response body change_to_array: "..responsejson)

      end

    end

  end

  return responsejson
end


local function transform_error(responsejson)

  local jsonTable = read_json_body(responsejson)
  -- remove extra keys
  jsonTable = remove_single_json(jsonTable, "Fault.faultcode")
  jsonTable = remove_single_json(jsonTable, "Fault.faultstring")
  -- convert back to string
  responsejson = cjson.encode(jsonTable)
  -- remove extra
  local headToRemove = '{"Fault":{"detail":{"LOSError":{"LOSErrorMessages":{"LOSErrorMessage":'
  local tailToRemove = '}}}}}'
  responsejson = gsub(responsejson, headToRemove , "")
  responsejson = gsub(responsejson, tailToRemove , "")

  return responsejson
end

----------------------------------------------------------------------
----------------------------------------------------------------------

local SoapTransformerHandler = {
  VERSION = "0.0.2",
  PRIORITY = 799,
}

local function remove_attr_tags(e)
  if type(e) == "table" then
    for k, v in pairs(e) do
      if k == '_attr' then
        e[k] = nil  
      end
      remove_attr_tags(v)
    end
  end
end

function SoapTransformerHandler.convertXMLtoJSON(xml, conf)
  local xmlHandler = handler:new()
  local parser = xml2lua.parser( xmlHandler )
  parser:parse(xml)
  local SOAPPrefix = "soapenv"

  if     string.match(xml,"soapenv:Envelope") then SOAPPrefix = "soapenv"
  elseif string.match(xml,"soap:Envelope"   ) then SOAPPrefix = "soap" 
  elseif string.match(xml,"soap12:Envelope" ) then SOAPPrefix = "soap12" end

  local t = xmlHandler.root[SOAPPrefix .. ":Envelope"][SOAPPrefix .. ":Body"]
  
  remove_attr_tags(t)

  return cjson.encode(t)
end

function SoapTransformerHandler:access(conf)
  local body = get_raw_body()
  local is_body_transformed, body, SOAPAction = access.transform_body(conf, body,get_header(CONTENT_TYPE))

  if is_body_transformed then
      set_raw_body(body)
      set_header(CONTENT_LENGTH, #body)
      set_header(CONTENT_TYPE, "text/xml;charset=UTF-8")
      set_header("SOAPAction", SOAPAction)
  end
end

function SoapTransformerHandler:header_filter(conf)
  kong.response.clear_header("Content-Length")
  kong.response.set_header("Content-Type", "application/json")
end

function SoapTransformerHandler:body_filter(conf)
  local ctx = ngx.ctx
  local chunk, eof = ngx.arg[1], ngx.arg[2]

  ctx.rt_body_chunks = ctx.rt_body_chunks or {}
  ctx.rt_body_chunk_number = ctx.rt_body_chunk_number or 1

  -- if eof wasn't received keep buffering
  if not eof then
      ctx.rt_body_chunks[ctx.rt_body_chunk_number] = chunk
      ctx.rt_body_chunk_number = ctx.rt_body_chunk_number + 1
      ngx.arg[1] = nil
      return
  end

  -- if bad gateway status recieved return
  if kong.response.get_status() == 502 then
      return nil
  end

  -- last piece of body is ready
  local resp_body = concat(ctx.rt_body_chunks)

  if not resp_body or resp_body == '' then
      return nil
  end

  kong.log.debug("Response body XML: "..resp_body)
  -- ngx.arg[1] = self.convertXMLtoJSON(resp_body, conf)

----------------------------------------------------------------------

  -- storing the encoded json, converted from table to string
  local responsejson = self.convertXMLtoJSON(resp_body, conf)

  -- remove ns2: etc .. prefixes from responses
  -- This is to avoid semicolon ":" in json keys which doesn't work with remove function
  responsejson = remove_ns(responsejson)

  -- removing empty arrays and making them empty strings
  responsejson = gsub(responsejson, "{}", '""')
  --kong.log.debug("Response body gsub: "..responsejson)
  -- check if the response is an error
  local isError = find(responsejson, "LOSErrorMessage")

  if not isError then
    responsejson = remove_keys_and_transform(responsejson)
    --kong.log.debug("Response body is not Error: "..responsejson)
  else
    responsejson = gsub(responsejson, "soapenv:", "")
    responsejson = transform_error(responsejson)
  end
  
  responsejson = gsub(responsejson, '""' , "null")
  ngx.arg[1] = responsejson

----------------------------------------------------------------------

  kong.log.debug("Response body JSON: "..ngx.arg[1])
end


return SoapTransformerHandler
