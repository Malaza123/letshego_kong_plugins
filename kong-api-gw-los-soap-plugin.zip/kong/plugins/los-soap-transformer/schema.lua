local typedefs = require "kong.db.schema.typedefs"

-- entries must have colons to set the key and value apart
local strings_array = {
    type = "array",
    default = {},
    elements = { type = "string" }
}

return {
    name = "los-soap-tranformer",
    fields = {
        {
            consumer = typedefs.no_consumer
        },
        {
            config = {
                type = "record",
                fields = {

                    { add = { type = "record", fields = {
                        
                        -- common keys for all services
                        -- { common_keys = strings_array },

                    }}},
                    -- to remove keys from response
                    { remove = { type = "record", fields = {

                        -- same keys for all APIs
                        -- { common_keys = strings_array },
                        
                    }}},   

                },
            },
        },
    }
}